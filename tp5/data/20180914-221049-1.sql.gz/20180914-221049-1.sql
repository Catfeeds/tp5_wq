
-- -----------------------------
-- Table structure for `xt_action_log`
-- -----------------------------
DROP TABLE IF EXISTS `xt_action_log`;
CREATE TABLE `xt_action_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行会员id',
  `username` char(30) NOT NULL DEFAULT '' COMMENT '用户名',
  `ip` char(30) NOT NULL DEFAULT '' COMMENT '执行行为者ip',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '行为名称',
  `describe` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '执行的URL',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '执行行为的时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2393 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='行为日志表';

-- -----------------------------
-- Records of `xt_action_log`
-- -----------------------------
INSERT INTO `xt_action_log` VALUES ('1874', '1098', '888888', '192.168.0.141', '登录', '登录操作，username：888888', '/s8726/public/admin/login/loginhandle.html', '1', '1535189040', '1535189040');
INSERT INTO `xt_action_log` VALUES ('1873', '1', '100000', '192.168.0.141', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535189000', '1535189000');
INSERT INTO `xt_action_log` VALUES ('1872', '1097', '444444', '192.168.0.141', '登录', '登录操作，username：444444', '/s8726/public/admin/login/loginhandle.html', '1', '1535188729', '1535188729');
INSERT INTO `xt_action_log` VALUES ('1871', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535188357', '1535188357');
INSERT INTO `xt_action_log` VALUES ('1870', '1096', '777777', '127.0.0.1', '登录', '登录操作，username：777777', '/s8726/public/admin/login/loginhandle.html', '1', '1535187768', '1535187768');
INSERT INTO `xt_action_log` VALUES ('1869', '1096', '777777', '127.0.0.1', '登录', '登录操作，username：777777', '/s8726/public/admin/login/loginhandle.html', '1', '1535187706', '1535187706');
INSERT INTO `xt_action_log` VALUES ('1868', '1095', '666666', '127.0.0.1', '登录', '登录操作，username：666666', '/s8726/public/admin/login/loginhandle.html', '1', '1535186639', '1535186639');
INSERT INTO `xt_action_log` VALUES ('1867', '1094', '555555', '127.0.0.1', '登录', '登录操作，username：555555', '/s8726/public/admin/login/loginhandle.html', '1', '1535186547', '1535186547');
INSERT INTO `xt_action_log` VALUES ('1866', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535186133', '1535186133');
INSERT INTO `xt_action_log` VALUES ('1865', '1094', '555555', '127.0.0.1', '登录', '登录操作，username：555555', '/s8726/public/admin/login/loginhandle.html', '1', '1535186033', '1535186033');
INSERT INTO `xt_action_log` VALUES ('1864', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535184910', '1535184910');
INSERT INTO `xt_action_log` VALUES ('1863', '1091', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535181694', '1535181694');
INSERT INTO `xt_action_log` VALUES ('1862', '1091', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535181641', '1535181641');
INSERT INTO `xt_action_log` VALUES ('1861', '1', '100000', '192.168.0.141', '编辑', '编辑会员，id：1093', '/s8726/public/admin/member/memberedit.html', '1', '1535181555', '1535181555');
INSERT INTO `xt_action_log` VALUES ('1860', '1093', '333333', '192.168.0.141', '登录', '登录操作，username：333333', '/s8726/public/admin/login/loginhandle.html', '1', '1535181541', '1535181541');
INSERT INTO `xt_action_log` VALUES ('1859', '1091', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535181244', '1535181244');
INSERT INTO `xt_action_log` VALUES ('1858', '1092', '222222', '192.168.0.141', '登录', '登录操作，username：222222', '/s8726/public/admin/login/loginhandle.html', '1', '1535181230', '1535181230');
INSERT INTO `xt_action_log` VALUES ('1857', '1', '100000', '192.168.0.141', '编辑', '编辑会员，id：1092', '/s8726/public/admin/member/memberedit.html', '1', '1535181109', '1535181109');
INSERT INTO `xt_action_log` VALUES ('1856', '1092', '222222', '192.168.0.141', '登录', '登录操作，username：222222', '/s8726/public/admin/login/loginhandle.html', '1', '1535181093', '1535181093');
INSERT INTO `xt_action_log` VALUES ('1855', '1091', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535180899', '1535180899');
INSERT INTO `xt_action_log` VALUES ('1854', '1091', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535180636', '1535180636');
INSERT INTO `xt_action_log` VALUES ('1853', '1', '100000', '192.168.0.141', '编辑', '编辑会员，id：1091', '/s8726/public/admin/member/memberedit.html', '1', '1535180605', '1535180605');
INSERT INTO `xt_action_log` VALUES ('1852', '1091', '111111', '192.168.0.141', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535180559', '1535180559');
INSERT INTO `xt_action_log` VALUES ('1851', '1', '100000', '192.168.0.141', '编辑', '编辑会员，id：1090', '/s8726/public/admin/member/memberedit.html', '1', '1535179485', '1535179485');
INSERT INTO `xt_action_log` VALUES ('1850', '1090', '111111', '192.168.0.141', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535179465', '1535179465');
INSERT INTO `xt_action_log` VALUES ('1849', '1089', '222222', '127.0.0.1', '登录', '登录操作，username：222222', '/s8726/public/admin/login/loginhandle.html', '1', '1535179204', '1535179204');
INSERT INTO `xt_action_log` VALUES ('1848', '1089', '222222', '127.0.0.1', '登录', '登录操作，username：222222', '/s8726/public/admin/login/loginhandle.html', '1', '1535171195', '1535171195');
INSERT INTO `xt_action_log` VALUES ('1847', '1088', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535171076', '1535171076');
INSERT INTO `xt_action_log` VALUES ('1846', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535171007', '1535171007');
INSERT INTO `xt_action_log` VALUES ('1845', '1088', '111111', '192.168.0.141', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535170940', '1535170940');
INSERT INTO `xt_action_log` VALUES ('1844', '1088', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535170584', '1535170584');
INSERT INTO `xt_action_log` VALUES ('1843', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1088', '/s8726/public/admin/member/memberedit.html', '1', '1535170560', '1535170560');
INSERT INTO `xt_action_log` VALUES ('1842', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535170542', '1535170542');
INSERT INTO `xt_action_log` VALUES ('1841', '1088', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535170456', '1535170456');
INSERT INTO `xt_action_log` VALUES ('1840', '1083', '111111', '192.168.0.141', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535170245', '1535170245');
INSERT INTO `xt_action_log` VALUES ('1839', '1', '100000', '192.168.0.141', '编辑', '编辑会员，id：1083', '/s8726/public/admin/member/memberedit.html', '1', '1535170220', '1535170220');
INSERT INTO `xt_action_log` VALUES ('1838', '1', '100000', '127.0.0.1', '删除', '删除会员，where：id=1085', '/s8726/public/admin/member/memberdel/id/1085.html', '1', '1535169155', '1535169155');
INSERT INTO `xt_action_log` VALUES ('1837', '1', '100000', '127.0.0.1', '删除', '删除会员，where：id=1086', '/s8726/public/admin/member/memberdel/id/1086.html', '1', '1535169151', '1535169151');
INSERT INTO `xt_action_log` VALUES ('1836', '1', '100000', '127.0.0.1', '删除', '删除会员，where：id=1087', '/s8726/public/admin/member/memberdel/id/1087.html', '1', '1535169140', '1535169140');
INSERT INTO `xt_action_log` VALUES ('1835', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535169122', '1535169122');
INSERT INTO `xt_action_log` VALUES ('1834', '1084', '444444', '127.0.0.1', '登录', '登录操作，username：444444', '/s8726/public/admin/login/loginhandle.html', '1', '1535168187', '1535168187');
INSERT INTO `xt_action_log` VALUES ('1833', '1082', '333333', '127.0.0.1', '登录', '登录操作，username：333333', '/s8726/public/admin/login/loginhandle.html', '1', '1535168101', '1535168101');
INSERT INTO `xt_action_log` VALUES ('1832', '1078', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1535167866', '1535167866');
INSERT INTO `xt_action_log` VALUES ('1831', '1081', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535167768', '1535167768');
INSERT INTO `xt_action_log` VALUES ('1830', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1081', '/s8726/public/admin/member/memberedit.html', '1', '1535167716', '1535167716');
INSERT INTO `xt_action_log` VALUES ('1829', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1081', '/s8726/public/admin/member/memberedit.html', '1', '1535167685', '1535167685');
INSERT INTO `xt_action_log` VALUES ('1828', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1081', '/s8726/public/admin/member/memberedit.html', '1', '1535167592', '1535167592');
INSERT INTO `xt_action_log` VALUES ('1827', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1081', '/s8726/public/admin/member/memberedit.html', '1', '1535167536', '1535167536');
INSERT INTO `xt_action_log` VALUES ('1826', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535167492', '1535167492');
INSERT INTO `xt_action_log` VALUES ('1825', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1081', '/s8726/public/admin/member/memberedit.html', '1', '1535167045', '1535167045');
INSERT INTO `xt_action_log` VALUES ('1824', '1081', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535166609', '1535166609');
INSERT INTO `xt_action_log` VALUES ('1823', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535166109', '1535166109');
INSERT INTO `xt_action_log` VALUES ('1822', '1078', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1535165916', '1535165916');
INSERT INTO `xt_action_log` VALUES ('1821', '1079', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535162915', '1535162915');
INSERT INTO `xt_action_log` VALUES ('1820', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535162702', '1535162702');
INSERT INTO `xt_action_log` VALUES ('1819', '1', '100000', '192.168.0.141', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535162366', '1535162366');
INSERT INTO `xt_action_log` VALUES ('1818', '1', '100000', '192.168.0.141', '编辑', '编辑会员，id：1080', '/s8726/public/admin/member/memberedit.html', '1', '1535162182', '1535162182');
INSERT INTO `xt_action_log` VALUES ('1817', '1080', '222222', '192.168.0.141', '登录', '登录操作，username：222222', '/s8726/public/admin/login/loginhandle.html', '1', '1535162165', '1535162165');
INSERT INTO `xt_action_log` VALUES ('1816', '1', '100000', '192.168.0.141', '数据状态', '数据状态调整，model：Shop，ids：59,58,57,56,55，status：-1', '/s8726/public/admin/shopadmin/setstatus.html', '1', '1535161927', '1535161927');
INSERT INTO `xt_action_log` VALUES ('1815', '1', '100000', '192.168.0.141', '编辑', '编辑会员，id：1079', '/s8726/public/admin/member/memberedit.html', '1', '1535161906', '1535161906');
INSERT INTO `xt_action_log` VALUES ('1814', '1079', '111111', '192.168.0.141', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535161881', '1535161881');
INSERT INTO `xt_action_log` VALUES ('1813', '1', '100000', '192.168.0.141', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535161813', '1535161813');
INSERT INTO `xt_action_log` VALUES ('1812', '1', '100000', '192.168.0.141', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535161685', '1535161685');
INSERT INTO `xt_action_log` VALUES ('1811', '1', '100000', '192.168.0.168', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535161284', '1535161284');
INSERT INTO `xt_action_log` VALUES ('1810', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535083216', '1535083216');
INSERT INTO `xt_action_log` VALUES ('1809', '1078', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1535082020', '1535082020');
INSERT INTO `xt_action_log` VALUES ('1808', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535081910', '1535081910');
INSERT INTO `xt_action_log` VALUES ('1807', '1078', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1535074047', '1535074047');
INSERT INTO `xt_action_log` VALUES ('1806', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535018485', '1535018485');
INSERT INTO `xt_action_log` VALUES ('1805', '1078', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1535018301', '1535018301');
INSERT INTO `xt_action_log` VALUES ('1804', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535018265', '1535018265');
INSERT INTO `xt_action_log` VALUES ('1803', '1078', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1535017366', '1535017366');
INSERT INTO `xt_action_log` VALUES ('1802', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535017321', '1535017321');
INSERT INTO `xt_action_log` VALUES ('1801', '1078', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1535016705', '1535016705');
INSERT INTO `xt_action_log` VALUES ('1800', '1078', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1535015837', '1535015837');
INSERT INTO `xt_action_log` VALUES ('1799', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535014593', '1535014593');
INSERT INTO `xt_action_log` VALUES ('1798', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535012187', '1535012187');
INSERT INTO `xt_action_log` VALUES ('1797', '1076', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1535011938', '1535011938');
INSERT INTO `xt_action_log` VALUES ('1796', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：reco', '/s8726/public/admin/config/configedit.html', '1', '1535011470', '1535011470');
INSERT INTO `xt_action_log` VALUES ('1795', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535009637', '1535009637');
INSERT INTO `xt_action_log` VALUES ('1794', '1', '100000', '127.0.0.1', '新增', '产品新增，name：343r3', '/s8726/public/admin/shopadmin/shopadd.html', '1', '1535007201', '1535007201');
INSERT INTO `xt_action_log` VALUES ('1793', '1', '100000', '127.0.0.1', '新增', '产品新增，name：4243232', '/s8726/public/admin/shopadmin/shopadd.html', '1', '1535007179', '1535007179');
INSERT INTO `xt_action_log` VALUES ('1792', '1', '100000', '127.0.0.1', '新增', '产品新增，name：2342342', '/s8726/public/admin/shopadmin/shopadd.html', '1', '1535007171', '1535007171');
INSERT INTO `xt_action_log` VALUES ('1791', '1', '100000', '127.0.0.1', '新增', '产品新增，name：1231231', '/s8726/public/admin/shopadmin/shopadd.html', '1', '1535007162', '1535007162');
INSERT INTO `xt_action_log` VALUES ('1790', '1', '100000', '127.0.0.1', '新增', '产品新增，name：3453533', '/s8726/public/admin/shopadmin/shopadd.html', '1', '1535007154', '1535007154');
INSERT INTO `xt_action_log` VALUES ('1789', '1', '100000', '127.0.0.1', '新增', '产品新增，name：消费品', '/s8726/public/admin/shopadmin/shopadd.html', '1', '1535006718', '1535006718');
INSERT INTO `xt_action_log` VALUES ('1788', '1', '100000', '127.0.0.1', '新增', '文章新增，name：312312321312', '/s8726/public/admin/article/articleadd.html', '1', '1535006408', '1535006408');
INSERT INTO `xt_action_log` VALUES ('1787', '1075', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535006179', '1535006179');
INSERT INTO `xt_action_log` VALUES ('1786', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535005960', '1535005960');
INSERT INTO `xt_action_log` VALUES ('1785', '1', '100000', '192.168.0.168', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535005900', '1535005900');
INSERT INTO `xt_action_log` VALUES ('1784', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：agent_income', '/s8726/public/admin/config/configedit.html', '1', '1534999314', '1534999314');
INSERT INTO `xt_action_log` VALUES ('1783', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534999150', '1534999150');
INSERT INTO `xt_action_log` VALUES ('1782', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534999120', '1534999120');
INSERT INTO `xt_action_log` VALUES ('1781', '1077', '222222', '127.0.0.1', '登录', '登录操作，username：222222', '/s8726/public/admin/login/loginhandle.html', '1', '1534998116', '1534998116');
INSERT INTO `xt_action_log` VALUES ('1780', '1076', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1534998005', '1534998005');
INSERT INTO `xt_action_log` VALUES ('1779', '1075', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1534997849', '1534997849');
INSERT INTO `xt_action_log` VALUES ('1778', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534997773', '1534997773');
INSERT INTO `xt_action_log` VALUES ('1777', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534997661', '1534997661');
INSERT INTO `xt_action_log` VALUES ('1776', '1074', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1534996348', '1534996348');
INSERT INTO `xt_action_log` VALUES ('1775', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534994606', '1534994606');
INSERT INTO `xt_action_log` VALUES ('1774', '1074', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1534994546', '1534994546');
INSERT INTO `xt_action_log` VALUES ('1773', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534994231', '1534994231');
INSERT INTO `xt_action_log` VALUES ('1772', '1074', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1534994065', '1534994065');
INSERT INTO `xt_action_log` VALUES ('1771', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534993883', '1534993883');
INSERT INTO `xt_action_log` VALUES ('1770', '1074', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1534992799', '1534992799');
INSERT INTO `xt_action_log` VALUES ('1769', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534992732', '1534992732');
INSERT INTO `xt_action_log` VALUES ('1768', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534992112', '1534992112');
INSERT INTO `xt_action_log` VALUES ('1767', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1072', '/s8726/public/admin/member/memberedit.html', '1', '1534989972', '1534989972');
INSERT INTO `xt_action_log` VALUES ('1766', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534989948', '1534989948');
INSERT INTO `xt_action_log` VALUES ('1765', '1073', '111112', '127.0.0.1', '登录', '登录操作，username：111112', '/s8726/public/admin/login/loginhandle.html', '1', '1534989872', '1534989872');
INSERT INTO `xt_action_log` VALUES ('1764', '1072', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1534989283', '1534989283');
INSERT INTO `xt_action_log` VALUES ('1763', '1', '100000', '127.0.0.1', '新增', '新增菜单，name：会员提现', '/s8726/public/admin/menu/menuadd.html', '1', '1534989255', '1534989255');
INSERT INTO `xt_action_log` VALUES ('1762', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534988964', '1534988964');
INSERT INTO `xt_action_log` VALUES ('1761', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：产品浏览', '/s8726/public/admin/menu/menuedit.html', '1', '1534931744', '1534931744');
INSERT INTO `xt_action_log` VALUES ('1760', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534931538', '1534931538');
INSERT INTO `xt_action_log` VALUES ('1759', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534926697', '1534926697');
INSERT INTO `xt_action_log` VALUES ('1758', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534923456', '1534923456');
INSERT INTO `xt_action_log` VALUES ('1757', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534920786', '1534920786');
INSERT INTO `xt_action_log` VALUES ('1756', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534920578', '1534920578');
INSERT INTO `xt_action_log` VALUES ('1755', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534918158', '1534918158');
INSERT INTO `xt_action_log` VALUES ('1754', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534909023', '1534909023');
INSERT INTO `xt_action_log` VALUES ('1753', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534903343', '1534903343');
INSERT INTO `xt_action_log` VALUES ('1752', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534899123', '1534899123');
INSERT INTO `xt_action_log` VALUES ('1751', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534841438', '1534841438');
INSERT INTO `xt_action_log` VALUES ('1750', '1070', 'admin1', '127.0.0.1', '登录', '登录操作，username：admin1', '/s8726/public/admin/login/loginhandle.html', '1', '1534840873', '1534840873');
INSERT INTO `xt_action_log` VALUES ('1749', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534840819', '1534840819');
INSERT INTO `xt_action_log` VALUES ('1748', '1070', 'admin1', '127.0.0.1', '登录', '登录操作，username：admin1', '/s8726/public/admin/login/loginhandle.html', '1', '1534840685', '1534840685');
INSERT INTO `xt_action_log` VALUES ('1747', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534838565', '1534838565');
INSERT INTO `xt_action_log` VALUES ('1746', '1', '100000', '127.0.0.1', '新增', '新增菜单，name：会员充值', '/s8726/public/admin/menu/menuadd.html', '1', '1534823178', '1534823178');
INSERT INTO `xt_action_log` VALUES ('1745', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：产品浏览', '/s8726/public/admin/menu/menuedit.html', '1', '1534822955', '1534822955');
INSERT INTO `xt_action_log` VALUES ('1744', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：产品列表', '/s8726/public/admin/menu/menuedit.html', '1', '1534822903', '1534822903');
INSERT INTO `xt_action_log` VALUES ('1743', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：购物商城', '/s8726/public/admin/menu/menuedit.html', '1', '1534822873', '1534822873');
INSERT INTO `xt_action_log` VALUES ('1742', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：会员添加', '/s8726/public/admin/menu/menuedit.html', '1', '1534822754', '1534822754');
INSERT INTO `xt_action_log` VALUES ('1741', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534822731', '1534822731');
INSERT INTO `xt_action_log` VALUES ('1740', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534820478', '1534820478');
INSERT INTO `xt_action_log` VALUES ('1739', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534820457', '1534820457');
INSERT INTO `xt_action_log` VALUES ('1738', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534763284', '1534763284');
INSERT INTO `xt_action_log` VALUES ('1737', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534763232', '1534763232');
INSERT INTO `xt_action_log` VALUES ('1736', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534763189', '1534763189');
INSERT INTO `xt_action_log` VALUES ('1735', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534752838', '1534752838');
INSERT INTO `xt_action_log` VALUES ('1734', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534752812', '1534752812');
INSERT INTO `xt_action_log` VALUES ('1733', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534752314', '1534752314');
INSERT INTO `xt_action_log` VALUES ('1732', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534746149', '1534746149');
INSERT INTO `xt_action_log` VALUES ('1731', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534739824', '1534739824');
INSERT INTO `xt_action_log` VALUES ('1730', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534739646', '1534739646');
INSERT INTO `xt_action_log` VALUES ('1729', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534737471', '1534737471');
INSERT INTO `xt_action_log` VALUES ('1728', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534589205', '1534589205');
INSERT INTO `xt_action_log` VALUES ('1727', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534588932', '1534588932');
INSERT INTO `xt_action_log` VALUES ('1726', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534588743', '1534588743');
INSERT INTO `xt_action_log` VALUES ('1725', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534588044', '1534588044');
INSERT INTO `xt_action_log` VALUES ('1724', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：权限管理', '/s8726/public/admin/menu/menuedit.html', '1', '1534586780', '1534586780');
INSERT INTO `xt_action_log` VALUES ('1723', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534586086', '1534586086');
INSERT INTO `xt_action_log` VALUES ('1722', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：订单管理', '/s8726/public/admin/menu/menuedit.html', '1', '1534585512', '1534585512');
INSERT INTO `xt_action_log` VALUES ('1721', '1', '100000', '127.0.0.1', '数据状态', '数据状态调整，model：Menu，ids：219，status：-1', '/s8726/public/admin/menu/setstatus/ids/219/status/-1.html', '1', '1534585375', '1534585375');
INSERT INTO `xt_action_log` VALUES ('1720', '1', '100000', '127.0.0.1', '数据状态', '数据状态调整，model：Menu，ids：220，status：-1', '/s8726/public/admin/menu/setstatus/ids/220/status/-1.html', '1', '1534585371', '1534585371');
INSERT INTO `xt_action_log` VALUES ('1719', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：订单管理', '/s8726/public/admin/menu/menuedit.html', '1', '1534585215', '1534585215');
INSERT INTO `xt_action_log` VALUES ('1718', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534585098', '1534585098');
INSERT INTO `xt_action_log` VALUES ('1717', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534583904', '1534583904');
INSERT INTO `xt_action_log` VALUES ('1716', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534583496', '1534583496');
INSERT INTO `xt_action_log` VALUES ('1715', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534583469', '1534583469');
INSERT INTO `xt_action_log` VALUES ('1714', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1069', '/s8726/public/admin/member/memberedit.html', '1', '1534582206', '1534582206');
INSERT INTO `xt_action_log` VALUES ('1713', '1', '100000', '127.0.0.1', '编辑', '产品编辑，name：报单产品', '/s8726/public/admin/shopadmin/shopedit.html', '1', '1534582026', '1534582026');
INSERT INTO `xt_action_log` VALUES ('1712', '1', '100000', '127.0.0.1', '授权', '会员授权，id：1069', '/s8726/public/admin/member/memberauth.html', '1', '1534581961', '1534581961');
INSERT INTO `xt_action_log` VALUES ('1711', '1', '100000', '127.0.0.1', '新增', '新增会员，username：1231', '/s8726/public/admin/member/memberadd.html', '1', '1534581916', '1534581916');
INSERT INTO `xt_action_log` VALUES ('1710', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534581636', '1534581636');
INSERT INTO `xt_action_log` VALUES ('1709', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534581624', '1534581624');
INSERT INTO `xt_action_log` VALUES ('1708', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1068', '/s8726/public/admin/member/memberedit.html', '1', '1534578131', '1534578131');
INSERT INTO `xt_action_log` VALUES ('1707', '1', '100000', '127.0.0.1', '编辑', '产品编辑，name：报单产品', '/s8726/public/admin/shopadmin/shopedit.html', '1', '1534578041', '1534578041');
INSERT INTO `xt_action_log` VALUES ('1706', '1068', '1', '127.0.0.1', '登录', '登录操作，username：1', '/s8726/public/admin/login/loginhandle.html', '1', '1534577859', '1534577859');
INSERT INTO `xt_action_log` VALUES ('1705', '1', '100000', '127.0.0.1', '新增', '新增会员，username：1', '/s8726/public/admin/member/memberadd.html', '1', '1534577830', '1534577830');
INSERT INTO `xt_action_log` VALUES ('1704', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534575884', '1534575884');
INSERT INTO `xt_action_log` VALUES ('1703', '1', '100000', '127.0.0.1', '编辑', '分类编辑，name：商城消费', '/s8726/public/admin/shopadmin/shopcategoryedit.html', '1', '1534574274', '1534574274');
INSERT INTO `xt_action_log` VALUES ('1702', '1', '100000', '127.0.0.1', '编辑', '分类编辑，name：报单产品', '/s8726/public/admin/shopadmin/shopcategoryedit.html', '1', '1534574261', '1534574261');
INSERT INTO `xt_action_log` VALUES ('1701', '1', '100000', '127.0.0.1', '编辑', '产品编辑，name：报单产品', '/s8726/public/admin/shopadmin/shopedit.html', '1', '1534574238', '1534574238');
INSERT INTO `xt_action_log` VALUES ('1700', '1', '100000', '127.0.0.1', '编辑', '文章分类编辑，name：报单产品', '/s8726/public/admin/article/articlecategoryedit.html', '1', '1534573945', '1534573945');
INSERT INTO `xt_action_log` VALUES ('1699', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534573861', '1534573861');
INSERT INTO `xt_action_log` VALUES ('1698', '1', '100000', '127.0.0.1', '数据状态', '数据状态调整，model：Config，ids：55，status：-1', '/s8726/public/admin/config/setstatus/ids/55/status/-1.html', '1', '1534571556', '1534571556');
INSERT INTO `xt_action_log` VALUES ('1697', '1', '100000', '127.0.0.1', '数据状态', '数据状态调整，model：Config，ids：55，status：0', '/s8726/public/admin/config/setstatus/ids/55/status/0.html', '1', '1534571536', '1534571536');
INSERT INTO `xt_action_log` VALUES ('1696', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534571496', '1534571496');
INSERT INTO `xt_action_log` VALUES ('1695', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534571491', '1534571491');
INSERT INTO `xt_action_log` VALUES ('1694', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534571484', '1534571484');
INSERT INTO `xt_action_log` VALUES ('1693', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534571479', '1534571479');
INSERT INTO `xt_action_log` VALUES ('1692', '1', '100000', '127.0.0.1', '新增', '新增配置，name：agent_income', '/s8726/public/admin/config/configadd.html', '1', '1534571441', '1534571441');
INSERT INTO `xt_action_log` VALUES ('1691', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534571010', '1534571010');
INSERT INTO `xt_action_log` VALUES ('1690', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534559800', '1534559800');
INSERT INTO `xt_action_log` VALUES ('1689', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534559358', '1534559358');
INSERT INTO `xt_action_log` VALUES ('1688', '1067', '3242sss', '127.0.0.1', '登录', '登录操作，username：3242sss', '/s8726/public/admin/login/loginhandle.html', '1', '1534557317', '1534557317');
INSERT INTO `xt_action_log` VALUES ('1687', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534555666', '1534555666');
INSERT INTO `xt_action_log` VALUES ('1686', '1067', '3242sss', '127.0.0.1', '登录', '登录操作，username：3242sss', '/s8726/public/admin/login/loginhandle.html', '1', '1534555559', '1534555559');
INSERT INTO `xt_action_log` VALUES ('1685', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534517877', '1534517877');
INSERT INTO `xt_action_log` VALUES ('1684', '1067', '3242sss', '127.0.0.1', '登录', '登录操作，username：3242sss', '/s8726/public/admin/login/loginhandle.html', '1', '1534517719', '1534517719');
INSERT INTO `xt_action_log` VALUES ('1683', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534517236', '1534517236');
INSERT INTO `xt_action_log` VALUES ('1682', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534517199', '1534517199');
INSERT INTO `xt_action_log` VALUES ('1681', '1067', '3242sss', '127.0.0.1', '登录', '登录操作，username：3242sss', '/s8726/public/admin/login/loginhandle.html', '1', '1534514726', '1534514726');
INSERT INTO `xt_action_log` VALUES ('1680', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534514639', '1534514639');
INSERT INTO `xt_action_log` VALUES ('1679', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534514618', '1534514618');
INSERT INTO `xt_action_log` VALUES ('1678', '1067', '3242sss', '127.0.0.1', '登录', '登录操作，username：3242sss', '/s8726/public/admin/login/loginhandle.html', '1', '1534513464', '1534513464');
INSERT INTO `xt_action_log` VALUES ('1677', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534513436', '1534513436');
INSERT INTO `xt_action_log` VALUES ('1676', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534511822', '1534511822');
INSERT INTO `xt_action_log` VALUES ('1675', '1067', '3242sss', '127.0.0.1', '登录', '登录操作，username：3242sss', '/s8726/public/admin/login/loginhandle.html', '1', '1534511529', '1534511529');
INSERT INTO `xt_action_log` VALUES ('1674', '1064', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1534508611', '1534508611');
INSERT INTO `xt_action_log` VALUES ('1673', '1064', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1534499726', '1534499726');
INSERT INTO `xt_action_log` VALUES ('1672', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534499516', '1534499516');
INSERT INTO `xt_action_log` VALUES ('1671', '1064', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1534496717', '1534496717');
INSERT INTO `xt_action_log` VALUES ('1670', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534496495', '1534496495');
INSERT INTO `xt_action_log` VALUES ('1669', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534496406', '1534496406');
INSERT INTO `xt_action_log` VALUES ('1668', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：菜单管理', '/s8726/public/admin/menu/menuedit.html', '1', '1534495581', '1534495581');
INSERT INTO `xt_action_log` VALUES ('1667', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：菜单列表', '/s8726/public/admin/menu/menuedit.html', '1', '1534495527', '1534495527');
INSERT INTO `xt_action_log` VALUES ('1666', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：菜单列表', '/s8726/public/admin/menu/menuedit.html', '1', '1534495504', '1534495504');
INSERT INTO `xt_action_log` VALUES ('1665', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：菜单状态', '/s8726/public/admin/menu/menuedit.html', '1', '1534495462', '1534495462');
INSERT INTO `xt_action_log` VALUES ('1664', '1', '100000', '127.0.0.1', '数据状态', '数据状态调整，model：Menu，ids：203，status：1', '/s8726/public/admin/menu/setstatus.html', '1', '1534495423', '1534495423');
INSERT INTO `xt_action_log` VALUES ('1663', '1', '100000', '127.0.0.1', '数据状态', '数据状态调整，model：Menu，ids：140,157,141,166，status：1', '/s8726/public/admin/menu/setstatus.html', '1', '1534495385', '1534495385');
INSERT INTO `xt_action_log` VALUES ('1662', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：接口管理', '/s8726/public/admin/menu/menuedit.html', '1', '1534495367', '1534495367');
INSERT INTO `xt_action_log` VALUES ('1661', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：插件管理', '/s8726/public/admin/menu/menuedit.html', '1', '1534495343', '1534495343');
INSERT INTO `xt_action_log` VALUES ('1660', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：服务管理', '/s8726/public/admin/menu/menuedit.html', '1', '1534495305', '1534495305');
INSERT INTO `xt_action_log` VALUES ('1659', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：驱动安装', '/s8726/public/admin/menu/menuedit.html', '1', '1534495282', '1534495282');
INSERT INTO `xt_action_log` VALUES ('1658', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：优化维护', '/s8726/public/admin/menu/menuedit.html', '1', '1534495253', '1534495253');
INSERT INTO `xt_action_log` VALUES ('1657', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：友情链接', '/s8726/public/admin/menu/menuedit.html', '1', '1534495203', '1534495203');
INSERT INTO `xt_action_log` VALUES ('1656', '1', '100000', '127.0.0.1', '数据状态', '数据状态调整，model：Menu，ids：135，status：-1', '/s8726/public/admin/menu/setstatus/ids/135/status/-1.html', '1', '1534495127', '1534495127');
INSERT INTO `xt_action_log` VALUES ('1655', '1', '100000', '127.0.0.1', '数据状态', '数据状态调整，model：Menu，ids：70，status：-1', '/s8726/public/admin/menu/setstatus/ids/70/status/-1.html', '1', '1534495080', '1534495080');
INSERT INTO `xt_action_log` VALUES ('1654', '1', '100000', '127.0.0.1', '数据状态', '数据状态调整，model：Menu，ids：70,135,140,157,141,166,203，status：0', '/s8726/public/admin/menu/setstatus.html', '1', '1534495066', '1534495066');
INSERT INTO `xt_action_log` VALUES ('1653', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534494922', '1534494922');
INSERT INTO `xt_action_log` VALUES ('1652', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534493969', '1534493969');
INSERT INTO `xt_action_log` VALUES ('1651', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534492447', '1534492447');
INSERT INTO `xt_action_log` VALUES ('1650', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534489538', '1534489538');
INSERT INTO `xt_action_log` VALUES ('1649', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534484184', '1534484184');
INSERT INTO `xt_action_log` VALUES ('1648', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534484174', '1534484174');
INSERT INTO `xt_action_log` VALUES ('1647', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534484052', '1534484052');
INSERT INTO `xt_action_log` VALUES ('1646', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534484035', '1534484035');
INSERT INTO `xt_action_log` VALUES ('1645', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534483839', '1534483839');
INSERT INTO `xt_action_log` VALUES ('1644', '1', '100000', '127.0.0.1', '清理', '文件清理', '/s8726/public/admin/fileclean/cleanlist.html', '1', '1534480742', '1534480742');
INSERT INTO `xt_action_log` VALUES ('1643', '1', '100000', '127.0.0.1', '清理', '文件清理', '/s8726/public/admin/fileclean/cleanlist.html', '1', '1534480714', '1534480714');
INSERT INTO `xt_action_log` VALUES ('1642', '1', '100000', '127.0.0.1', '清理', '文件清理', '/s8726/public/admin/fileclean/cleanlist.html', '1', '1534480713', '1534480713');
INSERT INTO `xt_action_log` VALUES ('1641', '1', '100000', '127.0.0.1', '清理', '文件清理', '/s8726/public/admin/fileclean/cleanlist.html', '1', '1534480710', '1534480710');
INSERT INTO `xt_action_log` VALUES ('1640', '1', '100000', '127.0.0.1', '清理', '文件清理', '/s8726/public/admin/fileclean/cleanlist.html', '1', '1534480125', '1534480125');
INSERT INTO `xt_action_log` VALUES ('1639', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534480107', '1534480107');
INSERT INTO `xt_action_log` VALUES ('1638', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534479137', '1534479137');
INSERT INTO `xt_action_log` VALUES ('1637', '1', '100000', '127.0.0.1', '数据状态', '数据状态调整，model：Menu，ids：222，status：-1', '/s8726/public/admin/menu/setstatus/ids/222/status/-1.html', '1', '1534478660', '1534478660');
INSERT INTO `xt_action_log` VALUES ('1636', '1', '100000', '127.0.0.1', '新增', '产品新增，name：会员网络图', '/s8726/public/admin/shopadmin/shopadd.html', '1', '1534478075', '1534478075');
INSERT INTO `xt_action_log` VALUES ('1635', '1', '100000', '127.0.0.1', '新增', '新增菜单，name：清空数据库', '/s8726/public/admin/menu/menuadd.html', '1', '1534476785', '1534476785');
INSERT INTO `xt_action_log` VALUES ('1634', '1', '100000', '127.0.0.1', '删除', '删除回收站数据，model_name：ActionLog，id0', '/s8726/public/admin/trash/trashdatadel/model_name/ActionLog.html', '1', '1534476424', '1534476424');
INSERT INTO `xt_action_log` VALUES ('1552', '1', '100000', '192.168.0.197', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534124432', '1534124432');
INSERT INTO `xt_action_log` VALUES ('1553', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534124506', '1534124506');
INSERT INTO `xt_action_log` VALUES ('1554', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534126244', '1534126244');
INSERT INTO `xt_action_log` VALUES ('1555', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534126752', '1534126752');
INSERT INTO `xt_action_log` VALUES ('1556', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534126866', '1534126866');
INSERT INTO `xt_action_log` VALUES ('1557', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534126933', '1534126933');
INSERT INTO `xt_action_log` VALUES ('1558', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534127280', '1534127280');
INSERT INTO `xt_action_log` VALUES ('1559', '1', '100000', '192.168.0.197', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534127703', '1534127703');
INSERT INTO `xt_action_log` VALUES ('1560', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534129554', '1534129554');
INSERT INTO `xt_action_log` VALUES ('1561', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534137239', '1534137239');
INSERT INTO `xt_action_log` VALUES ('1562', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534137843', '1534137843');
INSERT INTO `xt_action_log` VALUES ('1563', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534153778', '1534153778');
INSERT INTO `xt_action_log` VALUES ('1564', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534154386', '1534154386');
INSERT INTO `xt_action_log` VALUES ('1565', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534212439', '1534212439');
INSERT INTO `xt_action_log` VALUES ('1566', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534214348', '1534214348');
INSERT INTO `xt_action_log` VALUES ('1567', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534215391', '1534215391');
INSERT INTO `xt_action_log` VALUES ('1568', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534229764', '1534229764');
INSERT INTO `xt_action_log` VALUES ('1569', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534233587', '1534233587');
INSERT INTO `xt_action_log` VALUES ('1570', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534233866', '1534233866');
INSERT INTO `xt_action_log` VALUES ('1571', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534233901', '1534233901');
INSERT INTO `xt_action_log` VALUES ('1572', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534234479', '1534234479');
INSERT INTO `xt_action_log` VALUES ('1573', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534235028', '1534235028');
INSERT INTO `xt_action_log` VALUES ('1574', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534235300', '1534235300');
INSERT INTO `xt_action_log` VALUES ('1575', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534235847', '1534235847');
INSERT INTO `xt_action_log` VALUES ('1576', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534236924', '1534236924');
INSERT INTO `xt_action_log` VALUES ('1577', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534243950', '1534243950');
INSERT INTO `xt_action_log` VALUES ('1578', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534244591', '1534244591');
INSERT INTO `xt_action_log` VALUES ('1579', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534245381', '1534245381');
INSERT INTO `xt_action_log` VALUES ('1580', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534246028', '1534246028');
INSERT INTO `xt_action_log` VALUES ('1581', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534246644', '1534246644');
INSERT INTO `xt_action_log` VALUES ('1582', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534247683', '1534247683');
INSERT INTO `xt_action_log` VALUES ('1583', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534251760', '1534251760');
INSERT INTO `xt_action_log` VALUES ('1584', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534293660', '1534293660');
INSERT INTO `xt_action_log` VALUES ('1585', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534293990', '1534293990');
INSERT INTO `xt_action_log` VALUES ('1586', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534302262', '1534302262');
INSERT INTO `xt_action_log` VALUES ('1587', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534313169', '1534313169');
INSERT INTO `xt_action_log` VALUES ('1588', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534320811', '1534320811');
INSERT INTO `xt_action_log` VALUES ('1589', '1', '100000', '192.168.0.139', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534323930', '1534323930');
INSERT INTO `xt_action_log` VALUES ('1590', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534327580', '1534327580');
INSERT INTO `xt_action_log` VALUES ('1591', '1', '100000', '192.168.0.197', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534328008', '1534328008');
INSERT INTO `xt_action_log` VALUES ('1592', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534328721', '1534328721');
INSERT INTO `xt_action_log` VALUES ('1593', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534328732', '1534328732');
INSERT INTO `xt_action_log` VALUES ('1594', '1', '100000', '192.168.0.197', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534328968', '1534328968');
INSERT INTO `xt_action_log` VALUES ('1595', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534340748', '1534340748');
INSERT INTO `xt_action_log` VALUES ('1596', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534386815', '1534386815');
INSERT INTO `xt_action_log` VALUES ('1597', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534401568', '1534401568');
INSERT INTO `xt_action_log` VALUES ('1598', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534401807', '1534401807');
INSERT INTO `xt_action_log` VALUES ('1599', '1', '100000', '127.0.0.1', '删除', '删除会员，where：id=1050', '/s8726/public/admin/member/memberdel/id/1050.html', '1', '1534402025', '1534402025');
INSERT INTO `xt_action_log` VALUES ('1600', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534403085', '1534403085');
INSERT INTO `xt_action_log` VALUES ('1601', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534403122', '1534403122');
INSERT INTO `xt_action_log` VALUES ('1602', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534404054', '1534404054');
INSERT INTO `xt_action_log` VALUES ('1603', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534404124', '1534404124');
INSERT INTO `xt_action_log` VALUES ('1604', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534406967', '1534406967');
INSERT INTO `xt_action_log` VALUES ('1605', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534407465', '1534407465');
INSERT INTO `xt_action_log` VALUES ('1606', '1', '100000', '127.0.0.1', '新增', '产品新增，name：4入4入34日4r', '/s8726/public/admin/shopadmin/shopadd.html', '1', '1534407829', '1534407829');
INSERT INTO `xt_action_log` VALUES ('1607', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534418345', '1534418345');
INSERT INTO `xt_action_log` VALUES ('1608', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534419811', '1534419811');
INSERT INTO `xt_action_log` VALUES ('1609', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534424842', '1534424842');
INSERT INTO `xt_action_log` VALUES ('1610', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534424889', '1534424889');
INSERT INTO `xt_action_log` VALUES ('1611', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534424949', '1534424949');
INSERT INTO `xt_action_log` VALUES ('1612', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534424993', '1534424993');
INSERT INTO `xt_action_log` VALUES ('1613', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534425236', '1534425236');
INSERT INTO `xt_action_log` VALUES ('1614', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534425297', '1534425297');
INSERT INTO `xt_action_log` VALUES ('1615', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534425350', '1534425350');
INSERT INTO `xt_action_log` VALUES ('1616', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534425411', '1534425411');
INSERT INTO `xt_action_log` VALUES ('1617', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534425442', '1534425442');
INSERT INTO `xt_action_log` VALUES ('1618', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534425566', '1534425566');
INSERT INTO `xt_action_log` VALUES ('1619', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534425611', '1534425611');
INSERT INTO `xt_action_log` VALUES ('1620', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534425768', '1534425768');
INSERT INTO `xt_action_log` VALUES ('1621', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534425866', '1534425866');
INSERT INTO `xt_action_log` VALUES ('1622', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534425880', '1534425880');
INSERT INTO `xt_action_log` VALUES ('1623', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534427188', '1534427188');
INSERT INTO `xt_action_log` VALUES ('1624', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534427216', '1534427216');
INSERT INTO `xt_action_log` VALUES ('1625', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534427255', '1534427255');
INSERT INTO `xt_action_log` VALUES ('1626', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534427600', '1534427600');
INSERT INTO `xt_action_log` VALUES ('1627', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534427770', '1534427770');
INSERT INTO `xt_action_log` VALUES ('1628', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534429371', '1534429371');
INSERT INTO `xt_action_log` VALUES ('1629', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534470309', '1534470309');
INSERT INTO `xt_action_log` VALUES ('1630', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534471208', '1534471208');
INSERT INTO `xt_action_log` VALUES ('1631', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534475847', '1534475847');
INSERT INTO `xt_action_log` VALUES ('1632', '1', '100000', '127.0.0.1', '清理', '文件清理', '/s8726/public/admin/fileclean/cleanlist.html', '1', '1534476402', '1534476402');
INSERT INTO `xt_action_log` VALUES ('1633', '1', '100000', '127.0.0.1', '清理', '文件清理', '/s8726/public/admin/fileclean/cleanlist.html', '1', '1534476406', '1534476406');
INSERT INTO `xt_action_log` VALUES ('1875', '1', '100000', '192.168.0.141', '编辑', '编辑会员，id：1098', '/s8726/public/admin/member/memberedit.html', '1', '1535189060', '1535189060');
INSERT INTO `xt_action_log` VALUES ('1876', '1091', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535330834', '1535330834');
INSERT INTO `xt_action_log` VALUES ('1877', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535330856', '1535330856');
INSERT INTO `xt_action_log` VALUES ('1878', '1098', '888888', '127.0.0.1', '登录', '登录操作，username：888888', '/s8726/public/admin/login/loginhandle.html', '1', '1535330918', '1535330918');
INSERT INTO `xt_action_log` VALUES ('1879', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535330951', '1535330951');
INSERT INTO `xt_action_log` VALUES ('1880', '1091', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535331359', '1535331359');
INSERT INTO `xt_action_log` VALUES ('1881', '1091', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535331482', '1535331482');
INSERT INTO `xt_action_log` VALUES ('1882', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535331684', '1535331684');
INSERT INTO `xt_action_log` VALUES ('1883', '1092', '222222', '127.0.0.1', '登录', '登录操作，username：222222', '/s8726/public/admin/login/loginhandle.html', '1', '1535331803', '1535331803');
INSERT INTO `xt_action_log` VALUES ('1884', '1093', '333333', '127.0.0.1', '登录', '登录操作，username：333333', '/s8726/public/admin/login/loginhandle.html', '1', '1535332409', '1535332409');
INSERT INTO `xt_action_log` VALUES ('1885', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535332432', '1535332432');
INSERT INTO `xt_action_log` VALUES ('1886', '1093', '333333', '127.0.0.1', '登录', '登录操作，username：333333', '/s8726/public/admin/login/loginhandle.html', '1', '1535332603', '1535332603');
INSERT INTO `xt_action_log` VALUES ('1887', '1092', '222222', '127.0.0.1', '登录', '登录操作，username：222222', '/s8726/public/admin/login/loginhandle.html', '1', '1535332655', '1535332655');
INSERT INTO `xt_action_log` VALUES ('1888', '1098', '888888', '127.0.0.1', '登录', '登录操作，username：888888', '/s8726/public/admin/login/loginhandle.html', '1', '1535332739', '1535332739');
INSERT INTO `xt_action_log` VALUES ('1889', '1092', '222222', '127.0.0.1', '登录', '登录操作，username：222222', '/s8726/public/admin/login/loginhandle.html', '1', '1535333043', '1535333043');
INSERT INTO `xt_action_log` VALUES ('1890', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535333153', '1535333153');
INSERT INTO `xt_action_log` VALUES ('1891', '1092', '222222', '127.0.0.1', '登录', '登录操作，username：222222', '/s8726/public/admin/login/loginhandle.html', '1', '1535333503', '1535333503');
INSERT INTO `xt_action_log` VALUES ('1892', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535333624', '1535333624');
INSERT INTO `xt_action_log` VALUES ('1893', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1535333792', '1535333792');
INSERT INTO `xt_action_log` VALUES ('1894', '1092', '222222', '127.0.0.1', '登录', '登录操作，username：222222', '/s8726/public/admin/login/loginhandle.html', '1', '1535333825', '1535333825');
INSERT INTO `xt_action_log` VALUES ('1895', '1093', '333333', '127.0.0.1', '登录', '登录操作，username：333333', '/s8726/public/admin/login/loginhandle.html', '1', '1535333871', '1535333871');
INSERT INTO `xt_action_log` VALUES ('1896', '1098', '888888', '127.0.0.1', '登录', '登录操作，username：888888', '/s8726/public/admin/login/loginhandle.html', '1', '1535333939', '1535333939');
INSERT INTO `xt_action_log` VALUES ('1897', '1091', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535333986', '1535333986');
INSERT INTO `xt_action_log` VALUES ('1898', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535335091', '1535335091');
INSERT INTO `xt_action_log` VALUES ('1899', '1092', '222222', '127.0.0.1', '登录', '登录操作，username：222222', '/s8726/public/admin/login/loginhandle.html', '1', '1535335278', '1535335278');
INSERT INTO `xt_action_log` VALUES ('1900', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535335757', '1535335757');
INSERT INTO `xt_action_log` VALUES ('1901', '1098', '888888', '127.0.0.1', '登录', '登录操作，username：888888', '/s8726/public/admin/login/loginhandle.html', '1', '1535336719', '1535336719');
INSERT INTO `xt_action_log` VALUES ('1902', '1092', '222222', '127.0.0.1', '登录', '登录操作，username：222222', '/s8726/public/admin/login/loginhandle.html', '1', '1535336761', '1535336761');
INSERT INTO `xt_action_log` VALUES ('1903', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535339968', '1535339968');
INSERT INTO `xt_action_log` VALUES ('1904', '1099', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535340126', '1535340126');
INSERT INTO `xt_action_log` VALUES ('1905', '1099', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535340245', '1535340245');
INSERT INTO `xt_action_log` VALUES ('1906', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535340520', '1535340520');
INSERT INTO `xt_action_log` VALUES ('1907', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535340623', '1535340623');
INSERT INTO `xt_action_log` VALUES ('1908', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535340900', '1535340900');
INSERT INTO `xt_action_log` VALUES ('1909', '1099', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535340998', '1535340998');
INSERT INTO `xt_action_log` VALUES ('1910', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535341274', '1535341274');
INSERT INTO `xt_action_log` VALUES ('1911', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535342268', '1535342268');
INSERT INTO `xt_action_log` VALUES ('1912', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535349795', '1535349795');
INSERT INTO `xt_action_log` VALUES ('1913', '1', '100000', '192.168.0.168', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535350013', '1535350013');
INSERT INTO `xt_action_log` VALUES ('1914', '1', '100000', '192.168.0.183', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535350719', '1535350719');
INSERT INTO `xt_action_log` VALUES ('1915', '1', '100000', '192.168.0.183', '编辑', '编辑配置，name：seo_title', '/s8726/public/admin/config/configedit.html', '1', '1535351121', '1535351121');
INSERT INTO `xt_action_log` VALUES ('1916', '1', '100000', '192.168.0.183', '编辑', '编辑配置，name：seo_keywords', '/s8726/public/admin/config/configedit.html', '1', '1535351135', '1535351135');
INSERT INTO `xt_action_log` VALUES ('1917', '1', '100000', '192.168.0.183', '编辑', '编辑配置，name：seo_description', '/s8726/public/admin/config/configedit.html', '1', '1535351160', '1535351160');
INSERT INTO `xt_action_log` VALUES ('1918', '1', '100000', '192.168.0.109', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535351176', '1535351176');
INSERT INTO `xt_action_log` VALUES ('1919', '1', '100000', '192.168.0.120', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535352563', '1535352563');
INSERT INTO `xt_action_log` VALUES ('1920', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535938895', '1535938895');
INSERT INTO `xt_action_log` VALUES ('1921', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：菜单管理', '/s8726/public/admin/menu/menuedit.html', '1', '1535942122', '1535942122');
INSERT INTO `xt_action_log` VALUES ('1922', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：服务管理', '/s8726/public/admin/menu/menuedit.html', '1', '1535942133', '1535942133');
INSERT INTO `xt_action_log` VALUES ('1923', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：接口管理', '/s8726/public/admin/menu/menuedit.html', '1', '1535942154', '1535942154');
INSERT INTO `xt_action_log` VALUES ('1924', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：插件管理', '/s8726/public/admin/menu/menuedit.html', '1', '1535942160', '1535942160');
INSERT INTO `xt_action_log` VALUES ('1925', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：优化维护', '/s8726/public/admin/menu/menuedit.html', '1', '1535942167', '1535942167');
INSERT INTO `xt_action_log` VALUES ('1926', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：权限等级', '/s8726/public/admin/menu/menuedit.html', '1', '1535942209', '1535942209');
INSERT INTO `xt_action_log` VALUES ('1927', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：权限管理', '/s8726/public/admin/menu/menuedit.html', '1', '1535942236', '1535942236');
INSERT INTO `xt_action_log` VALUES ('1928', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：产品浏览', '/s8726/public/admin/menu/menuedit.html', '1', '1535942312', '1535942312');
INSERT INTO `xt_action_log` VALUES ('1929', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1535943185', '1535943185');
INSERT INTO `xt_action_log` VALUES ('1930', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535943577', '1535943577');
INSERT INTO `xt_action_log` VALUES ('1931', '1', '100000', '127.0.0.1', '数据状态', '数据状态调整，model：Shop，ids：53，status：-1', '/s8726/public/admin/shopadmin/setstatus/ids/53/status/-1.html', '1', '1535944513', '1535944513');
INSERT INTO `xt_action_log` VALUES ('1932', '1', '100000', '127.0.0.1', '编辑', '产品编辑，name：广告包', '/s8726/public/admin/shopadmin/shopedit.html', '1', '1535944526', '1535944526');
INSERT INTO `xt_action_log` VALUES ('1933', '1', '100000', '127.0.0.1', '编辑', '产品编辑，name：广告包', '/s8726/public/admin/shopadmin/shopedit.html', '1', '1535944546', '1535944546');
INSERT INTO `xt_action_log` VALUES ('1934', '1', '100000', '127.0.0.1', '删除', '产品分类删除，where：id=12', '/s8726/public/admin/shopadmin/shopcategorydel/id/12.html', '1', '1535946092', '1535946092');
INSERT INTO `xt_action_log` VALUES ('1935', '1', '100000', '127.0.0.1', '编辑', '分类编辑，name：广告包', '/s8726/public/admin/shopadmin/shopcategoryedit.html', '1', '1535946108', '1535946108');
INSERT INTO `xt_action_log` VALUES ('1936', '1', '100000', '127.0.0.1', '删除', '产品分类删除，where：id=7', '/s8726/public/admin/shopadmin/shopcategorydel/id/7.html', '1', '1535946233', '1535946233');
INSERT INTO `xt_action_log` VALUES ('1937', '1', '100000', '127.0.0.1', '新增', '分类新增，name：广告包', '/s8726/public/admin/shopadmin/shopcategoryadd.html', '1', '1535946321', '1535946321');
INSERT INTO `xt_action_log` VALUES ('1938', '1', '100000', '127.0.0.1', '编辑', '产品编辑，name：广告包', '/s8726/public/admin/shopadmin/shopedit.html', '1', '1535947730', '1535947730');
INSERT INTO `xt_action_log` VALUES ('1939', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：推荐图', '/s8726/public/admin/menu/menuedit.html', '1', '1535955798', '1535955798');
INSERT INTO `xt_action_log` VALUES ('1940', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535957721', '1535957721');
INSERT INTO `xt_action_log` VALUES ('1941', '1', '100000', '192.168.0.103', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1535959740', '1535959740');
INSERT INTO `xt_action_log` VALUES ('1942', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：购物商城', '/c8903/public/admin/menu/menuedit.html', '1', '1535966122', '1535966122');
INSERT INTO `xt_action_log` VALUES ('1943', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：权限等级', '/c8903/public/admin/menu/menuedit.html', '1', '1535966149', '1535966149');
INSERT INTO `xt_action_log` VALUES ('1944', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：后台管理', '/c8903/public/admin/menu/menuedit.html', '1', '1535966266', '1535966266');
INSERT INTO `xt_action_log` VALUES ('1945', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：会员管理', '/c8903/public/admin/menu/menuedit.html', '1', '1535966341', '1535966341');
INSERT INTO `xt_action_log` VALUES ('1946', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：文章管理', '/c8903/public/admin/menu/menuedit.html', '1', '1535966471', '1535966471');
INSERT INTO `xt_action_log` VALUES ('1947', '1', '100000', '192.168.0.103', '新增', '新增菜单，name：个人设置', '/c8903/public/admin/menu/menuadd.html', '1', '1535966736', '1535966736');
INSERT INTO `xt_action_log` VALUES ('1948', '1', '100000', '192.168.0.103', '新增', '新增菜单，name：会员档案', '/c8903/public/admin/menu/menuadd.html', '1', '1535966788', '1535966788');
INSERT INTO `xt_action_log` VALUES ('1949', '1', '100000', '192.168.0.103', '新增', '新增菜单，name：注册账户', '/c8903/public/admin/menu/menuadd.html', '1', '1535966876', '1535966876');
INSERT INTO `xt_action_log` VALUES ('1950', '1', '100000', '192.168.0.103', '新增', '新增菜单，name：二维码分享', '/c8903/public/admin/menu/menuadd.html', '1', '1535966957', '1535966957');
INSERT INTO `xt_action_log` VALUES ('1951', '1', '100000', '192.168.0.103', '数据排序', '数据排序调整，model：Menu，id：225，value：1', '/c8903/public/admin/menu/setsort.html', '1', '1535967101', '1535967101');
INSERT INTO `xt_action_log` VALUES ('1952', '1', '100000', '192.168.0.103', '数据排序', '数据排序调整，model：Menu，id：198，value：2', '/c8903/public/admin/menu/setsort.html', '1', '1535967132', '1535967132');
INSERT INTO `xt_action_log` VALUES ('1953', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：二维码分享', '/c8903/public/admin/menu/menuedit.html', '1', '1535967387', '1535967387');
INSERT INTO `xt_action_log` VALUES ('1954', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：会员档案', '/c8903/public/admin/menu/menuedit.html', '1', '1535967596', '1535967596');
INSERT INTO `xt_action_log` VALUES ('1955', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：注册账户', '/c8903/public/admin/menu/menuedit.html', '1', '1535967614', '1535967614');
INSERT INTO `xt_action_log` VALUES ('1956', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：推荐图', '/c8903/public/admin/menu/menuedit.html', '1', '1535967780', '1535967780');
INSERT INTO `xt_action_log` VALUES ('1957', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：货币流向', '/c8903/public/menu/menuedit.html', '1', '1535968523', '1535968523');
INSERT INTO `xt_action_log` VALUES ('1958', '1', '100000', '192.168.0.103', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1535968582', '1535968582');
INSERT INTO `xt_action_log` VALUES ('1959', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：资料修改', '/c8903/public/menu/menuedit.html', '1', '1535969069', '1535969069');
INSERT INTO `xt_action_log` VALUES ('1960', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：我的信息', '/c8903/public/menu/menuedit.html', '1', '1535969097', '1535969097');
INSERT INTO `xt_action_log` VALUES ('1961', '1', '100000', '192.168.0.144', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1535969138', '1535969138');
INSERT INTO `xt_action_log` VALUES ('1962', '1', '100000', '192.168.0.103', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1535969147', '1535969147');
INSERT INTO `xt_action_log` VALUES ('1963', '1', '100000', '192.168.0.103', '新增', '新增菜单，name：会员中心', '/c8903/public/menu/menuadd.html', '1', '1535969770', '1535969770');
INSERT INTO `xt_action_log` VALUES ('1964', '1', '100000', '192.168.0.103', '数据排序', '数据排序调整，model：Menu，id：229，value：1', '/c8903/public/menu/setsort.html', '1', '1535969798', '1535969798');
INSERT INTO `xt_action_log` VALUES ('1965', '1', '100000', '192.168.0.103', '新增', '新增菜单，name：提现', '/c8903/public/menu/menuadd.html', '1', '1535969850', '1535969850');
INSERT INTO `xt_action_log` VALUES ('1966', '1', '100000', '192.168.0.103', '新增', '新增菜单，name：转账', '/c8903/public/menu/menuadd.html', '1', '1535969902', '1535969902');
INSERT INTO `xt_action_log` VALUES ('1967', '1', '100000', '192.168.0.103', '新增', '新增菜单，name：财务明细', '/c8903/public/menu/menuadd.html', '1', '1535970098', '1535970098');
INSERT INTO `xt_action_log` VALUES ('1968', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：优化维护', '/c8903/public/menu/menuedit.html', '1', '1535971031', '1535971031');
INSERT INTO `xt_action_log` VALUES ('1969', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：插件管理', '/c8903/public/menu/menuedit.html', '1', '1535971039', '1535971039');
INSERT INTO `xt_action_log` VALUES ('1970', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：接口管理', '/c8903/public/menu/menuedit.html', '1', '1535971048', '1535971048');
INSERT INTO `xt_action_log` VALUES ('1971', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：服务管理', '/c8903/public/menu/menuedit.html', '1', '1535971054', '1535971054');
INSERT INTO `xt_action_log` VALUES ('1972', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：新闻公告管理', '/c8903/public/menu/menuedit.html', '1', '1535971068', '1535971068');
INSERT INTO `xt_action_log` VALUES ('1973', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：公告管理', '/c8903/public/menu/menuedit.html', '1', '1535971086', '1535971086');
INSERT INTO `xt_action_log` VALUES ('1974', '1', '100000', '192.168.0.103', '数据排序', '数据排序调整，model：Menu，id：75，value：5', '/c8903/public/menu/setsort.html', '1', '1535971110', '1535971110');
INSERT INTO `xt_action_log` VALUES ('1975', '1', '100000', '192.168.0.103', '数据排序', '数据排序调整，model：Menu，id：69，value：10', '/c8903/public/menu/setsort.html', '1', '1535971152', '1535971152');
INSERT INTO `xt_action_log` VALUES ('1976', '1', '100000', '192.168.0.103', '数据排序', '数据排序调整，model：Menu，id：170，value：11', '/c8903/public/menu/setsort.html', '1', '1535971158', '1535971158');
INSERT INTO `xt_action_log` VALUES ('1977', '1', '100000', '192.168.0.103', '数据排序', '数据排序调整，model：Menu，id：209，value：9', '/c8903/public/menu/setsort.html', '1', '1535971174', '1535971174');
INSERT INTO `xt_action_log` VALUES ('1978', '1', '100000', '192.168.0.103', '新增', '新增菜单，name：新闻公告', '/c8903/public/menu/menuadd.html', '1', '1535971273', '1535971273');
INSERT INTO `xt_action_log` VALUES ('1979', '1', '100000', '192.168.0.103', '编辑', '文章编辑，name：312312321312', '/c8903/public/article/articleedit.html', '1', '1535971435', '1535971435');
INSERT INTO `xt_action_log` VALUES ('1980', '1', '100000', '192.168.0.103', '新增', '新增菜单，name：邮箱', '/c8903/public/menu/menuadd.html', '1', '1535971624', '1535971624');
INSERT INTO `xt_action_log` VALUES ('1981', '1', '100000', '192.168.0.103', '新增', '新增菜单，name：收件箱', '/c8903/public/menu/menuadd.html', '1', '1535971652', '1535971652');
INSERT INTO `xt_action_log` VALUES ('1982', '1', '100000', '192.168.0.103', '新增', '新增菜单，name：发件箱', '/c8903/public/menu/menuadd.html', '1', '1535971664', '1535971664');
INSERT INTO `xt_action_log` VALUES ('1983', '1', '100000', '192.168.0.103', '新增', '新增菜单，name：写邮件', '/c8903/public/menu/menuadd.html', '1', '1535971675', '1535971675');
INSERT INTO `xt_action_log` VALUES ('1984', '1', '100000', '192.168.0.103', '数据排序', '数据排序调整，model：Menu，id：230，value：1', '/c8903/public/menu/setsort.html', '1', '1535971806', '1535971806');
INSERT INTO `xt_action_log` VALUES ('1985', '1', '100000', '192.168.0.103', '数据排序', '数据排序调整，model：Menu，id：231，value：1', '/c8903/public/menu/setsort.html', '1', '1535971815', '1535971815');
INSERT INTO `xt_action_log` VALUES ('1986', '1', '100000', '192.168.0.103', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1535971923', '1535971923');
INSERT INTO `xt_action_log` VALUES ('1987', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：会员充值', '/c8903/public/menu/menuedit.html', '1', '1535972305', '1535972305');
INSERT INTO `xt_action_log` VALUES ('1988', '1', '100000', '192.168.0.103', '新增', '新增菜单，name：奖金明细', '/c8903/public/menu/menuadd.html', '1', '1535972688', '1535972688');
INSERT INTO `xt_action_log` VALUES ('1989', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：奖金明细', '/c8903/public/menu/menuedit.html', '1', '1535972711', '1535972711');
INSERT INTO `xt_action_log` VALUES ('1990', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：奖金明细', '/c8903/public/menu/menuedit.html', '1', '1535972759', '1535972759');
INSERT INTO `xt_action_log` VALUES ('1991', '1', '100000', '192.168.0.103', '数据排序', '数据排序调整，model：Menu，id：234，value：1', '/c8903/public/menu/setsort.html', '1', '1535973618', '1535973618');
INSERT INTO `xt_action_log` VALUES ('1992', '1', '100000', '192.168.0.103', '新增', '新增会员，username：1000001', '/c8903/public/index/member_add.html', '1', '1535976662', '1535976662');
INSERT INTO `xt_action_log` VALUES ('1993', '1', '100000', '192.168.0.103', '新增', '新增菜单，name：充值', '/c8903/public/menu/menuadd.html', '1', '1536025887', '1536025887');
INSERT INTO `xt_action_log` VALUES ('1994', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：充值', '/c8903/public/menu/menuedit.html', '1', '1536027493', '1536027493');
INSERT INTO `xt_action_log` VALUES ('1995', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：会员充值', '/c8903/public/menu/menuedit.html', '1', '1536028784', '1536028784');
INSERT INTO `xt_action_log` VALUES ('1996', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：会员充值', '/c8903/public/menu/menuedit.html', '1', '1536028816', '1536028816');
INSERT INTO `xt_action_log` VALUES ('1997', '1', '100000', '192.168.0.103', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536029380', '1536029380');
INSERT INTO `xt_action_log` VALUES ('1998', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：会员充值', '/c8903/public/menu/menuedit.html', '1', '1536029508', '1536029508');
INSERT INTO `xt_action_log` VALUES ('1999', '1', '100000', '192.168.0.103', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536030240', '1536030240');
INSERT INTO `xt_action_log` VALUES ('2000', '1', '100000', '192.168.0.144', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536030368', '1536030368');
INSERT INTO `xt_action_log` VALUES ('2001', '1', '100000', '192.168.0.103', '新增', '新增菜单，name：会员激活', '/c8903/public/menu/menuadd.html', '1', '1536030963', '1536030963');
INSERT INTO `xt_action_log` VALUES ('2002', '1', '100000', '192.168.0.103', '数据排序', '数据排序调整，model：Menu，id：239，value：1', '/c8903/public/menu/setsort.html', '1', '1536030978', '1536030978');
INSERT INTO `xt_action_log` VALUES ('2003', '1', '100000', '192.168.0.103', '数据排序', '数据排序调整，model：Menu，id：234，value：3', '/c8903/public/menu/setsort.html', '1', '1536031025', '1536031025');
INSERT INTO `xt_action_log` VALUES ('2004', '1', '100000', '192.168.0.103', '数据排序', '数据排序调整，model：Menu，id：230，value：2', '/c8903/public/menu/setsort.html', '1', '1536031040', '1536031040');
INSERT INTO `xt_action_log` VALUES ('2005', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：充值', '/c8903/public/menu/menuedit.html', '1', '1536031218', '1536031218');
INSERT INTO `xt_action_log` VALUES ('2006', '1', '100000', '192.168.0.103', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536031307', '1536031307');
INSERT INTO `xt_action_log` VALUES ('2007', '1', '100000', '192.168.0.103', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536039082', '1536039082');
INSERT INTO `xt_action_log` VALUES ('2008', '1', '100000', '192.168.0.103', '新增', '新增会员，username：12323123', '/c8903/public/index/member_add.html', '1', '1536042509', '1536042509');
INSERT INTO `xt_action_log` VALUES ('2009', '1', '100000', '192.168.0.103', '删除', '删除会员，where：id=1099', '/c8903/public/member/memberdel/id/1099.html', '1', '1536043048', '1536043048');
INSERT INTO `xt_action_log` VALUES ('2010', '1', '100000', '192.168.0.103', '删除', '删除会员，where：id=1099', '/c8903/public/member/memberdel/id/1099.html', '1', '1536043051', '1536043051');
INSERT INTO `xt_action_log` VALUES ('2011', '1', '100000', '192.168.0.103', '删除', '删除会员，where：id=1100', '/c8903/public/member/memberdel/id/1100.html', '1', '1536043055', '1536043055');
INSERT INTO `xt_action_log` VALUES ('2012', '1', '100000', '192.168.0.103', '删除', '删除会员，where：id=1101', '/c8903/public/member/memberdel/id/1101.html', '1', '1536043059', '1536043059');
INSERT INTO `xt_action_log` VALUES ('2013', '1', '100000', '192.168.0.103', '新增', '新增会员，username：111111', '/c8903/public/index/member_add.html', '1', '1536043481', '1536043481');
INSERT INTO `xt_action_log` VALUES ('2014', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：会员激活', '/c8903/public/menu/menuedit.html', '1', '1536043817', '1536043817');
INSERT INTO `xt_action_log` VALUES ('2015', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：会员激活', '/c8903/public/menu/menuedit.html', '1', '1536043848', '1536043848');
INSERT INTO `xt_action_log` VALUES ('2016', '1', '100000', '192.168.0.103', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536046808', '1536046808');
INSERT INTO `xt_action_log` VALUES ('2017', '1', '100000', '192.168.0.103', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536047208', '1536047208');
INSERT INTO `xt_action_log` VALUES ('2018', '1', '100000', '192.168.0.103', '新增', '新增会员，username：222222', '/c8903/public/index/member_add.html', '1', '1536047878', '1536047878');
INSERT INTO `xt_action_log` VALUES ('2019', '1', '100000', '192.168.0.103', '新增', '新增会员，username：2222222', '/c8903/public/index/member_add.html', '1', '1536047886', '1536047886');
INSERT INTO `xt_action_log` VALUES ('2020', '1', '100000', '192.168.0.103', '新增', '新增会员，username：1232323', '/c8903/public/index/member_add.html', '1', '1536047988', '1536047988');
INSERT INTO `xt_action_log` VALUES ('2021', '1', '100000', '192.168.0.103', '新增', '新增会员，username：12323236', '/c8903/public/index/member_add.html', '1', '1536048070', '1536048070');
INSERT INTO `xt_action_log` VALUES ('2022', '1', '100000', '192.168.0.103', '新增', '新增会员，username：12323236e', '/c8903/public/index/member_add.html', '1', '1536048274', '1536048274');
INSERT INTO `xt_action_log` VALUES ('2023', '1', '100000', '192.168.0.103', '新增', '新增会员，username：12323236e41', '/c8903/public/index/member_add.html', '1', '1536048378', '1536048378');
INSERT INTO `xt_action_log` VALUES ('2024', '1', '100000', '192.168.0.103', '新增', '新增会员，username：12323236e413', '/c8903/public/index/member_add.html', '1', '1536048440', '1536048440');
INSERT INTO `xt_action_log` VALUES ('2025', '1', '100000', '192.168.0.103', '新增', '新增会员，username：12323236e4133', '/c8903/public/index/member_add.html', '1', '1536048452', '1536048452');
INSERT INTO `xt_action_log` VALUES ('2026', '1', '100000', '192.168.0.103', '新增', '新增会员，username：12323236e4w133', '/c8903/public/index/member_add.html', '1', '1536048522', '1536048522');
INSERT INTO `xt_action_log` VALUES ('2027', '1', '100000', '192.168.0.103', '新增', '新增会员，username：12323236e4w1w33', '/c8903/public/index/member_add.html', '1', '1536048551', '1536048551');
INSERT INTO `xt_action_log` VALUES ('2028', '1', '100000', '192.168.0.103', '新增', '新增会员，username：12323236e4w1w3w3', '/c8903/public/index/member_add.html', '1', '1536048561', '1536048561');
INSERT INTO `xt_action_log` VALUES ('2029', '1', '100000', '192.168.0.103', '新增', '新增会员，username：12323236e4w1w3w3', '/c8903/public/index/member_add.html', '1', '1536048589', '1536048589');
INSERT INTO `xt_action_log` VALUES ('2030', '1', '100000', '192.168.0.103', '新增', '新增会员，username：12323236e4w1w3w3', '/c8903/public/index/member_add.html', '1', '1536048590', '1536048590');
INSERT INTO `xt_action_log` VALUES ('2031', '1', '100000', '192.168.0.103', '新增', '新增会员，username：12323236e4w1w3w3', '/c8903/public/index/member_add.html', '1', '1536048590', '1536048590');
INSERT INTO `xt_action_log` VALUES ('2032', '1', '100000', '192.168.0.103', '新增', '新增会员，username：12323236e4w1w3w3', '/c8903/public/index/member_add.html', '1', '1536048591', '1536048591');
INSERT INTO `xt_action_log` VALUES ('2033', '1', '100000', '192.168.0.103', '新增', '新增会员，username：12323236e4w1w3w3', '/c8903/public/index/member_add.html', '1', '1536048592', '1536048592');
INSERT INTO `xt_action_log` VALUES ('2034', '1', '100000', '192.168.0.103', '新增', '新增会员，username：12323236e4w1w3w3', '/c8903/public/index/member_add.html', '1', '1536048592', '1536048592');
INSERT INTO `xt_action_log` VALUES ('2035', '1', '100000', '192.168.0.103', '新增', '新增会员，username：111111', '/c8903/public/index/member_add.html', '1', '1536049183', '1536049183');
INSERT INTO `xt_action_log` VALUES ('2036', '1', '100000', '192.168.0.103', '授权', '设置权限组权限，id：1', '/c8903/public/auth/menuauth.html', '1', '1536049311', '1536049311');
INSERT INTO `xt_action_log` VALUES ('2037', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：会员添加', '/c8903/public/menu/menuedit.html', '1', '1536051254', '1536051254');
INSERT INTO `xt_action_log` VALUES ('2038', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：会员添加', '/c8903/public/menu/menuedit.html', '1', '1536051284', '1536051284');
INSERT INTO `xt_action_log` VALUES ('2039', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：会员添加', '/c8903/public/menu/menuedit.html', '1', '1536051303', '1536051303');
INSERT INTO `xt_action_log` VALUES ('2040', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536051980', '1536051980');
INSERT INTO `xt_action_log` VALUES ('2041', '1', '100000', '127.0.0.1', '新增', '新增菜单，name：配置列表', '/c8903/public/menu/menuadd.html', '1', '1536052149', '1536052149');
INSERT INTO `xt_action_log` VALUES ('2042', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536052191', '1536052191');
INSERT INTO `xt_action_log` VALUES ('2043', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536052199', '1536052199');
INSERT INTO `xt_action_log` VALUES ('2044', '1', '100000', '127.0.0.1', '新增', '新增会员，username：111111', '/c8903/public/index/member_add.html', '1', '1536059124', '1536059124');
INSERT INTO `xt_action_log` VALUES ('2045', '1', '100000', '127.0.0.1', '新增', '新增会员，username：111111', '/c8903/public/index/member_add.html', '1', '1536059567', '1536059567');
INSERT INTO `xt_action_log` VALUES ('2046', '1', '100000', '127.0.0.1', '新增', '新增会员，username：111111', '/c8903/public/index/member_add.html', '1', '1536059634', '1536059634');
INSERT INTO `xt_action_log` VALUES ('2047', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536060396', '1536060396');
INSERT INTO `xt_action_log` VALUES ('2048', '1', '100000', '127.0.0.1', '新增', '新增会员，username：111111', '/c8903/public/index/member_add.html', '1', '1536060431', '1536060431');
INSERT INTO `xt_action_log` VALUES ('2049', '1126', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/c8903/public/login/loginhandle.html', '1', '1536060458', '1536060458');
INSERT INTO `xt_action_log` VALUES ('2050', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536060486', '1536060486');
INSERT INTO `xt_action_log` VALUES ('2051', '1', '100000', '127.0.0.1', '删除', '删除权限组，where：id=1', '/c8903/public/auth/groupdel/id/1.html', '1', '1536060525', '1536060525');
INSERT INTO `xt_action_log` VALUES ('2052', '1', '100000', '127.0.0.1', '新增', '新增权限组，name：1232', '/c8903/public/auth/groupadd.html', '1', '1536060680', '1536060680');
INSERT INTO `xt_action_log` VALUES ('2053', '1', '100000', '127.0.0.1', '授权', '设置权限组权限，id：3', '/c8903/public/auth/menuauth.html', '1', '1536060703', '1536060703');
INSERT INTO `xt_action_log` VALUES ('2054', '1', '100000', '127.0.0.1', '新增', '新增会员，username：222222', '/c8903/public/index/member_add.html', '1', '1536061443', '1536061443');
INSERT INTO `xt_action_log` VALUES ('2055', '1127', '222222', '127.0.0.1', '登录', '登录操作，username：222222', '/c8903/public/login/loginhandle.html', '1', '1536061475', '1536061475');
INSERT INTO `xt_action_log` VALUES ('2056', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536061612', '1536061612');
INSERT INTO `xt_action_log` VALUES ('2057', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536061636', '1536061636');
INSERT INTO `xt_action_log` VALUES ('2058', '1', '100000', '127.0.0.1', '新增', '新增会员，username：111111', '/c8903/public/index/member_add.html', '1', '1536061665', '1536061665');
INSERT INTO `xt_action_log` VALUES ('2059', '1128', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/c8903/public/login/loginhandle.html', '1', '1536061688', '1536061688');
INSERT INTO `xt_action_log` VALUES ('2060', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536061715', '1536061715');
INSERT INTO `xt_action_log` VALUES ('2061', '1', '100000', '127.0.0.1', '新增', '新增权限组，name：报单中心', '/c8903/public/auth/groupadd.html', '1', '1536062691', '1536062691');
INSERT INTO `xt_action_log` VALUES ('2062', '1', '100000', '127.0.0.1', '编辑', '编辑权限组，name：普通会员', '/c8903/public/auth/groupedit.html', '1', '1536062702', '1536062702');
INSERT INTO `xt_action_log` VALUES ('2063', '1', '100000', '127.0.0.1', '授权', '设置权限组权限，id：3', '/c8903/public/auth/menuauth.html', '1', '1536062740', '1536062740');
INSERT INTO `xt_action_log` VALUES ('2064', '1', '100000', '127.0.0.1', '授权', '设置权限组权限，id：4', '/c8903/public/auth/menuauth.html', '1', '1536062776', '1536062776');
INSERT INTO `xt_action_log` VALUES ('2065', '1', '100000', '127.0.0.1', '新增', '新增会员，username：222222', '/c8903/public/index/member_add.html', '1', '1536063170', '1536063170');
INSERT INTO `xt_action_log` VALUES ('2066', '1', '100000', '127.0.0.1', '新增', '新增会员，username：2222222', '/c8903/public/index/member_add.html', '1', '1536108254', '1536108254');
INSERT INTO `xt_action_log` VALUES ('2067', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：vip_level', '/c8903/public/config/configedit.html', '1', '1536109229', '1536109229');
INSERT INTO `xt_action_log` VALUES ('2068', '1', '100000', '127.0.0.1', '新增', '新增配置，name：is_agent', '/c8903/public/config/configadd.html', '1', '1536109819', '1536109819');
INSERT INTO `xt_action_log` VALUES ('2069', '1', '100000', '127.0.0.1', '新增', '新增会员，username：111111', '/c8903/public/index/member_add.html', '1', '1536109935', '1536109935');
INSERT INTO `xt_action_log` VALUES ('2070', '1', '100000', '127.0.0.1', '新增', '新增会员，username：222222', '/c8903/public/index/member_add.html', '1', '1536109953', '1536109953');
INSERT INTO `xt_action_log` VALUES ('2071', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536110074', '1536110074');
INSERT INTO `xt_action_log` VALUES ('2072', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536110080', '1536110080');
INSERT INTO `xt_action_log` VALUES ('2073', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536110110', '1536110110');
INSERT INTO `xt_action_log` VALUES ('2074', '1', '100000', '127.0.0.1', '新增', '新增配置，name：s_ratio', '/c8903/public/config/configadd.html', '1', '1536110316', '1536110316');
INSERT INTO `xt_action_log` VALUES ('2075', '1', '100000', '127.0.0.1', '数据状态', '数据状态调整，model：Config，ids：72，status：-1', '/c8903/public/config/setstatus/ids/72/status/-1.html', '1', '1536110329', '1536110329');
INSERT INTO `xt_action_log` VALUES ('2076', '1', '100000', '127.0.0.1', '新增', '新增配置，name：everyday_time', '/c8903/public/config/configadd.html', '1', '1536110905', '1536110905');
INSERT INTO `xt_action_log` VALUES ('2077', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：everyday_time', '/c8903/public/config/configedit.html', '1', '1536110997', '1536110997');
INSERT INTO `xt_action_log` VALUES ('2078', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：everyday_time', '/c8903/public/config/configedit.html', '1', '1536111172', '1536111172');
INSERT INTO `xt_action_log` VALUES ('2079', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：everyday_time', '/c8903/public/config/configedit.html', '1', '1536111272', '1536111272');
INSERT INTO `xt_action_log` VALUES ('2080', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536112092', '1536112092');
INSERT INTO `xt_action_log` VALUES ('2081', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536112499', '1536112499');
INSERT INTO `xt_action_log` VALUES ('2082', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536112842', '1536112842');
INSERT INTO `xt_action_log` VALUES ('2083', '1', '100000', '127.0.0.1', '新增', '新增会员，username：18799', '/c8903/public/index/member_add.html', '1', '1536113979', '1536113979');
INSERT INTO `xt_action_log` VALUES ('2084', '1', '100000', '127.0.0.1', '新增', '新增会员，username：617767', '/c8903/public/index/member_add.html', '1', '1536114102', '1536114102');
INSERT INTO `xt_action_log` VALUES ('2085', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536114578', '1536114578');
INSERT INTO `xt_action_log` VALUES ('2086', '1', '100000', '127.0.0.1', '新增', '新增配置，name：junc', '/c8903/public/config/configadd.html', '1', '1536121084', '1536121084');
INSERT INTO `xt_action_log` VALUES ('2087', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536121120', '1536121120');
INSERT INTO `xt_action_log` VALUES ('2088', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：reco', '/c8903/public/config/configedit.html', '1', '1536121134', '1536121134');
INSERT INTO `xt_action_log` VALUES ('2089', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：achievement', '/c8903/public/config/configedit.html', '1', '1536121203', '1536121203');
INSERT INTO `xt_action_log` VALUES ('2090', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536123113', '1536123113');
INSERT INTO `xt_action_log` VALUES ('2091', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536123317', '1536123317');
INSERT INTO `xt_action_log` VALUES ('2092', '1', '100000', '127.0.0.1', '新增', '新增配置，name： manage', '/c8903/public/config/configadd.html', '1', '1536124636', '1536124636');
INSERT INTO `xt_action_log` VALUES ('2093', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：everyday_time', '/c8903/public/config/configedit.html', '1', '1536124663', '1536124663');
INSERT INTO `xt_action_log` VALUES ('2094', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：static_domain', '/c8903/public/config/configedit.html', '1', '1536124701', '1536124701');
INSERT INTO `xt_action_log` VALUES ('2095', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：seo_title', '/c8903/public/config/configedit.html', '1', '1536124756', '1536124756');
INSERT INTO `xt_action_log` VALUES ('2096', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：loading_icon', '/c8903/public/config/configedit.html', '1', '1536124784', '1536124784');
INSERT INTO `xt_action_log` VALUES ('2097', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：seo_title', '/c8903/public/config/configedit.html', '1', '1536124800', '1536124800');
INSERT INTO `xt_action_log` VALUES ('2098', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：seo_keywords', '/c8903/public/config/configedit.html', '1', '1536124854', '1536124854');
INSERT INTO `xt_action_log` VALUES ('2099', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：seo_description', '/c8903/public/config/configedit.html', '1', '1536124866', '1536124866');
INSERT INTO `xt_action_log` VALUES ('2100', '1', '100000', '127.0.0.1', '新增', '新增配置，name：see_you', '/c8903/public/config/configadd.html', '1', '1536125806', '1536125806');
INSERT INTO `xt_action_log` VALUES ('2101', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：see_you', '/c8903/public/config/configedit.html', '1', '1536126037', '1536126037');
INSERT INTO `xt_action_log` VALUES ('2102', '1', '100000', '127.0.0.1', '新增', '新增配置，name：see_you_ratio', '/c8903/public/config/configadd.html', '1', '1536126087', '1536126087');
INSERT INTO `xt_action_log` VALUES ('2103', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：see_you', '/c8903/public/config/configedit.html', '1', '1536126099', '1536126099');
INSERT INTO `xt_action_log` VALUES ('2104', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：see_you_ratio', '/c8903/public/config/configedit.html', '1', '1536126815', '1536126815');
INSERT INTO `xt_action_log` VALUES ('2105', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：manage', '/c8903/public/config/configedit.html', '1', '1536127194', '1536127194');
INSERT INTO `xt_action_log` VALUES ('2106', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：treeplace', '/c8903/public/config/configedit.html', '1', '1536127968', '1536127968');
INSERT INTO `xt_action_log` VALUES ('2107', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536128951', '1536128951');
INSERT INTO `xt_action_log` VALUES ('2108', '1', '100000', '127.0.0.1', '新增', '新增会员，username：800811', '/c8903/public/index/member_add.html', '1', '1536129728', '1536129728');
INSERT INTO `xt_action_log` VALUES ('2109', '1134', '617767', '127.0.0.1', '登录', '登录操作，username：617767', '/c8903/public/login/loginhandle.html', '1', '1536130102', '1536130102');
INSERT INTO `xt_action_log` VALUES ('2110', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536130170', '1536130170');
INSERT INTO `xt_action_log` VALUES ('2111', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536130746', '1536130746');
INSERT INTO `xt_action_log` VALUES ('2112', '1', '100000', '127.0.0.1', '新增', '新增配置，name：agent_center', '/c8903/public/config/configadd.html', '1', '1536130873', '1536130873');
INSERT INTO `xt_action_log` VALUES ('2113', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：agent_center', '/c8903/public/config/configedit.html', '1', '1536130881', '1536130881');
INSERT INTO `xt_action_log` VALUES ('2114', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：agent_center', '/c8903/public/config/configedit.html', '1', '1536131086', '1536131086');
INSERT INTO `xt_action_log` VALUES ('2115', '1', '100000', '127.0.0.1', '新增', '新增配置，name：tax', '/c8903/public/config/configadd.html', '1', '1536132648', '1536132648');
INSERT INTO `xt_action_log` VALUES ('2116', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：tax', '/c8903/public/config/configedit.html', '1', '1536132656', '1536132656');
INSERT INTO `xt_action_log` VALUES ('2117', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536132811', '1536132811');
INSERT INTO `xt_action_log` VALUES ('2118', '1', '100000', '127.0.0.1', '新增', '新增会员，username：53437', '/c8903/public/index/member_add.html', '1', '1536133849', '1536133849');
INSERT INTO `xt_action_log` VALUES ('2119', '1', '100000', '127.0.0.1', '新增', '新增会员，username：685028', '/c8903/public/index/member_add.html', '1', '1536134633', '1536134633');
INSERT INTO `xt_action_log` VALUES ('2120', '1', '100000', '127.0.0.1', '新增', '新增会员，username：764709', '/c8903/public/index/member_add.html', '1', '1536134937', '1536134937');
INSERT INTO `xt_action_log` VALUES ('2121', '1', '100000', '127.0.0.1', '新增', '新增会员，username：448822', '/c8903/public/index/member_add.html', '1', '1536135598', '1536135598');
INSERT INTO `xt_action_log` VALUES ('2122', '1', '100000', '127.0.0.1', '新增', '新增会员，username：685425', '/c8903/public/index/member_add.html', '1', '1536135794', '1536135794');
INSERT INTO `xt_action_log` VALUES ('2123', '1', '100000', '127.0.0.1', '新增', '新增会员，username：332825', '/c8903/public/index/member_add.html', '1', '1536135847', '1536135847');
INSERT INTO `xt_action_log` VALUES ('2124', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536222497', '1536222497');
INSERT INTO `xt_action_log` VALUES ('2125', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536222573', '1536222573');
INSERT INTO `xt_action_log` VALUES ('2126', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536309160', '1536309160');
INSERT INTO `xt_action_log` VALUES ('2127', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536136665', '1536136665');
INSERT INTO `xt_action_log` VALUES ('2128', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536223178', '1536223178');
INSERT INTO `xt_action_log` VALUES ('2129', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536223230', '1536223230');
INSERT INTO `xt_action_log` VALUES ('2130', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536309666', '1536309666');
INSERT INTO `xt_action_log` VALUES ('2131', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536137188', '1536137188');
INSERT INTO `xt_action_log` VALUES ('2132', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：货币流向', '/c8903/public/menu/menuedit.html', '1', '1536137950', '1536137950');
INSERT INTO `xt_action_log` VALUES ('2133', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：货币流向', '/c8903/public/menu/menuedit.html', '1', '1536138149', '1536138149');
INSERT INTO `xt_action_log` VALUES ('2134', '1', '100000', '127.0.0.1', '新增', '新增会员，username：679291', '/c8903/public/index/member_add.html', '1', '1536141112', '1536141112');
INSERT INTO `xt_action_log` VALUES ('2135', '1', '100000', '127.0.0.1', '新增', '新增会员，username：497559', '/c8903/public/index/member_add.html', '1', '1536141232', '1536141232');
INSERT INTO `xt_action_log` VALUES ('2136', '1', '100000', '192.168.0.115', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536141315', '1536141315');
INSERT INTO `xt_action_log` VALUES ('2137', '1', '100000', '127.0.0.1', '删除', '文章分类删除，where：id=7', '/c8903/public/article/articlecategorydel/id/7.html', '1', '1536146329', '1536146329');
INSERT INTO `xt_action_log` VALUES ('2138', '1', '100000', '127.0.0.1', '编辑', '文章编辑，name：312312321312', '/c8903/public/article/articleedit.html', '1', '1536146339', '1536146339');
INSERT INTO `xt_action_log` VALUES ('2139', '1', '100000', '127.0.0.1', '导出', '导出会员列表', '/c8903/public/member/exportmemberlist.html?', '1', '1536146482', '1536146482');
INSERT INTO `xt_action_log` VALUES ('2140', '1', '100000', '127.0.0.1', '导出', '导出会员列表', '/c8903/public/member/exportmemberlist.html?', '1', '1536146495', '1536146495');
INSERT INTO `xt_action_log` VALUES ('2141', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：关系图', '/c8903/public/menu/menuedit.html', '1', '1536194662', '1536194662');
INSERT INTO `xt_action_log` VALUES ('2142', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：注册账户', '/c8903/public/menu/menuedit.html', '1', '1536194702', '1536194702');
INSERT INTO `xt_action_log` VALUES ('2143', '1', '100000', '127.0.0.1', '新增', '新增菜单，name：会员财务', '/c8903/public/menu/menuadd.html', '1', '1536194839', '1536194839');
INSERT INTO `xt_action_log` VALUES ('2144', '1', '100000', '127.0.0.1', '新增', '新增菜单，name：会员资讯', '/c8903/public/menu/menuadd.html', '1', '1536194878', '1536194878');
INSERT INTO `xt_action_log` VALUES ('2145', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：财务明细', '/c8903/public/menu/menuedit.html', '1', '1536194901', '1536194901');
INSERT INTO `xt_action_log` VALUES ('2146', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：奖金明细', '/c8903/public/menu/menuedit.html', '1', '1536194918', '1536194918');
INSERT INTO `xt_action_log` VALUES ('2147', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：转账', '/c8903/public/menu/menuedit.html', '1', '1536194934', '1536194934');
INSERT INTO `xt_action_log` VALUES ('2148', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：充值', '/c8903/public/menu/menuedit.html', '1', '1536194951', '1536194951');
INSERT INTO `xt_action_log` VALUES ('2149', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：提现', '/c8903/public/menu/menuedit.html', '1', '1536194963', '1536194963');
INSERT INTO `xt_action_log` VALUES ('2150', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：新闻公告', '/c8903/public/menu/menuedit.html', '1', '1536194999', '1536194999');
INSERT INTO `xt_action_log` VALUES ('2151', '1', '100000', '127.0.0.1', '数据排序', '数据排序调整，model：Menu，id：1，value：0', '/c8903/public/menu/setsort.html', '1', '1536195068', '1536195068');
INSERT INTO `xt_action_log` VALUES ('2152', '1', '100000', '127.0.0.1', '数据排序', '数据排序调整，model：Menu，id：229，value：2', '/c8903/public/menu/setsort.html', '1', '1536195078', '1536195078');
INSERT INTO `xt_action_log` VALUES ('2153', '1', '100000', '127.0.0.1', '数据排序', '数据排序调整，model：Menu，id：242，value：3', '/c8903/public/menu/setsort.html', '1', '1536195085', '1536195085');
INSERT INTO `xt_action_log` VALUES ('2154', '1', '100000', '127.0.0.1', '数据排序', '数据排序调整，model：Menu，id：243，value：4', '/c8903/public/menu/setsort.html', '1', '1536195090', '1536195090');
INSERT INTO `xt_action_log` VALUES ('2155', '1', '100000', '127.0.0.1', '数据排序', '数据排序调整，model：Menu，id：198，value：5', '/c8903/public/menu/setsort.html', '1', '1536195119', '1536195119');
INSERT INTO `xt_action_log` VALUES ('2156', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：二维码分享', '/c8903/public/menu/menuedit.html', '1', '1536195197', '1536195197');
INSERT INTO `xt_action_log` VALUES ('2157', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536197611', '1536197611');
INSERT INTO `xt_action_log` VALUES ('2158', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：写邮件', '/c8903/public/menu/menuedit.html', '1', '1536197753', '1536197753');
INSERT INTO `xt_action_log` VALUES ('2159', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：发件箱', '/c8903/public/menu/menuedit.html', '1', '1536197852', '1536197852');
INSERT INTO `xt_action_log` VALUES ('2160', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：收件箱', '/c8903/public/menu/menuedit.html', '1', '1536197898', '1536197898');
INSERT INTO `xt_action_log` VALUES ('2161', '1', '100000', '192.168.0.112', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536203683', '1536203683');
INSERT INTO `xt_action_log` VALUES ('2162', '1', '100000', '192.168.0.115', '导出', '导出会员列表', '/c8903/public/member/exportmemberlist.html?', '1', '1536214588', '1536214588');
INSERT INTO `xt_action_log` VALUES ('2163', '1', '100000', '192.168.0.115', '导出', '导出会员列表', '/c8903/public/member/exportmemberlist.html?', '1', '1536215045', '1536215045');
INSERT INTO `xt_action_log` VALUES ('2164', '1', '100000', '192.168.0.115', '导出', '导出会员列表', '/c8903/public/member/exportmemberlist.html', '1', '1536215228', '1536215228');
INSERT INTO `xt_action_log` VALUES ('2165', '1', '100000', '192.168.0.115', '导出', '导出会员列表', '/c8903/public/member/exportmemberlist.html?', '1', '1536215261', '1536215261');
INSERT INTO `xt_action_log` VALUES ('2166', '1', '100000', '192.168.0.115', '导出', '导出会员列表', '/c8903/public/member/exportmemberlist.html?', '1', '1536215310', '1536215310');
INSERT INTO `xt_action_log` VALUES ('2167', '1', '100000', '192.168.0.115', '导出', '导出会员列表', '/c8903/public/member/exportmemberlist.html', '1', '1536217567', '1536217567');
INSERT INTO `xt_action_log` VALUES ('2168', '1', '100000', '192.168.0.115', '导出', '导出提现列表', '/c8903/public/member/exportdrawallist.html', '1', '1536217795', '1536217795');
INSERT INTO `xt_action_log` VALUES ('2169', '1', '100000', '192.168.0.115', '导出', '导出提现列表', '/c8903/public/member/exportdrawallist.html', '1', '1536217814', '1536217814');
INSERT INTO `xt_action_log` VALUES ('2170', '1', '100000', '192.168.0.115', '导出', '导出提现列表', '/c8903/public/member/exportdrawallist.html', '1', '1536218049', '1536218049');
INSERT INTO `xt_action_log` VALUES ('2171', '1', '100000', '192.168.0.115', '导出', '导出提现列表', '/c8903/public/member/exportdrawallist.html', '1', '1536218348', '1536218348');
INSERT INTO `xt_action_log` VALUES ('2172', '1', '100000', '192.168.0.115', '导出', '导出提现列表', '/c8903/public/member/exportdrawallist.html', '1', '1536218428', '1536218428');
INSERT INTO `xt_action_log` VALUES ('2173', '1', '100000', '192.168.0.115', '导出', '导出会员列表', '/c8903/public/member/exportmemberlist.html', '1', '1536218583', '1536218583');
INSERT INTO `xt_action_log` VALUES ('2174', '1', '100000', '192.168.0.115', '导出', '导出提现列表', '/c8903/public/member/exportdrawallist.html', '1', '1536219302', '1536219302');
INSERT INTO `xt_action_log` VALUES ('2175', '1', '100000', '192.168.0.115', '导出', '导出充值列表', '/c8903/public/member/exportchargelist.html', '1', '1536219391', '1536219391');
INSERT INTO `xt_action_log` VALUES ('2176', '1', '100000', '192.168.0.115', '导出', '导出提现列表', '/c8903/public/member/exportdrawallist.html', '1', '1536219468', '1536219468');
INSERT INTO `xt_action_log` VALUES ('2177', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536229673', '1536229673');
INSERT INTO `xt_action_log` VALUES ('2178', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：seo_keywords', '/c8903/public/config/configedit.html', '1', '1536230896', '1536230896');
INSERT INTO `xt_action_log` VALUES ('2179', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：seo_description', '/c8903/public/config/configedit.html', '1', '1536230913', '1536230913');
INSERT INTO `xt_action_log` VALUES ('2180', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：seo_title', '/c8903/public/config/configedit.html', '1', '1536230931', '1536230931');
INSERT INTO `xt_action_log` VALUES ('2181', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536230945', '1536230945');
INSERT INTO `xt_action_log` VALUES ('2182', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：seo_description', '/c8903/public/config/configedit.html', '1', '1536231253', '1536231253');
INSERT INTO `xt_action_log` VALUES ('2183', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：seo_description', '/c8903/public/config/configedit.html', '1', '1536231265', '1536231265');
INSERT INTO `xt_action_log` VALUES ('2184', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：seo_description', '/c8903/public/config/configedit.html', '1', '1536231283', '1536231283');
INSERT INTO `xt_action_log` VALUES ('2185', '1', '100000', '127.0.0.1', '新增', '新增配置，name：money_type', '/c8903/public/config/configadd.html', '1', '1536280719', '1536280719');
INSERT INTO `xt_action_log` VALUES ('2186', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：money_type', '/c8903/public/config/configedit.html', '1', '1536281044', '1536281044');
INSERT INTO `xt_action_log` VALUES ('2187', '1', '100000', '192.168.0.161', '数据排序', '数据排序调整，model：Config，id：73，value：1212101212', '/c8903/public/config/setsort.html', '1', '1536301993', '1536301993');
INSERT INTO `xt_action_log` VALUES ('2188', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536318625', '1536318625');
INSERT INTO `xt_action_log` VALUES ('2189', '1', '100000', '127.0.0.1', '新增', '新增会员，username：664215', '/c8903/public/index/member_add.html', '1', '1536366804', '1536366804');
INSERT INTO `xt_action_log` VALUES ('2190', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/c8903/public/member/memberedit.html', '1', '1536366895', '1536366895');
INSERT INTO `xt_action_log` VALUES ('2191', '1', '100000', '192.168.0.161', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536367414', '1536367414');
INSERT INTO `xt_action_log` VALUES ('2192', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：财务明细', '/c8903/public/menu/menuedit.html', '1', '1536367468', '1536367468');
INSERT INTO `xt_action_log` VALUES ('2193', '1', '100000', '127.0.0.1', '新增', '新增会员，username：336548', '/c8903/public/index/member_add.html', '1', '1536367829', '1536367829');
INSERT INTO `xt_action_log` VALUES ('2194', '1', '100000', '127.0.0.1', '新增', '文章新增，name：system1', '/c8903/public/article/articleadd.html', '1', '1536373286', '1536373286');
INSERT INTO `xt_action_log` VALUES ('2195', '1', '100000', '192.168.0.157', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536543922', '1536543922');
INSERT INTO `xt_action_log` VALUES ('2196', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536544127', '1536544127');
INSERT INTO `xt_action_log` VALUES ('2197', '1', '100000', '192.168.0.157', '还原', '数据库还原', '/c8903/public/database/datarestorehandle/time/1520506958.html', '1', '1536544175', '1536544175');
INSERT INTO `xt_action_log` VALUES ('2198', '1', '100000', '192.168.0.157', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536544301', '1536544301');
INSERT INTO `xt_action_log` VALUES ('2199', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536544339', '1536544339');
INSERT INTO `xt_action_log` VALUES ('2200', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：数据库', '/c8903/public/menu/menuedit.html', '1', '1536544401', '1536544401');
INSERT INTO `xt_action_log` VALUES ('2201', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：数据还原', '/c8903/public/menu/menuedit.html', '1', '1536544463', '1536544463');
INSERT INTO `xt_action_log` VALUES ('2202', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：数据库', '/c8903/public/menu/menuedit.html', '1', '1536544508', '1536544508');
INSERT INTO `xt_action_log` VALUES ('2203', '1', '100000', '127.0.0.1', '优化', '数据库优化', '/c8903/public/database/optimize.html', '1', '1536544547', '1536544547');
INSERT INTO `xt_action_log` VALUES ('2204', '1', '100000', '127.0.0.1', '备份', '数据库备份', '/c8903/public/database/databackup.html', '1', '1536544552', '1536544552');
INSERT INTO `xt_action_log` VALUES ('2205', '1', '100000', '192.168.0.157', '备份', '数据库备份', '/c8903/public/database/databackup.html', '1', '1536544646', '1536544646');
INSERT INTO `xt_action_log` VALUES ('2206', '1', '100000', '127.0.0.1', '备份', '数据库备份', '/c8903/public/database/databackup.html', '1', '1536544825', '1536544825');
INSERT INTO `xt_action_log` VALUES ('2207', '1', '100000', '192.168.0.157', '新增', '新增会员，username：1', '/c8903/public/index/member_add.html', '1', '1536545297', '1536545297');
INSERT INTO `xt_action_log` VALUES ('2208', '1', '100000', '127.0.0.1', '备份', '数据库备份', '/c8903/public/database/databackup.html', '1', '1536545680', '1536545680');
INSERT INTO `xt_action_log` VALUES ('2209', '1', '100000', '192.168.0.157', '新增', '新增会员，username：2', '/c8903/public/index/member_add.html', '1', '1536547436', '1536547436');
INSERT INTO `xt_action_log` VALUES ('2210', '1', '100000', '192.168.0.161', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536551623', '1536551623');
INSERT INTO `xt_action_log` VALUES ('2211', '1', '100000', '192.168.0.161', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536565219', '1536565219');
INSERT INTO `xt_action_log` VALUES ('2212', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536567291', '1536567291');
INSERT INTO `xt_action_log` VALUES ('2213', '1', '100000', '192.168.0.161', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536571465', '1536571465');
INSERT INTO `xt_action_log` VALUES ('2214', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536628433', '1536628433');
INSERT INTO `xt_action_log` VALUES ('2215', '1', '100000', '192.168.0.144', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536629037', '1536629037');
INSERT INTO `xt_action_log` VALUES ('2216', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536629388', '1536629388');
INSERT INTO `xt_action_log` VALUES ('2217', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536629779', '1536629779');
INSERT INTO `xt_action_log` VALUES ('2218', '1', '100000', '192.168.0.122', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536629866', '1536629866');
INSERT INTO `xt_action_log` VALUES ('2219', '1', '100000', '192.168.0.122', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536629972', '1536629972');
INSERT INTO `xt_action_log` VALUES ('2220', '1', '100000', '192.168.0.122', '新增', '新增配置，name：bank', '/c8903/public/config/configadd.html', '1', '1536631030', '1536631030');
INSERT INTO `xt_action_log` VALUES ('2221', '1', '100000', '127.0.0.1', '授权', '设置权限组权限，id：4', '/c8903/public/auth/menuauth.html', '1', '1536634073', '1536634073');
INSERT INTO `xt_action_log` VALUES ('2222', '1', '100000', '127.0.0.1', '授权', '设置权限组权限，id：3', '/c8903/public/auth/menuauth.html', '1', '1536634118', '1536634118');
INSERT INTO `xt_action_log` VALUES ('2223', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：权限管理', '/c8903/public/menu/menuedit.html', '1', '1536634172', '1536634172');
INSERT INTO `xt_action_log` VALUES ('2224', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536634259', '1536634259');
INSERT INTO `xt_action_log` VALUES ('2225', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536635078', '1536635078');
INSERT INTO `xt_action_log` VALUES ('2226', '1', '100000', '192.168.0.144', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536636547', '1536636547');
INSERT INTO `xt_action_log` VALUES ('2227', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536636616', '1536636616');
INSERT INTO `xt_action_log` VALUES ('2228', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536639481', '1536639481');
INSERT INTO `xt_action_log` VALUES ('2229', '1', '100000', '127.0.0.1', '新增', '新增会员，username：703705', '/c8903/public/index/member_add.html', '1', '1536639587', '1536639587');
INSERT INTO `xt_action_log` VALUES ('2230', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536639776', '1536639776');
INSERT INTO `xt_action_log` VALUES ('2231', '1', '100000', '127.0.0.1', '删除', '数据库备份文件删除，path：D:\\wamp64\\www\\c8903\\data\\20180308-190238-*.sql*', '/c8903/public/database/backupdel/time/1520506958.html', '1', '1536640049', '1536640049');
INSERT INTO `xt_action_log` VALUES ('2232', '1', '100000', '127.0.0.1', '删除', '数据库备份文件删除，path：D:\\wamp64\\www\\c8903\\data\\20180910-095552-*.sql*', '/c8903/public/database/backupdel/time/1536544552.html', '1', '1536640057', '1536640057');
INSERT INTO `xt_action_log` VALUES ('2233', '1', '100000', '127.0.0.1', '删除', '数据库备份文件删除，path：D:\\wamp64\\www\\c8903\\data\\20180910-095725-*.sql*', '/c8903/public/database/backupdel/time/1536544645.html', '1', '1536640061', '1536640061');
INSERT INTO `xt_action_log` VALUES ('2234', '1', '100000', '127.0.0.1', '新增', '新增会员，username：658691', '/c8903/public/index/member_add.html', '1', '1536640090', '1536640090');
INSERT INTO `xt_action_log` VALUES ('2235', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536641223', '1536641223');
INSERT INTO `xt_action_log` VALUES ('2236', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：菜单管理', '/c8903/public/menu/menuedit.html', '1', '1536641634', '1536641634');
INSERT INTO `xt_action_log` VALUES ('2237', '1', '100000', '192.168.0.144', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536646512', '1536646512');
INSERT INTO `xt_action_log` VALUES ('2238', '1', '100000', '192.168.0.157', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536653761', '1536653761');
INSERT INTO `xt_action_log` VALUES ('2239', '1', '100000', '192.168.0.157', '新增', '新增会员，username：2', '/c8903/public/index/member_add.html', '1', '1536654034', '1536654034');
INSERT INTO `xt_action_log` VALUES ('2240', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：7', '/c8903/public/member/memberedit.html', '1', '1536654704', '1536654704');
INSERT INTO `xt_action_log` VALUES ('2241', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：7', '/c8903/public/member/memberedit.html', '1', '1536654721', '1536654721');
INSERT INTO `xt_action_log` VALUES ('2242', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：7', '/c8903/public/member/memberedit.html', '1', '1536654730', '1536654730');
INSERT INTO `xt_action_log` VALUES ('2243', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：7', '/c8903/public/member/memberedit.html', '1', '1536654831', '1536654831');
INSERT INTO `xt_action_log` VALUES ('2244', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：7', '/c8903/public/member/memberedit.html', '1', '1536654840', '1536654840');
INSERT INTO `xt_action_log` VALUES ('2245', '1', '100000', '192.168.0.157', '新增', '新增会员，username：3', '/c8903/public/index/member_add.html', '1', '1536655127', '1536655127');
INSERT INTO `xt_action_log` VALUES ('2246', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/c8903/public/member/memberedit.html', '1', '1536655174', '1536655174');
INSERT INTO `xt_action_log` VALUES ('2247', '1', '100000', '192.168.0.157', '新增', '新增会员，username：4', '/c8903/public/index/member_add.html', '1', '1536655260', '1536655260');
INSERT INTO `xt_action_log` VALUES ('2248', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/c8903/public/member/memberedit.html', '1', '1536655493', '1536655493');
INSERT INTO `xt_action_log` VALUES ('2249', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/c8903/public/member/memberedit.html', '1', '1536655529', '1536655529');
INSERT INTO `xt_action_log` VALUES ('2250', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：流水明细', '/c8903/public/menu/menuedit.html', '1', '1536656443', '1536656443');
INSERT INTO `xt_action_log` VALUES ('2251', '1', '100000', '127.0.0.1', '新增', '新增菜单，name：手动业绩奖', '/c8903/public/menu/menuadd.html', '1', '1536656745', '1536656745');
INSERT INTO `xt_action_log` VALUES ('2252', '1', '100000', '127.0.0.1', '数据排序', '数据排序调整，model：Menu，id：244，value：11', '/c8903/public/menu/setsort.html', '1', '1536656793', '1536656793');
INSERT INTO `xt_action_log` VALUES ('2253', '1', '100000', '127.0.0.1', '新增', '新增会员，username：943603', '/c8903/public/index/member_add.html', '1', '1536657090', '1536657090');
INSERT INTO `xt_action_log` VALUES ('2254', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：菜单管理', '/c8903/public/menu/menuedit.html', '1', '1536657621', '1536657621');
INSERT INTO `xt_action_log` VALUES ('2255', '1', '100000', '127.0.0.1', '新增', '新增配置，name：poundage', '/c8903/public/config/configadd.html', '1', '1536657697', '1536657697');
INSERT INTO `xt_action_log` VALUES ('2256', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：poundage', '/c8903/public/config/configedit.html', '1', '1536657741', '1536657741');
INSERT INTO `xt_action_log` VALUES ('2257', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536662533', '1536662533');
INSERT INTO `xt_action_log` VALUES ('2258', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536663306', '1536663306');
INSERT INTO `xt_action_log` VALUES ('2259', '1', '100000', '192.168.0.157', '新增', '新增会员，username：1', '/c8903/public/index/member_add.html', '1', '1536664052', '1536664052');
INSERT INTO `xt_action_log` VALUES ('2260', '1', '100000', '127.0.0.1', '新增', '新增会员，username：274933', '/c8903/public/index/member_add.html', '1', '1536664476', '1536664476');
INSERT INTO `xt_action_log` VALUES ('2261', '1', '100000', '192.168.0.157', '新增', '新增会员，username：1', '/c8903/public/index/member_add.html', '1', '1536664823', '1536664823');
INSERT INTO `xt_action_log` VALUES ('2262', '1', '100000', '192.168.0.157', '新增', '新增会员，username：2', '/c8903/public/index/member_add.html', '1', '1536664954', '1536664954');
INSERT INTO `xt_action_log` VALUES ('2263', '1', '100000', '192.168.0.157', '新增', '新增会员，username：3', '/c8903/public/index/member_add.html', '1', '1536664998', '1536664998');
INSERT INTO `xt_action_log` VALUES ('2264', '1', '100000', '192.168.0.157', '新增', '新增会员，username：4', '/c8903/public/index/member_add.html', '1', '1536665028', '1536665028');
INSERT INTO `xt_action_log` VALUES ('2265', '1', '100000', '192.168.0.157', '还原', '数据库还原', '/c8903/public/database/datarestorehandle/time/1536665046.html', '1', '1536724284', '1536724284');
INSERT INTO `xt_action_log` VALUES ('2266', '1', '100000', '192.168.0.157', '新增', '新增会员，username：1', '/c8903/public/index/member_add.html', '1', '1536724404', '1536724404');
INSERT INTO `xt_action_log` VALUES ('2267', '1', '100000', '192.168.0.157', '新增', '新增会员，username：2', '/c8903/public/index/member_add.html', '1', '1536724428', '1536724428');
INSERT INTO `xt_action_log` VALUES ('2268', '1', '100000', '192.168.0.157', '新增', '新增会员，username：3', '/c8903/public/index/member_add.html', '1', '1536724460', '1536724460');
INSERT INTO `xt_action_log` VALUES ('2269', '1', '100000', '192.168.0.157', '新增', '新增会员，username：4', '/c8903/public/index/member_add.html', '1', '1536724501', '1536724501');
INSERT INTO `xt_action_log` VALUES ('2270', '1', '100000', '192.168.0.157', '新增', '新增会员，username：1', '/c8903/public/index/member_add.html', '1', '1536724607', '1536724607');
INSERT INTO `xt_action_log` VALUES ('2271', '1', '100000', '192.168.0.157', '新增', '新增会员，username：2', '/c8903/public/index/member_add.html', '1', '1536724626', '1536724626');
INSERT INTO `xt_action_log` VALUES ('2272', '1', '100000', '192.168.0.157', '新增', '新增会员，username：3', '/c8903/public/index/member_add.html', '1', '1536724688', '1536724688');
INSERT INTO `xt_action_log` VALUES ('2273', '1', '100000', '192.168.0.157', '新增', '新增会员，username：4', '/c8903/public/index/member_add.html', '1', '1536724723', '1536724723');
INSERT INTO `xt_action_log` VALUES ('2274', '1', '100000', '192.168.0.157', '备份', '数据库备份', '/c8903/public/database/databackup.html', '1', '1536724755', '1536724755');
INSERT INTO `xt_action_log` VALUES ('2275', '1', '100000', '192.168.0.157', '新增', '新增会员，username：5', '/c8903/public/index/member_add.html', '1', '1536724907', '1536724907');
INSERT INTO `xt_action_log` VALUES ('2276', '26', '1', '127.0.0.1', '登录', '登录操作，username：1', '/c8903/public/login/loginhandle.html', '1', '1536726896', '1536726896');
INSERT INTO `xt_action_log` VALUES ('2277', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536726947', '1536726947');
INSERT INTO `xt_action_log` VALUES ('2278', '1', '100000', '127.0.0.1', '新增', '新增会员，username：412750', '/c8903/public/index/member_add.html', '1', '1536727012', '1536727012');
INSERT INTO `xt_action_log` VALUES ('2279', '26', '1', '127.0.0.1', '登录', '登录操作，username：1', '/c8903/public/login/loginhandle.html', '1', '1536727544', '1536727544');
INSERT INTO `xt_action_log` VALUES ('2280', '26', '1', '127.0.0.1', '新增', '新增会员，username：540955', '/c8903/public/index/member_add.html', '1', '1536728207', '1536728207');
INSERT INTO `xt_action_log` VALUES ('2281', '26', '1', '127.0.0.1', '登录', '登录操作，username：1', '/c8903/public/login/loginhandle.html', '1', '1536728272', '1536728272');
INSERT INTO `xt_action_log` VALUES ('2282', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536728314', '1536728314');
INSERT INTO `xt_action_log` VALUES ('2283', '26', '1', '127.0.0.1', '登录', '登录操作，username：1', '/c8903/public/login/loginhandle.html', '1', '1536728442', '1536728442');
INSERT INTO `xt_action_log` VALUES ('2284', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536728478', '1536728478');
INSERT INTO `xt_action_log` VALUES ('2285', '26', '1', '127.0.0.1', '登录', '登录操作，username：1', '/c8903/public/login/loginhandle.html', '1', '1536728519', '1536728519');
INSERT INTO `xt_action_log` VALUES ('2286', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536728542', '1536728542');
INSERT INTO `xt_action_log` VALUES ('2287', '1', '100000', '127.0.0.1', '授权', '设置权限组权限，id：3', '/c8903/public/auth/menuauth.html', '1', '1536728570', '1536728570');
INSERT INTO `xt_action_log` VALUES ('2288', '26', '1', '127.0.0.1', '登录', '登录操作，username：1', '/c8903/public/login/loginhandle.html', '1', '1536728584', '1536728584');
INSERT INTO `xt_action_log` VALUES ('2289', '26', '1', '127.0.0.1', '登录', '登录操作，username：1', '/c8903/public/login/loginhandle.html', '1', '1536728618', '1536728618');
INSERT INTO `xt_action_log` VALUES ('2290', '27', '2', '127.0.0.1', '登录', '登录操作，username：2', '/c8903/public/login/loginhandle.html', '1', '1536728650', '1536728650');
INSERT INTO `xt_action_log` VALUES ('2291', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536728669', '1536728669');
INSERT INTO `xt_action_log` VALUES ('2292', '1', '100000', '127.0.0.1', '数据排序', '数据排序调整，model：Menu，id：168，value：21', '/c8903/public/menu/setsort.html', '1', '1536728867', '1536728867');
INSERT INTO `xt_action_log` VALUES ('2293', '1', '100000', '127.0.0.1', '数据排序', '数据排序调整，model：Menu，id：69，value：18', '/c8903/public/menu/setsort.html', '1', '1536728887', '1536728887');
INSERT INTO `xt_action_log` VALUES ('2294', '1', '100000', '127.0.0.1', '数据排序', '数据排序调整，model：Menu，id：245，value：10', '/c8903/public/menu/setsort.html', '1', '1536728904', '1536728904');
INSERT INTO `xt_action_log` VALUES ('2295', '1', '100000', '127.0.0.1', '数据排序', '数据排序调整，model：Menu，id：244，value：9', '/c8903/public/menu/setsort.html', '1', '1536728936', '1536728936');
INSERT INTO `xt_action_log` VALUES ('2296', '1', '100000', '127.0.0.1', '数据排序', '数据排序调整，model：Menu，id：209，value：11', '/c8903/public/menu/setsort.html', '1', '1536728944', '1536728944');
INSERT INTO `xt_action_log` VALUES ('2297', '1', '100000', '127.0.0.1', '授权', '设置权限组权限，id：3', '/c8903/public/auth/menuauth.html', '1', '1536729018', '1536729018');
INSERT INTO `xt_action_log` VALUES ('2298', '26', '1', '127.0.0.1', '登录', '登录操作，username：1', '/c8903/public/login/loginhandle.html', '1', '1536729047', '1536729047');
INSERT INTO `xt_action_log` VALUES ('2299', '27', '2', '127.0.0.1', '登录', '登录操作，username：2', '/c8903/public/login/loginhandle.html', '1', '1536729089', '1536729089');
INSERT INTO `xt_action_log` VALUES ('2300', '27', '2', '127.0.0.1', '新增', '新增会员，username：453217', '/c8903/public/index/member_add.html', '1', '1536732513', '1536732513');
INSERT INTO `xt_action_log` VALUES ('2301', '1', '100000', '192.168.0.144', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536733813', '1536733813');
INSERT INTO `xt_action_log` VALUES ('2302', '27', '2', '127.0.0.1', '新增', '新增会员，username：345368', '/c8903/public/index/member_add.html', '1', '1536734046', '1536734046');
INSERT INTO `xt_action_log` VALUES ('2303', '27', '2', '127.0.0.1', '新增', '新增会员，username：3453683', '/c8903/public/index/member_add.html', '1', '1536734224', '1536734224');
INSERT INTO `xt_action_log` VALUES ('2304', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536736291', '1536736291');
INSERT INTO `xt_action_log` VALUES ('2305', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536736625', '1536736625');
INSERT INTO `xt_action_log` VALUES ('2306', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：菜单管理', '/c8903/public/menu/menuedit.html', '1', '1536736660', '1536736660');
INSERT INTO `xt_action_log` VALUES ('2307', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：权限管理', '/c8903/public/menu/menuedit.html', '1', '1536736683', '1536736683');
INSERT INTO `xt_action_log` VALUES ('2308', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536737230', '1536737230');
INSERT INTO `xt_action_log` VALUES ('2309', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：菜单管理', '/c8903/public/menu/menuedit.html', '1', '1536737513', '1536737513');
INSERT INTO `xt_action_log` VALUES ('2310', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：reco', '/c8903/public/config/configedit.html', '1', '1536737557', '1536737557');
INSERT INTO `xt_action_log` VALUES ('2311', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：poundage', '/c8903/public/config/configedit.html', '1', '1536737628', '1536737628');
INSERT INTO `xt_action_log` VALUES ('2312', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：tax', '/c8903/public/config/configedit.html', '1', '1536737641', '1536737641');
INSERT INTO `xt_action_log` VALUES ('2313', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：reco', '/c8903/public/config/configedit.html', '1', '1536737665', '1536737665');
INSERT INTO `xt_action_log` VALUES ('2314', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：agent_center', '/c8903/public/config/configedit.html', '1', '1536737678', '1536737678');
INSERT INTO `xt_action_log` VALUES ('2315', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：see_you', '/c8903/public/config/configedit.html', '1', '1536737713', '1536737713');
INSERT INTO `xt_action_log` VALUES ('2316', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：see_you_ratio', '/c8903/public/config/configedit.html', '1', '1536737731', '1536737731');
INSERT INTO `xt_action_log` VALUES ('2317', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：see_you', '/c8903/public/config/configedit.html', '1', '1536737748', '1536737748');
INSERT INTO `xt_action_log` VALUES ('2318', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：manage', '/c8903/public/config/configedit.html', '1', '1536737775', '1536737775');
INSERT INTO `xt_action_log` VALUES ('2319', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：type_name', '/c8903/public/config/configedit.html', '1', '1536737823', '1536737823');
INSERT INTO `xt_action_log` VALUES ('2320', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：money_type', '/c8903/public/config/configedit.html', '1', '1536737847', '1536737847');
INSERT INTO `xt_action_log` VALUES ('2321', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：s_ratio', '/c8903/public/config/configedit.html', '1', '1536737913', '1536737913');
INSERT INTO `xt_action_log` VALUES ('2322', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：achievement', '/c8903/public/config/configedit.html', '1', '1536737933', '1536737933');
INSERT INTO `xt_action_log` VALUES ('2323', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：see_you_ratio', '/c8903/public/config/configedit.html', '1', '1536737979', '1536737979');
INSERT INTO `xt_action_log` VALUES ('2324', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：vip_level', '/c8903/public/config/configedit.html', '1', '1536738018', '1536738018');
INSERT INTO `xt_action_log` VALUES ('2325', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：see_you', '/c8903/public/config/configedit.html', '1', '1536738067', '1536738067');
INSERT INTO `xt_action_log` VALUES ('2326', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：菜单管理', '/c8903/public/menu/menuedit.html', '1', '1536738093', '1536738093');
INSERT INTO `xt_action_log` VALUES ('2327', '1', '100000', '127.0.0.1', '新增', '新增配置，name：31231', '/c8903/public/config/configadd.html', '1', '1536740530', '1536740530');
INSERT INTO `xt_action_log` VALUES ('2328', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：31231', '/c8903/public/config/configedit.html', '1', '1536740559', '1536740559');
INSERT INTO `xt_action_log` VALUES ('2329', '1', '100000', '127.0.0.1', '数据状态', '数据状态调整，model：Config，ids：85，status：-1', '/c8903/public/config/setstatus/ids/85/status/-1.html', '1', '1536740597', '1536740597');
INSERT INTO `xt_action_log` VALUES ('2330', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536743328', '1536743328');
INSERT INTO `xt_action_log` VALUES ('2331', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536743560', '1536743560');
INSERT INTO `xt_action_log` VALUES ('2332', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536749397', '1536749397');
INSERT INTO `xt_action_log` VALUES ('2333', '1', '100000', '127.0.0.1', '新增', '新增会员，username：605865', '/c8903/public/index/member_add.html', '1', '1536749457', '1536749457');
INSERT INTO `xt_action_log` VALUES ('2334', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536752129', '1536752129');
INSERT INTO `xt_action_log` VALUES ('2335', '1', '100000', '127.0.0.1', '新增', '新增会员，username：90176423', '/c8903/public/front/member_add.html', '1', '1536752166', '1536752166');
INSERT INTO `xt_action_log` VALUES ('2336', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536752455', '1536752455');
INSERT INTO `xt_action_log` VALUES ('2337', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536756169', '1536756169');
INSERT INTO `xt_action_log` VALUES ('2338', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536798959', '1536798959');
INSERT INTO `xt_action_log` VALUES ('2339', '1', '100000', '192.168.0.122', '编辑', '编辑菜单，name：购物商城', '/c8903/public/menu/menuedit.html', '1', '1536811102', '1536811102');
INSERT INTO `xt_action_log` VALUES ('2340', '1', '100000', '192.168.0.122', '编辑', '编辑菜单，name：菜单管理', '/c8903/public/menu/menuedit.html', '1', '1536813739', '1536813739');
INSERT INTO `xt_action_log` VALUES ('2341', '1', '100000', '192.168.0.122', '编辑', '编辑菜单，name：产品浏览', '/c8903/public/menu/menuedit.html', '1', '1536813797', '1536813797');
INSERT INTO `xt_action_log` VALUES ('2342', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：订单管理', '/c8903/public/menu/menuedit.html', '1', '1536814462', '1536814462');
INSERT INTO `xt_action_log` VALUES ('2343', '1', '100000', '127.0.0.1', '新增', '产品新增，name：2000产品', '/c8903/public/shopadmin/shopadd.html', '1', '1536825080', '1536825080');
INSERT INTO `xt_action_log` VALUES ('2344', '1', '100000', '127.0.0.1', '新增', '产品新增，name：5000产品', '/c8903/public/shopadmin/shopadd.html', '1', '1536825115', '1536825115');
INSERT INTO `xt_action_log` VALUES ('2345', '1', '100000', '127.0.0.1', '新增', '产品新增，name：10000产品', '/c8903/public/shopadmin/shopadd.html', '1', '1536825156', '1536825156');
INSERT INTO `xt_action_log` VALUES ('2346', '1', '100000', '127.0.0.1', '新增', '产品新增，name：30000产品', '/c8903/public/shopadmin/shopadd.html', '1', '1536825192', '1536825192');
INSERT INTO `xt_action_log` VALUES ('2347', '1', '100000', '127.0.0.1', '新增', '产品新增，name：50000产品', '/c8903/public/shopadmin/shopadd.html', '1', '1536825217', '1536825217');
INSERT INTO `xt_action_log` VALUES ('2348', '1', '100000', '127.0.0.1', '新增', '新增菜单，name：我的订单', '/c8903/public/menu/menuadd.html', '1', '1536826076', '1536826076');
INSERT INTO `xt_action_log` VALUES ('2349', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：我的订单', '/c8903/public/menu/menuedit.html', '1', '1536826097', '1536826097');
INSERT INTO `xt_action_log` VALUES ('2350', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536829298', '1536829298');
INSERT INTO `xt_action_log` VALUES ('2351', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536829323', '1536829323');
INSERT INTO `xt_action_log` VALUES ('2352', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：产品浏览', '/c8903/public/menu/menuedit.html', '1', '1536830414', '1536830414');
INSERT INTO `xt_action_log` VALUES ('2353', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：产品浏览', '/c8903/public/menu/menuedit.html', '1', '1536830426', '1536830426');
INSERT INTO `xt_action_log` VALUES ('2354', '1', '100000', '127.0.0.1', '编辑', '分类编辑，name：会员产品', '/c8903/public/shopadmin/shopcategoryedit.html', '1', '1536830460', '1536830460');
INSERT INTO `xt_action_log` VALUES ('2355', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536832581', '1536832581');
INSERT INTO `xt_action_log` VALUES ('2356', '1', '100000', '127.0.0.1', '删除', '数据库备份文件删除，path：D:\\wamp64\\www\\c8903\\data\\20180910-100024-*.sql*', '/c8903/public/database/backupdel/time/1536544824.html', '1', '1536833716', '1536833716');
INSERT INTO `xt_action_log` VALUES ('2357', '1', '100000', '127.0.0.1', '删除', '数据库备份文件删除，path：D:\\wamp64\\www\\c8903\\data\\20180910-101440-*.sql*', '/c8903/public/database/backupdel/time/1536545680.html', '1', '1536833720', '1536833720');
INSERT INTO `xt_action_log` VALUES ('2358', '1', '100000', '127.0.0.1', '删除', '数据库备份文件删除，path：D:\\wamp64\\www\\c8903\\data\\20180911-192406-*.sql*', '/c8903/public/database/backupdel/time/1536665046.html', '1', '1536833724', '1536833724');
INSERT INTO `xt_action_log` VALUES ('2359', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536835194', '1536835194');
INSERT INTO `xt_action_log` VALUES ('2360', '1', '100000', '192.168.0.157', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536888063', '1536888063');
INSERT INTO `xt_action_log` VALUES ('2361', '1', '100000', '192.168.0.122', '编辑', '编辑菜单，name：产品浏览', '/c8903/public/menu/menuedit.html', '1', '1536888290', '1536888290');
INSERT INTO `xt_action_log` VALUES ('2362', '1', '100000', '192.168.0.122', '编辑', '编辑菜单，name：订单管理', '/c8903/public/menu/menuedit.html', '1', '1536888312', '1536888312');
INSERT INTO `xt_action_log` VALUES ('2363', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536897839', '1536897839');
INSERT INTO `xt_action_log` VALUES ('2364', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536899887', '1536899887');
INSERT INTO `xt_action_log` VALUES ('2365', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：bank', '/c8903/public/config/configedit.html', '1', '1536899936', '1536899936');
INSERT INTO `xt_action_log` VALUES ('2366', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536907849', '1536907849');
INSERT INTO `xt_action_log` VALUES ('2367', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536908845', '1536908845');
INSERT INTO `xt_action_log` VALUES ('2368', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536911037', '1536911037');
INSERT INTO `xt_action_log` VALUES ('2369', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536919245', '1536919245');
INSERT INTO `xt_action_log` VALUES ('2370', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536920762', '1536920762');
INSERT INTO `xt_action_log` VALUES ('2371', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：菜单管理', '/c8903/public/menu/menuedit.html', '1', '1536921048', '1536921048');
INSERT INTO `xt_action_log` VALUES ('2372', '1', '100000', '192.168.0.157', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536921410', '1536921410');
INSERT INTO `xt_action_log` VALUES ('2373', '1', '100000', '192.168.0.157', '编辑', '产品编辑，name：胶囊', '/c8903/public/shopadmin/shopedit.html', '1', '1536921587', '1536921587');
INSERT INTO `xt_action_log` VALUES ('2374', '1', '100000', '192.168.0.122', '编辑', '编辑菜单，name：订单管理', '/c8903/public/menu/menuedit.html', '1', '1536921674', '1536921674');
INSERT INTO `xt_action_log` VALUES ('2375', '83', '563476', '192.168.0.122', '登录', '登录操作，username：563476', '/c8903/public/login/loginhandle.html', '1', '1536923552', '1536923552');
INSERT INTO `xt_action_log` VALUES ('2376', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536923604', '1536923604');
INSERT INTO `xt_action_log` VALUES ('2377', '1', '100000', '192.168.0.122', '授权', '设置权限组权限，id：3', '/c8903/public/auth/menuauth.html', '1', '1536923655', '1536923655');
INSERT INTO `xt_action_log` VALUES ('2378', '1', '100000', '192.168.0.122', '授权', '设置权限组权限，id：4', '/c8903/public/auth/menuauth.html', '1', '1536923669', '1536923669');
INSERT INTO `xt_action_log` VALUES ('2379', '83', '563476', '127.0.0.1', '登录', '登录操作，username：563476', '/c8903/public/login/loginhandle.html', '1', '1536923707', '1536923707');
INSERT INTO `xt_action_log` VALUES ('2380', '1', '100000', '192.168.0.157', '还原', '数据库还原', '/c8903/public/database/datarestorehandle/time/1536926202.html', '1', '1536928335', '1536928335');
INSERT INTO `xt_action_log` VALUES ('2381', '1', '100000', '192.168.0.122', '删除', '数据库备份文件删除，path：D:\\wamp64\\www\\c8903\\data\\20180914-195642-*.sql*', '/c8903/public/database/backupdel/time/1536926202.html', '1', '1536928390', '1536928390');
INSERT INTO `xt_action_log` VALUES ('2382', '1', '100000', '192.168.0.122', '备份', '数据库备份', '/c8903/public/database/databackup.html', '1', '1536928398', '1536928398');
INSERT INTO `xt_action_log` VALUES ('2383', '1', '100000', '192.168.0.122', '备份', '数据库备份', '/c8903/public/database/databackup.html', '1', '1536928580', '1536928580');
INSERT INTO `xt_action_log` VALUES ('2384', '1', '100000', '192.168.0.157', '备份', '数据库备份', '/c8903/public/database/databackup.html', '1', '1536928600', '1536928600');
INSERT INTO `xt_action_log` VALUES ('2385', '1', '100000', '192.168.0.122', '备份', '数据库备份', '/c8903/public/database/databackup.html', '1', '1536930337', '1536930337');
INSERT INTO `xt_action_log` VALUES ('2386', '1', '100000', '192.168.0.122', '删除', '数据库备份文件删除，path：D:\\wamp64\\www\\c8903\\data\\20180914-203639-*.sql*', '/c8903/public/database/backupdel/time/1536928599.html', '1', '1536930346', '1536930346');
INSERT INTO `xt_action_log` VALUES ('2387', '1', '100000', '192.168.0.122', '删除', '数据库备份文件删除，path：D:\\wamp64\\www\\c8903\\data\\20180914-203620-*.sql*', '/c8903/public/database/backupdel/time/1536928580.html', '1', '1536930350', '1536930350');
INSERT INTO `xt_action_log` VALUES ('2388', '1', '100000', '192.168.0.122', '删除', '数据库备份文件删除，path：D:\\wamp64\\www\\c8903\\data\\20180914-210537-*.sql*', '/c8903/public/database/backupdel/time/1536930337.html', '1', '1536930354', '1536930354');
INSERT INTO `xt_action_log` VALUES ('2389', '1', '100000', '192.168.0.122', '修复', '数据库修复', '/c8903/public/database/repair.html', '1', '1536930458', '1536930458');
INSERT INTO `xt_action_log` VALUES ('2390', '1', '100000', '192.168.0.122', '备份', '数据库备份', '/c8903/public/database/databackup.html', '1', '1536930463', '1536930463');
INSERT INTO `xt_action_log` VALUES ('2391', '1', '100000', '192.168.0.122', '删除', '数据库备份文件删除，path：D:\\wamp64\\www\\c8903\\data\\20180914-210742-*.sql*', '/c8903/public/database/backupdel/time/1536930462.html', '1', '1536930476', '1536930476');
INSERT INTO `xt_action_log` VALUES ('2392', '1', '100000', '113.16.67.151', '登录', '登录操作，username：100000', '/login/loginhandle.html', '1', '1536934230', '1536934230');

-- -----------------------------
-- Table structure for `xt_addon`
-- -----------------------------
DROP TABLE IF EXISTS `xt_addon`;
CREATE TABLE `xt_addon` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL DEFAULT '' COMMENT '插件名或标识',
  `title` varchar(20) NOT NULL DEFAULT '' COMMENT '中文名称',
  `describe` varchar(255) NOT NULL DEFAULT '' COMMENT '插件描述',
  `config` text NOT NULL COMMENT '配置',
  `author` varchar(40) NOT NULL DEFAULT '' COMMENT '作者',
  `version` varchar(20) NOT NULL DEFAULT '' COMMENT '版本号',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='插件表';

-- -----------------------------
-- Records of `xt_addon`
-- -----------------------------
INSERT INTO `xt_addon` VALUES ('3', 'File', '文件上传', '文件上传插件', '', 'Jack', '1.0', '1', '0', '0');
INSERT INTO `xt_addon` VALUES ('4', 'Icon', '图标选择', '图标选择插件', '', 'Bigotry', '1.0', '1', '0', '0');
INSERT INTO `xt_addon` VALUES ('5', 'Editor', '文本编辑器', '富文本编辑器', '', 'Bigotry', '1.0', '1', '0', '0');

-- -----------------------------
-- Table structure for `xt_address`
-- -----------------------------
DROP TABLE IF EXISTS `xt_address`;
CREATE TABLE `xt_address` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `consignee_name` varchar(100) NOT NULL COMMENT '收货人',
  `province` varchar(100) NOT NULL COMMENT '省',
  `city` varchar(100) NOT NULL COMMENT '市',
  `county` varchar(100) DEFAULT NULL COMMENT '县/区',
  `address` text NOT NULL COMMENT '详细地址',
  `mobile` varchar(11) NOT NULL COMMENT '联系电话',
  `status` int(10) NOT NULL DEFAULT '1' COMMENT '1-正常 -1-已删除',
  `default` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否为默认收货地址1-是 0-否',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `xt_address`
-- -----------------------------
INSERT INTO `xt_address` VALUES ('26', '73', '玩儿同为', '北京市', '北京市', '东城区', '请问', '15600156921', '1', '1');
INSERT INTO `xt_address` VALUES ('27', '74', '玩儿同为', '北京市', '北京市', '东城区', '请问', '15600156921', '1', '1');
INSERT INTO `xt_address` VALUES ('28', '75', '玩儿同为', '北京市', '北京市', '东城区', '请问', '15600156921', '1', '1');
INSERT INTO `xt_address` VALUES ('29', '76', 'werwr5w', '北京市', '北京市', '东城区', '  广西壮族自治区南宁市江南区万|电话：(0771)3828425', '15600156921', '1', '1');
INSERT INTO `xt_address` VALUES ('30', '77', '12惹我天天惹人', '北京市', '北京市', '东城区', '我二人我玩儿我wr', '15600156921', '1', '1');
INSERT INTO `xt_address` VALUES ('31', '78', 'ewrwrv wer we', '北京市', '北京市', '东城区', '2000', '15600156789', '1', '1');
INSERT INTO `xt_address` VALUES ('32', '79', 'erwerwrewer', '北京市', '北京市', '东城区', '2000ewrewrewrewre', '21231313232', '1', '1');
INSERT INTO `xt_address` VALUES ('33', '80', '玩儿玩儿', '北京市', '北京市', '东城区', '请问', '15600156921', '1', '1');
INSERT INTO `xt_address` VALUES ('34', '81', '123', '北京市', '北京市', '东城区', '123', '13122222222', '1', '1');
INSERT INTO `xt_address` VALUES ('35', '82', '123123', '北京市', '北京市', '东城区', '123123', '13122222222', '1', '1');
INSERT INTO `xt_address` VALUES ('36', '83', 'wrtetrertete', '北京市', '北京市', '东城区', '  广西壮族自治区南宁市江南区万|电话：(0771)3828425', '15600156921', '1', '1');
INSERT INTO `xt_address` VALUES ('37', '84', '123', '北京市', '北京市', '东城区', '123', '13122222222', '1', '1');
INSERT INTO `xt_address` VALUES ('38', '85', '131', '北京市', '北京市', '东城区', '123123', '13122222222', '1', '1');
INSERT INTO `xt_address` VALUES ('39', '86', '123', '北京市', '北京市', '西城区', '123', '13122222222', '1', '1');
INSERT INTO `xt_address` VALUES ('40', '87', '1123', '北京市', '北京市', '西城区', '123123', '13188888888', '1', '1');
INSERT INTO `xt_address` VALUES ('41', '88', '123', '北京市', '北京市', '东城区', '123', '13122222222', '1', '1');
INSERT INTO `xt_address` VALUES ('42', '89', '123', '北京市', '北京市', '东城区', '123', '13122222222', '1', '1');
INSERT INTO `xt_address` VALUES ('43', '90', '123', '北京市', '北京市', '东城区', '123', '13122222222', '1', '1');
INSERT INTO `xt_address` VALUES ('44', '91', '131', '北京市', '北京市', '东城区', '123', '13122222222', '1', '1');
INSERT INTO `xt_address` VALUES ('45', '92', '13', '北京市', '北京市', '东城区', '123', '13122222222', '1', '1');
INSERT INTO `xt_address` VALUES ('46', '93', '123', '北京市', '北京市', '东城区', '123', '13122222222', '1', '1');
INSERT INTO `xt_address` VALUES ('47', '94', '123', '北京市', '北京市', '东城区', '123', '13122222222', '1', '1');
INSERT INTO `xt_address` VALUES ('48', '95', '131', '北京市', '北京市', '东城区', '13', '13888888888', '1', '1');
INSERT INTO `xt_address` VALUES ('49', '96', '131', '北京市', '北京市', '东城区', '131', '13888888888', '1', '1');
INSERT INTO `xt_address` VALUES ('50', '97', '123', '北京市', '北京市', '东城区', '123', '13888888888', '1', '1');
INSERT INTO `xt_address` VALUES ('51', '98', '123', '北京市', '北京市', '东城区', '123', '13888888888', '1', '1');

-- -----------------------------
-- Table structure for `xt_api`
-- -----------------------------
DROP TABLE IF EXISTS `xt_api`;
CREATE TABLE `xt_api` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(150) NOT NULL DEFAULT '' COMMENT '接口名称',
  `group_id` int(6) unsigned NOT NULL DEFAULT '0' COMMENT '接口分组',
  `request_type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '请求类型 0:POST  1:GET',
  `api_url` char(50) NOT NULL DEFAULT '' COMMENT '请求路径',
  `describe` varchar(255) NOT NULL DEFAULT '' COMMENT '接口描述',
  `describe_text` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '接口富文本描述',
  `is_request_data` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否需要请求数据',
  `request_data` text NOT NULL COMMENT '请求数据',
  `response_data` text NOT NULL COMMENT '响应数据',
  `is_response_data` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否需要响应数据',
  `is_user_token` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否需要用户token',
  `is_response_sign` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否返回数据签名',
  `is_request_sign` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否验证请求数据签名',
  `response_examples` text NOT NULL COMMENT '响应栗子',
  `developer` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '研发者',
  `api_status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '接口状态（0:待研发，1:研发中，2:测试中，3:已完成）',
  `is_page` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否为分页接口 0：否  1：是',
  `sort` tinyint(5) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=192 DEFAULT CHARSET=utf8 COMMENT='API表';

-- -----------------------------
-- Records of `xt_api`
-- -----------------------------
INSERT INTO `xt_api` VALUES ('186', '登录或注册', '34', '0', 'common/login', '系统登录注册接口，若用户名存在则验证密码正确性，若用户名不存在则注册新用户，返回 user_token 用于操作需验证身份的接口', '', '1', '[{\"field_name\":\"username\",\"data_type\":\"0\",\"is_require\":\"1\",\"field_describe\":\"\\u7528\\u6237\\u540d\"},{\"field_name\":\"password\",\"data_type\":\"0\",\"is_require\":\"1\",\"field_describe\":\"\\u5bc6\\u7801\"}]', '[{\"field_name\":\"data\",\"data_type\":\"2\",\"field_describe\":\"\\u4f1a\\u5458\\u6570\\u636e\\u53causer_token\"}]', '1', '0', '1', '0', '{\r\n    &quot;code&quot;: 0,\r\n    &quot;msg&quot;: &quot;操作成功&quot;,\r\n    &quot;data&quot;: {\r\n        &quot;member_id&quot;: 51,\r\n        &quot;nickname&quot;: &quot;sadasdas&quot;,\r\n        &quot;username&quot;: &quot;sadasdas&quot;,\r\n        &quot;create_time&quot;: &quot;2017-09-09 13:40:17&quot;,\r\n        &quot;user_token&quot;: &quot;eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJPbmVCYXNlIEpXVCIsImlhdCI6MTUwNDkzNTYxNywiZXhwIjoxNTA0OTM2NjE3LCJhdWQiOiJPbmVCYXNlIiwic3ViIjoiT25lQmFzZSIsImRhdGEiOnsibWVtYmVyX2lkIjo1MSwibmlja25hbWUiOiJzYWRhc2RhcyIsInVzZXJuYW1lIjoic2FkYXNkYXMiLCJjcmVhdGVfdGltZSI6IjIwMTctMDktMDkgMTM6NDA6MTcifX0.6PEShODuifNsa-x1TumLoEaR2TCXpUEYgjpD3Mz3GRM&quot;\r\n    }\r\n}', '0', '1', '0', '0', '1', '1504501410', '1520504982');
INSERT INTO `xt_api` VALUES ('187', '文章分类列表', '44', '0', 'article/categorylist', '文章分类列表接口', '', '0', '', '[{\"field_name\":\"id\",\"data_type\":\"0\",\"field_describe\":\"\\u6587\\u7ae0\\u5206\\u7c7bID\"},{\"field_name\":\"name\",\"data_type\":\"0\",\"field_describe\":\"\\u6587\\u7ae0\\u5206\\u7c7b\\u540d\\u79f0\"}]', '1', '0', '0', '0', '{\r\n    &quot;code&quot;: 0,\r\n    &quot;msg&quot;: &quot;操作成功&quot;,\r\n    &quot;data&quot;: [\r\n        {\r\n            &quot;id&quot;: 2,\r\n            &quot;name&quot;: &quot;测试文章分类2&quot;\r\n        },\r\n        {\r\n            &quot;id&quot;: 1,\r\n            &quot;name&quot;: &quot;测试文章分类1&quot;\r\n        }\r\n    ]\r\n}', '0', '0', '0', '2', '1', '1504765581', '1520504982');
INSERT INTO `xt_api` VALUES ('188', '文章列表', '44', '0', 'article/articlelist', '文章列表接口', '', '1', '[{\"field_name\":\"category_id\",\"data_type\":\"0\",\"is_require\":\"0\",\"field_describe\":\"\\u82e5\\u4e0d\\u4f20\\u9012\\u6b64\\u53c2\\u6570\\u5219\\u4e3a\\u6240\\u6709\\u5206\\u7c7b\"}]', '', '0', '0', '0', '0', '{\r\n    &quot;code&quot;: 0,\r\n    &quot;msg&quot;: &quot;操作成功&quot;,\r\n    &quot;data&quot;: {\r\n        &quot;total&quot;: 9,\r\n        &quot;per_page&quot;: &quot;10&quot;,\r\n        &quot;current_page&quot;: 1,\r\n        &quot;last_page&quot;: 1,\r\n        &quot;data&quot;: [\r\n            {\r\n                &quot;id&quot;: 16,\r\n                &quot;name&quot;: &quot;11111111&quot;,\r\n                &quot;category_id&quot;: 2,\r\n                &quot;describe&quot;: &quot;22222222&quot;,\r\n                &quot;create_time&quot;: &quot;2017-08-07 13:58:37&quot;\r\n            },\r\n            {\r\n                &quot;id&quot;: 15,\r\n                &quot;name&quot;: &quot;tttttt&quot;,\r\n                &quot;category_id&quot;: 1,\r\n                &quot;describe&quot;: &quot;sddd&quot;,\r\n                &quot;create_time&quot;: &quot;2017-08-07 13:24:46&quot;\r\n            }\r\n        ]\r\n    }\r\n}', '0', '0', '1', '1', '1', '1504779780', '1520504982');
INSERT INTO `xt_api` VALUES ('189', '首页接口', '45', '0', 'combination/index', '首页聚合接口', '', '1', '[{\"field_name\":\"category_id\",\"data_type\":\"0\",\"is_require\":\"0\",\"field_describe\":\"\\u6587\\u7ae0\\u5206\\u7c7bID\"}]', '[{\"field_name\":\"article_category_list\",\"data_type\":\"2\",\"field_describe\":\"\\u6587\\u7ae0\\u5206\\u7c7b\\u6570\\u636e\"},{\"field_name\":\"article_list\",\"data_type\":\"2\",\"field_describe\":\"\\u6587\\u7ae0\\u6570\\u636e\"}]', '1', '0', '1', '0', '{\r\n    &quot;code&quot;: 0,\r\n    &quot;msg&quot;: &quot;操作成功&quot;,\r\n    &quot;data&quot;: {\r\n        &quot;article_category_list&quot;: [\r\n            {\r\n                &quot;id&quot;: 2,\r\n                &quot;name&quot;: &quot;测试文章分类2&quot;\r\n            },\r\n            {\r\n                &quot;id&quot;: 1,\r\n                &quot;name&quot;: &quot;测试文章分类1&quot;\r\n            }\r\n        ],\r\n        &quot;article_list&quot;: {\r\n            &quot;total&quot;: 8,\r\n            &quot;per_page&quot;: &quot;2&quot;,\r\n            &quot;current_page&quot;: &quot;1&quot;,\r\n            &quot;last_page&quot;: 4,\r\n            &quot;data&quot;: [\r\n                {\r\n                    &quot;id&quot;: 15,\r\n                    &quot;name&quot;: &quot;tttttt&quot;,\r\n                    &quot;category_id&quot;: 1,\r\n                    &quot;describe&quot;: &quot;sddd&quot;,\r\n                    &quot;create_time&quot;: &quot;2017-08-07 13:24:46&quot;\r\n                },\r\n                {\r\n                    &quot;id&quot;: 14,\r\n                    &quot;name&quot;: &quot;1111111111111111111&quot;,\r\n                    &quot;category_id&quot;: 1,\r\n                    &quot;describe&quot;: &quot;123123&quot;,\r\n                    &quot;create_time&quot;: &quot;2017-08-04 15:37:20&quot;\r\n                }\r\n            ]\r\n        }\r\n    }\r\n}', '0', '0', '1', '0', '1', '1504785072', '1520504982');
INSERT INTO `xt_api` VALUES ('190', '详情页接口', '45', '0', 'combination/details', '详情页接口', '', '1', '[{\"field_name\":\"article_id\",\"data_type\":\"0\",\"is_require\":\"1\",\"field_describe\":\"\\u6587\\u7ae0ID\"}]', '[{\"field_name\":\"article_category_list\",\"data_type\":\"2\",\"field_describe\":\"\\u6587\\u7ae0\\u5206\\u7c7b\\u6570\\u636e\"},{\"field_name\":\"article_details\",\"data_type\":\"2\",\"field_describe\":\"\\u6587\\u7ae0\\u8be6\\u60c5\\u6570\\u636e\"}]', '1', '0', '0', '0', '{\r\n    &quot;code&quot;: 0,\r\n    &quot;msg&quot;: &quot;操作成功&quot;,\r\n    &quot;data&quot;: {\r\n        &quot;article_category_list&quot;: [\r\n            {\r\n                &quot;id&quot;: 2,\r\n                &quot;name&quot;: &quot;测试文章分类2&quot;\r\n            },\r\n            {\r\n                &quot;id&quot;: 1,\r\n                &quot;name&quot;: &quot;测试文章分类1&quot;\r\n            }\r\n        ],\r\n        &quot;article_details&quot;: {\r\n            &quot;id&quot;: 1,\r\n            &quot;name&quot;: &quot;213&quot;,\r\n            &quot;category_id&quot;: 1,\r\n            &quot;describe&quot;: &quot;test001&quot;,\r\n            &quot;content&quot;: &quot;第三方发送到&quot;&quot;&quot;,\r\n            &quot;create_time&quot;: &quot;2014-07-22 11:56:53&quot;\r\n        }\r\n    }\r\n}', '0', '0', '0', '0', '1', '1504922092', '1520504982');
INSERT INTO `xt_api` VALUES ('191', '修改密码', '34', '0', 'common/changepassword', '修改密码接口', '', '1', '[{\"field_name\":\"old_password\",\"data_type\":\"0\",\"is_require\":\"1\",\"field_describe\":\"\\u65e7\\u5bc6\\u7801\"},{\"field_name\":\"new_password\",\"data_type\":\"0\",\"is_require\":\"1\",\"field_describe\":\"\\u65b0\\u5bc6\\u7801\"}]', '', '0', '1', '0', '0', '{\r\n    &quot;code&quot;: 0,\r\n    &quot;msg&quot;: &quot;操作成功&quot;,\r\n    &quot;exe_time&quot;: &quot;0.037002&quot;\r\n}', '0', '0', '0', '0', '1', '1504941496', '1520504982');

-- -----------------------------
-- Table structure for `xt_api_group`
-- -----------------------------
DROP TABLE IF EXISTS `xt_api_group`;
CREATE TABLE `xt_api_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(120) NOT NULL DEFAULT '' COMMENT 'aip分组名称',
  `sort` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=72 DEFAULT CHARSET=utf8 COMMENT='api分组表';

-- -----------------------------
-- Records of `xt_api_group`
-- -----------------------------
INSERT INTO `xt_api_group` VALUES ('34', '基础接口', '0', '1504501195', '0', '1');
INSERT INTO `xt_api_group` VALUES ('44', '文章接口', '1', '1504765319', '1504765319', '1');
INSERT INTO `xt_api_group` VALUES ('45', '聚合接口', '0', '1504784149', '1504784149', '1');

-- -----------------------------
-- Table structure for `xt_article`
-- -----------------------------
DROP TABLE IF EXISTS `xt_article`;
CREATE TABLE `xt_article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文章ID',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '会员id',
  `name` char(40) NOT NULL DEFAULT '' COMMENT '文章名称',
  `category_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文章分类',
  `describe` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `content` text NOT NULL COMMENT '文章内容',
  `cover_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '封面图片id',
  `file_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件id',
  `img_ids` varchar(200) NOT NULL DEFAULT '',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='文章表';

-- -----------------------------
-- Records of `xt_article`
-- -----------------------------
INSERT INTO `xt_article` VALUES ('1', '1', '312312321312', '8', '3213213', '3213123213213试试同为额儿童额恩恩&amp;nbsp;', '0', '0', '', '1535006408', '1536146338', '1');
INSERT INTO `xt_article` VALUES ('2', '1', 'system1', '8', '日特特瑞特人', '&lt;table&gt;\r\n	&lt;tbody&gt;\r\n		&lt;tr&gt;\r\n			&lt;td class=&quot;line-number&quot;&gt;\r\n			&lt;/td&gt;\r\n			&lt;td class=&quot;line-content&quot;&gt;\r\n				&lt;span class=&quot;html-doctype&quot;&gt;&amp;lt;!DOCTYPE HTML&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;html &lt;span class=&quot;html-attribute-name&quot;&gt;lang&lt;/span&gt;=\'&lt;span class=&quot;html-attribute-value&quot;&gt;zh_CN&lt;/span&gt;\' &lt;span class=&quot;html-attribute-name&quot;&gt;dir&lt;/span&gt;=\'&lt;span class=&quot;html-attribute-value&quot;&gt;ltr&lt;/span&gt;\' &lt;span class=&quot;html-attribute-name&quot;&gt;class&lt;/span&gt;=\'&lt;span class=&quot;html-attribute-value&quot;&gt;chrome chrome68&lt;/span&gt;\'&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;head&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;meta &lt;span class=&quot;html-attribute-name&quot;&gt;charset&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;utf-8&lt;/span&gt;&quot; /&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;meta &lt;span class=&quot;html-attribute-name&quot;&gt;name&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;referrer&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;content&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;no-referrer&lt;/span&gt;&quot; /&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;meta &lt;span class=&quot;html-attribute-name&quot;&gt;name&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;robots&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;content&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;noindex,nofollow&lt;/span&gt;&quot; /&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;meta &lt;span class=&quot;html-attribute-name&quot;&gt;http-equiv&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;X-UA-Compatible&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;content&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;IE=Edge&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;style &lt;span class=&quot;html-attribute-name&quot;&gt;id&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;cfs-style&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;html{display: none;}&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/style&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;link &lt;span class=&quot;html-attribute-name&quot;&gt;rel&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;icon&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;href&lt;/span&gt;=&quot;&lt;a class=&quot;html-attribute-value html-resource-link&quot; target=&quot;_blank&quot; href=&quot;http://localhost/phpmyadmin/favicon.ico&quot;&gt;favicon.ico&lt;/a&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;type&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;image/x-icon&lt;/span&gt;&quot; /&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;link &lt;span class=&quot;html-attribute-name&quot;&gt;rel&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;shortcut icon&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;href&lt;/span&gt;=&quot;&lt;a class=&quot;html-attribute-value html-resource-link&quot; target=&quot;_blank&quot; href=&quot;http://localhost/phpmyadmin/favicon.ico&quot;&gt;favicon.ico&lt;/a&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;type&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;image/x-icon&lt;/span&gt;&quot; /&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;link &lt;span class=&quot;html-attribute-name&quot;&gt;rel&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;stylesheet&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;type&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;text/css&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;href&lt;/span&gt;=&quot;&lt;a class=&quot;html-attribute-value html-resource-link&quot; target=&quot;_blank&quot; href=&quot;http://localhost/phpmyadmin/themes/pmahomme/jquery/jquery-ui-1.11.4.css&quot;&gt;./themes/pmahomme/jquery/jquery-ui-1.11.4.css&lt;/a&gt;&quot; /&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;link &lt;span class=&quot;html-attribute-name&quot;&gt;rel&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;stylesheet&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;type&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;text/css&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;href&lt;/span&gt;=&quot;&lt;a class=&quot;html-attribute-value html-resource-link&quot; target=&quot;_blank&quot; href=&quot;http://localhost/phpmyadmin/js/codemirror/lib/codemirror.css?v=4.6.4&quot;&gt;js/codemirror/lib/codemirror.css?v=4.6.4&lt;/a&gt;&quot; /&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;link &lt;span class=&quot;html-attribute-name&quot;&gt;rel&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;stylesheet&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;type&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;text/css&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;href&lt;/span&gt;=&quot;&lt;a class=&quot;html-attribute-value html-resource-link&quot; target=&quot;_blank&quot; href=&quot;http://localhost/phpmyadmin/js/codemirror/addon/hint/show-hint.css?v=4.6.4&quot;&gt;js/codemirror/addon/hint/show-hint.css?v=4.6.4&lt;/a&gt;&quot; /&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;link &lt;span class=&quot;html-attribute-name&quot;&gt;rel&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;stylesheet&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;type&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;text/css&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;href&lt;/span&gt;=&quot;&lt;a class=&quot;html-attribute-value html-resource-link&quot; target=&quot;_blank&quot; href=&quot;http://localhost/phpmyadmin/js/codemirror/addon/lint/lint.css?v=4.6.4&quot;&gt;js/codemirror/addon/lint/lint.css?v=4.6.4&lt;/a&gt;&quot; /&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;link &lt;span class=&quot;html-attribute-name&quot;&gt;rel&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;stylesheet&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;type&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;text/css&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;href&lt;/span&gt;=&quot;&lt;a class=&quot;html-attribute-value html-resource-link&quot; target=&quot;_blank&quot; href=&quot;http://localhost/phpmyadmin/phpmyadmin.css.php?nocache=4414076554ltr&quot;&gt;phpmyadmin.css.php?nocache=4414076554ltr&lt;/a&gt;&quot; /&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;link &lt;span class=&quot;html-attribute-name&quot;&gt;rel&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;stylesheet&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;type&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;text/css&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;href&lt;/span&gt;=&quot;&lt;a class=&quot;html-attribute-value html-resource-link&quot; target=&quot;_blank&quot; href=&quot;http://localhost/phpmyadmin/themes/pmahomme/css/printview.css?v=4.6.4&quot;&gt;./themes/pmahomme/css/printview.css?v=4.6.4&lt;/a&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;media&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;print&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;id&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;printcss&lt;/span&gt;&quot;/&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;title&amp;gt;&lt;/span&gt;phpMyAdmin&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/title&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;script &lt;span class=&quot;html-attribute-name&quot;&gt;data-cfasync&lt;/span&gt;=\'&lt;span class=&quot;html-attribute-value&quot;&gt;false&lt;/span&gt;\' &lt;span class=&quot;html-attribute-name&quot;&gt;type&lt;/span&gt;=\'&lt;span class=&quot;html-attribute-value&quot;&gt;text/javascript&lt;/span&gt;\' &lt;span class=&quot;html-attribute-name&quot;&gt;src&lt;/span&gt;=\'&lt;a class=&quot;html-attribute-value html-resource-link&quot; target=&quot;_blank&quot; href=&quot;http://localhost/phpmyadmin/js/whitelist.php?lang=zh_CN&amp;amp;db=j8830&amp;amp;token=23c7bcd9770df110efa1c8a54933f42a&amp;amp;v=4.6.4&quot;&gt;js/whitelist.php?lang=zh_CN&amp;amp;amp;db=j8830&amp;amp;amp;token=23c7bcd9770df110efa1c8a54933f42a&amp;amp;v=4.6.4&lt;/a&gt;\'&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/script&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;script &lt;span class=&quot;html-attribute-name&quot;&gt;data-cfasync&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;false&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;type&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;text/javascript&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;src&lt;/span&gt;=&quot;&lt;a class=&quot;html-attribute-value html-resource-link&quot; target=&quot;_blank&quot; href=&quot;http://localhost/phpmyadmin/js/get_scripts.js.php?scripts%5B%5D=jquery/jquery-2.1.4.min.js&amp;amp;scripts%5B%5D=sprintf.js&amp;amp;scripts%5B%5D=ajax.js&amp;amp;scripts%5B%5D=keyhandler.js&amp;amp;scripts%5B%5D=jquery/jquery-ui-1.11.4.min.js&amp;amp;scripts%5B%5D=jquery/jquery.cookie.js&amp;amp;scripts%5B%5D=jquery/jquery.mousewheel.js&amp;amp;scripts%5B%5D=jquery/jquery.event.drag-2.2.js&amp;amp;scripts%5B%5D=jquery/jquery-ui-timepicker-addon.js&amp;amp;scripts%5B%5D=jquery/jquery.ba-hashchange-1.3.js&amp;amp;v=4.6.4&quot;&gt;js/get_scripts.js.php?scripts%5B%5D=jquery/jquery-2.1.4.min.js&amp;amp;amp;scripts%5B%5D=sprintf.js&amp;amp;amp;scripts%5B%5D=ajax.js&amp;amp;amp;scripts%5B%5D=keyhandler.js&amp;amp;amp;scripts%5B%5D=jquery/jquery-ui-1.11.4.min.js&amp;amp;amp;scripts%5B%5D=jquery/jquery.cookie.js&amp;amp;amp;scripts%5B%5D=jquery/jquery.mousewheel.js&amp;amp;amp;scripts%5B%5D=jquery/jquery.event.drag-2.2.js&amp;amp;amp;scripts%5B%5D=jquery/jquery-ui-timepicker-addon.js&amp;amp;amp;scripts%5B%5D=jquery/jquery.ba-hashchange-1.3.js&amp;amp;amp;v=4.6.4&lt;/a&gt;&quot;&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/script&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;script &lt;span class=&quot;html-attribute-name&quot;&gt;data-cfasync&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;false&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;type&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;text/javascript&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;src&lt;/span&gt;=&quot;&lt;a class=&quot;html-attribute-value html-resource-link&quot; target=&quot;_blank&quot; href=&quot;http://localhost/phpmyadmin/js/get_scripts.js.php?scripts%5B%5D=jquery/jquery.debounce-1.0.5.js&amp;amp;scripts%5B%5D=menu-resizer.js&amp;amp;scripts%5B%5D=cross_framing_protection.js&amp;amp;scripts%5B%5D=rte.js&amp;amp;scripts%5B%5D=tracekit/tracekit.js&amp;amp;scripts%5B%5D=error_report.js&amp;amp;scripts%5B%5D=config.js&amp;amp;scripts%5B%5D=doclinks.js&amp;amp;scripts%5B%5D=functions.js&amp;amp;scripts%5B%5D=navigation.js&amp;amp;v=4.6.4&quot;&gt;js/get_scripts.js.php?scripts%5B%5D=jquery/jquery.debounce-1.0.5.js&amp;amp;amp;scripts%5B%5D=menu-resizer.js&amp;amp;amp;scripts%5B%5D=cross_framing_protection.js&amp;amp;amp;scripts%5B%5D=rte.js&amp;amp;amp;scripts%5B%5D=tracekit/tracekit.js&amp;amp;amp;scripts%5B%5D=error_report.js&amp;amp;amp;scripts%5B%5D=config.js&amp;amp;amp;scripts%5B%5D=doclinks.js&amp;amp;amp;scripts%5B%5D=functions.js&amp;amp;amp;scripts%5B%5D=navigation.js&amp;amp;amp;v=4.6.4&lt;/a&gt;&quot;&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/script&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;script &lt;span class=&quot;html-attribute-name&quot;&gt;data-cfasync&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;false&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;type&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;text/javascript&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;src&lt;/span&gt;=&quot;&lt;a class=&quot;html-attribute-value html-resource-link&quot; target=&quot;_blank&quot; href=&quot;http://localhost/phpmyadmin/js/get_scripts.js.php?scripts%5B%5D=indexes.js&amp;amp;scripts%5B%5D=common.js&amp;amp;scripts%5B%5D=page_settings.js&amp;amp;scripts%5B%5D=codemirror/lib/codemirror.js&amp;amp;scripts%5B%5D=codemirror/mode/sql/sql.js&amp;amp;scripts%5B%5D=codemirror/addon/runmode/runmode.js&amp;amp;scripts%5B%5D=codemirror/addon/hint/show-hint.js&amp;amp;scripts%5B%5D=codemirror/addon/hint/sql-hint.js&amp;amp;scripts%5B%5D=codemirror/addon/lint/lint.js&amp;amp;scripts%5B%5D=codemirror/addon/lint/sql-lint.js&amp;amp;v=4.6.4&quot;&gt;js/get_scripts.js.php?scripts%5B%5D=indexes.js&amp;amp;amp;scripts%5B%5D=common.js&amp;amp;amp;scripts%5B%5D=page_settings.js&amp;amp;amp;scripts%5B%5D=codemirror/lib/codemirror.js&amp;amp;amp;scripts%5B%5D=codemirror/mode/sql/sql.js&amp;amp;amp;scripts%5B%5D=codemirror/addon/runmode/runmode.js&amp;amp;amp;scripts%5B%5D=codemirror/addon/hint/show-hint.js&amp;amp;amp;scripts%5B%5D=codemirror/addon/hint/sql-hint.js&amp;amp;amp;scripts%5B%5D=codemirror/addon/lint/lint.js&amp;amp;amp;scripts%5B%5D=codemirror/addon/lint/sql-lint.js&amp;amp;amp;v=4.6.4&lt;/a&gt;&quot;&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/script&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;script &lt;span class=&quot;html-attribute-name&quot;&gt;data-cfasync&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;false&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;type&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;text/javascript&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;src&lt;/span&gt;=&quot;&lt;a class=&quot;html-attribute-value html-resource-link&quot; target=&quot;_blank&quot; href=&quot;http://localhost/phpmyadmin/js/get_scripts.js.php?scripts%5B%5D=console.js&amp;amp;v=4.6.4&quot;&gt;js/get_scripts.js.php?scripts%5B%5D=console.js&amp;amp;amp;v=4.6.4&lt;/a&gt;&quot;&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/script&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;script &lt;span class=&quot;html-attribute-name&quot;&gt;data-cfasync&lt;/span&gt;=\'&lt;span class=&quot;html-attribute-value&quot;&gt;false&lt;/span&gt;\' &lt;span class=&quot;html-attribute-name&quot;&gt;type&lt;/span&gt;=\'&lt;span class=&quot;html-attribute-value&quot;&gt;text/javascript&lt;/span&gt;\' &lt;span class=&quot;html-attribute-name&quot;&gt;src&lt;/span&gt;=\'&lt;a class=&quot;html-attribute-value html-resource-link&quot; target=&quot;_blank&quot; href=&quot;http://localhost/phpmyadmin/js/messages.php?lang=zh_CN&amp;amp;db=j8830&amp;amp;token=23c7bcd9770df110efa1c8a54933f42a&amp;amp;v=4.6.4&quot;&gt;js/messages.php?lang=zh_CN&amp;amp;amp;db=j8830&amp;amp;amp;token=23c7bcd9770df110efa1c8a54933f42a&amp;amp;v=4.6.4&lt;/a&gt;\'&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/script&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;script &lt;span class=&quot;html-attribute-name&quot;&gt;data-cfasync&lt;/span&gt;=\'&lt;span class=&quot;html-attribute-value&quot;&gt;false&lt;/span&gt;\' &lt;span class=&quot;html-attribute-name&quot;&gt;type&lt;/span&gt;=\'&lt;span class=&quot;html-attribute-value&quot;&gt;text/javascript&lt;/span&gt;\' &lt;span class=&quot;html-attribute-name&quot;&gt;src&lt;/span&gt;=\'&lt;a class=&quot;html-attribute-value html-resource-link&quot; target=&quot;_blank&quot; href=&quot;http://localhost/phpmyadmin/js/get_image.js.php?theme=pmahomme&amp;amp;v=4.6.4&quot;&gt;js/get_image.js.php?theme=pmahomme&amp;amp;v=4.6.4&lt;/a&gt;\'&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/script&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;script &lt;span class=&quot;html-attribute-name&quot;&gt;data-cfasync&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;false&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;type&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;text/javascript&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;// &amp;lt;![CDATA[\r\n			&lt;/td&gt;\r\n		&lt;/tr&gt;\r\n		&lt;tr&gt;\r\n			&lt;td class=&quot;line-number&quot;&gt;\r\n			&lt;/td&gt;\r\n			&lt;td class=&quot;line-content&quot;&gt;\r\n				PMA_commonParams.setAll({common_query:&quot;?token=23c7bcd9770df110efa1c8a54933f42a&quot;,opendb_url:&quot;db_structure.php&quot;,safari_browser:&quot;0&quot;,collation_connection:&quot;utf8_unicode_ci&quot;,lang:&quot;zh_CN&quot;,server:&quot;1&quot;,table:&quot;xt_history&quot;,db:&quot;j8830&quot;,token:&quot;23c7bcd9770df110efa1c8a54933f42a&quot;,text_dir:&quot;ltr&quot;,show_databases_navigation_as_tree:&quot;1&quot;,pma_text_default_tab:&quot;浏览&quot;,pma_text_left_default_tab:&quot;结构&quot;,pma_text_left_default_tab2:&quot;&quot;,LimitChars:&quot;50&quot;,pftext:&quot;P&quot;,confirm:&quot;1&quot;,LoginCookieValidity:&quot;1440&quot;,logged_in:&quot;&quot;,PMA_VERSION:&quot;4.6.4&quot;,auth_type:&quot;cookie&quot;});\r\n			&lt;/td&gt;\r\n		&lt;/tr&gt;\r\n		&lt;tr&gt;\r\n			&lt;td class=&quot;line-number&quot;&gt;\r\n			&lt;/td&gt;\r\n			&lt;td class=&quot;line-content&quot;&gt;\r\n				ConsoleEnterExecutes=false\r\n			&lt;/td&gt;\r\n		&lt;/tr&gt;\r\n		&lt;tr&gt;\r\n			&lt;td class=&quot;line-number&quot;&gt;\r\n			&lt;/td&gt;\r\n			&lt;td class=&quot;line-content&quot;&gt;\r\n				AJAX.scriptHandler.add(&quot;jquery/jquery-2.1.4.min.js&quot;,0).add(&quot;whitelist.php?lang=zh_CN&amp;amp;amp;db=j8830&amp;amp;amp;token=23c7bcd9770df110efa1c8a54933f42a&quot;,1).add(&quot;sprintf.js&quot;,1).add(&quot;ajax.js&quot;,0).add(&quot;keyhandler.js&quot;,1).add(&quot;jquery/jquery-ui-1.11.4.min.js&quot;,0).add(&quot;jquery/jquery.cookie.js&quot;,0).add(&quot;jquery/jquery.mousewheel.js&quot;,0).add(&quot;jquery/jquery.event.drag-2.2.js&quot;,0).add(&quot;jquery/jquery-ui-timepicker-addon.js&quot;,0).add(&quot;jquery/jquery.ba-hashchange-1.3.js&quot;,0).add(&quot;jquery/jquery.debounce-1.0.5.js&quot;,0).add(&quot;menu-resizer.js&quot;,1).add(&quot;cross_framing_protection.js&quot;,0).add(&quot;rte.js&quot;,1).add(&quot;tracekit/tracekit.js&quot;,1).add(&quot;error_report.js&quot;,1).add(&quot;messages.php?lang=zh_CN&amp;amp;amp;db=j8830&amp;amp;amp;token=23c7bcd9770df110efa1c8a54933f42a&quot;,0).add(&quot;get_image.js.php?theme=pmahomme&quot;,0).add(&quot;config.js&quot;,1).add(&quot;doclinks.js&quot;,1).add(&quot;functions.js&quot;,1).add(&quot;navigation.js&quot;,1).add(&quot;indexes.js&quot;,1).add(&quot;common.js&quot;,1).add(&quot;page_settings.js&quot;,1).add(&quot;codemirror/lib/codemirror.js&quot;,0).add(&quot;codemirror/mode/sql/sql.js&quot;,0).add(&quot;codemirror/addon/runmode/runmode.js&quot;,0).add(&quot;codemirror/addon/hint/show-hint.js&quot;,0).add(&quot;codemirror/addon/hint/sql-hint.js&quot;,0).add(&quot;codemirror/addon/lint/lint.js&quot;,0).add(&quot;codemirror/addon/lint/sql-lint.js&quot;,0).add(&quot;console.js&quot;,1);\r\n			&lt;/td&gt;\r\n		&lt;/tr&gt;\r\n		&lt;tr&gt;\r\n			&lt;td class=&quot;line-number&quot;&gt;\r\n			&lt;/td&gt;\r\n			&lt;td class=&quot;line-content&quot;&gt;\r\n				$(function() {AJAX.fireOnload(&quot;whitelist.php?lang=zh_CN&amp;amp;amp;db=j8830&amp;amp;amp;token=23c7bcd9770df110efa1c8a54933f42a&quot;);AJAX.fireOnload(&quot;sprintf.js&quot;);AJAX.fireOnload(&quot;keyhandler.js&quot;);AJAX.fireOnload(&quot;menu-resizer.js&quot;);AJAX.fireOnload(&quot;rte.js&quot;);AJAX.fireOnload(&quot;tracekit/tracekit.js&quot;);AJAX.fireOnload(&quot;error_report.js&quot;);AJAX.fireOnload(&quot;config.js&quot;);AJAX.fireOnload(&quot;doclinks.js&quot;);AJAX.fireOnload(&quot;functions.js&quot;);AJAX.fireOnload(&quot;navigation.js&quot;);AJAX.fireOnload(&quot;indexes.js&quot;);AJAX.fireOnload(&quot;common.js&quot;);AJAX.fireOnload(&quot;page_settings.js&quot;);AJAX.fireOnload(&quot;console.js&quot;);});\r\n			&lt;/td&gt;\r\n		&lt;/tr&gt;\r\n		&lt;tr&gt;\r\n			&lt;td class=&quot;line-number&quot;&gt;\r\n			&lt;/td&gt;\r\n			&lt;td class=&quot;line-content&quot;&gt;\r\n				// ]]&amp;gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/script&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;noscript&amp;gt;&lt;/span&gt;&amp;lt;style&amp;gt;html{display:block}&amp;lt;/style&amp;gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/noscript&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/head&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;body &lt;span class=&quot;html-attribute-name&quot;&gt;id&lt;/span&gt;=\'&lt;span class=&quot;html-attribute-value&quot;&gt;loginform&lt;/span&gt;\'&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;div &lt;span class=&quot;html-attribute-name&quot;&gt;id&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;page_content&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;\r\n			&lt;/td&gt;\r\n		&lt;/tr&gt;\r\n		&lt;tr&gt;\r\n			&lt;td class=&quot;line-number&quot;&gt;\r\n			&lt;/td&gt;\r\n			&lt;td class=&quot;line-content&quot;&gt;\r\n				&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;div &lt;span class=&quot;html-attribute-name&quot;&gt;class&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;container&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;\r\n			&lt;/td&gt;\r\n		&lt;/tr&gt;\r\n		&lt;tr&gt;\r\n			&lt;td class=&quot;line-number&quot;&gt;\r\n			&lt;/td&gt;\r\n			&lt;td class=&quot;line-content&quot;&gt;\r\n				&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;a &lt;span class=&quot;html-attribute-name&quot;&gt;href&lt;/span&gt;=&quot;&lt;a class=&quot;html-attribute-value html-external-link&quot; target=&quot;_blank&quot; href=&quot;http://localhost/phpmyadmin/url.php?url=https%3A%2F%2Fwww.phpmyadmin.net%2F&quot;&gt;./url.php?url=https%3A%2F%2Fwww.phpmyadmin.net%2F&lt;/a&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;target&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;_blank&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;class&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;logo&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;img &lt;span class=&quot;html-attribute-name&quot;&gt;src&lt;/span&gt;=&quot;&lt;a class=&quot;html-attribute-value html-resource-link&quot; target=&quot;_blank&quot; href=&quot;http://localhost/phpmyadmin/themes/pmahomme/img/logo_right.png&quot;&gt;./themes/pmahomme/img/logo_right.png&lt;/a&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;id&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;imLogo&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;name&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;imLogo&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;alt&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;phpMyAdmin&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;border&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;0&lt;/span&gt;&quot; /&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/a&amp;gt;&lt;/span&gt;\r\n			&lt;/td&gt;\r\n		&lt;/tr&gt;\r\n		&lt;tr&gt;\r\n			&lt;td class=&quot;line-number&quot;&gt;\r\n			&lt;/td&gt;\r\n			&lt;td class=&quot;line-content&quot;&gt;\r\n				&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;h1&amp;gt;&lt;/span&gt;欢迎使用 &lt;span class=&quot;html-tag&quot;&gt;&amp;lt;bdo &lt;span class=&quot;html-attribute-name&quot;&gt;dir&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;ltr&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;lang&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;en&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;phpMyAdmin&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/bdo&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/h1&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;div &lt;span class=&quot;html-attribute-name&quot;&gt;class&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;error&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;img &lt;span class=&quot;html-attribute-name&quot;&gt;src&lt;/span&gt;=&quot;&lt;a class=&quot;html-attribute-value html-resource-link&quot; target=&quot;_blank&quot; href=&quot;http://localhost/phpmyadmin/themes/dot.gif&quot;&gt;themes/dot.gif&lt;/a&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;title&lt;/span&gt;=&quot;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;alt&lt;/span&gt;=&quot;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;class&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;icon ic_s_error&lt;/span&gt;&quot; /&amp;gt;&lt;/span&gt; 登录超时 (1440 秒未活动)，请重新登录。&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/div&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;noscript&amp;gt;&lt;/span&gt;\r\n			&lt;/td&gt;\r\n		&lt;/tr&gt;\r\n		&lt;tr&gt;\r\n			&lt;td class=&quot;line-number&quot;&gt;\r\n			&lt;/td&gt;\r\n			&lt;td class=&quot;line-content&quot;&gt;\r\n				&amp;lt;div class=&quot;error&quot;&amp;gt;&amp;lt;img src=&quot;themes/dot.gif&quot; title=&quot;&quot; alt=&quot;&quot; class=&quot;icon ic_s_error&quot; /&amp;gt; 该处必须启用 Javascript！&amp;lt;/div&amp;gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/noscript&amp;gt;&lt;/span&gt;\r\n			&lt;/td&gt;\r\n		&lt;/tr&gt;\r\n		&lt;tr&gt;\r\n			&lt;td class=&quot;line-number&quot;&gt;\r\n			&lt;/td&gt;\r\n			&lt;td class=&quot;line-content&quot;&gt;\r\n				&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;div &lt;span class=&quot;html-attribute-name&quot;&gt;class&lt;/span&gt;=\'&lt;span class=&quot;html-attribute-value&quot;&gt;hide js-show&lt;/span&gt;\'&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;form &lt;span class=&quot;html-attribute-name&quot;&gt;method&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;get&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;action&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;index.php&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;class&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;disableAjax&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;input &lt;span class=&quot;html-attribute-name&quot;&gt;type&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;hidden&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;name&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;db&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;j8830&lt;/span&gt;&quot; /&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;input &lt;span class=&quot;html-attribute-name&quot;&gt;type&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;hidden&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;name&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;table&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;xt_history&lt;/span&gt;&quot; /&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;input &lt;span class=&quot;html-attribute-name&quot;&gt;type&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;hidden&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;name&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;token&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;23c7bcd9770df110efa1c8a54933f42a&lt;/span&gt;&quot; /&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;fieldset&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;legend &lt;span class=&quot;html-attribute-name&quot;&gt;lang&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;en&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;dir&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;ltr&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;语言 - &lt;span class=&quot;html-tag&quot;&gt;&amp;lt;em&amp;gt;&lt;/span&gt;Language&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/em&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/legend&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;select &lt;span class=&quot;html-attribute-name&quot;&gt;name&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;lang&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;class&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;autosubmit&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;lang&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;en&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;dir&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;ltr&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;id&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;sel-lang&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;hy&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;Հայերէն - Armenian&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;az&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;Az&amp;amp;#601;rbaycanca - Azerbaijani&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;bn&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;বাংলা - Bangla&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;pt_br&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;Portugu&amp;amp;ecirc;s - Brazilian Portuguese&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;bg&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;&amp;amp;#1041;&amp;amp;#1098;&amp;amp;#1083;&amp;amp;#1075;&amp;amp;#1072;&amp;amp;#1088;&amp;amp;#1089;&amp;amp;#1082;&amp;amp;#1080; - Bulgarian&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;ca&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;Catal&amp;amp;agrave; - Catalan&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;zh_cn&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;selected&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;selected&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;&amp;amp;#20013;&amp;amp;#25991; - Chinese simplified&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;zh_tw&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;&amp;amp;#20013;&amp;amp;#25991; - Chinese traditional&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;cs&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;Če&scaron;tina - Czech&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;da&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;Dansk - Danish&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;nl&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;Nederlands - Dutch&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;en&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;English&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;en_gb&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;English (United Kingdom)&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;et&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;Eesti - Estonian&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;fi&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;Suomi - Finnish&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;fr&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;Fran&amp;amp;ccedil;ais - French&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;gl&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;Galego - Galician&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;de&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;Deutsch - German&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;el&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;&amp;amp;Epsilon;&amp;amp;lambda;&amp;amp;lambda;&amp;amp;eta;&amp;amp;nu;&amp;amp;iota;&amp;amp;kappa;&amp;amp;#940; - Greek&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;hu&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;Magyar - Hungarian&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;id&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;Bahasa Indonesia - Indonesian&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;ia&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;Interlingua&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;it&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;Italiano - Italian&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;ja&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;&amp;amp;#26085;&amp;amp;#26412;&amp;amp;#35486; - Japanese&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;ko&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;&amp;amp;#54620;&amp;amp;#44397;&amp;amp;#50612; - Korean&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;lt&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;Lietuvi&amp;amp;#371; - Lithuanian&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;nb&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;Norsk - Norwegian&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;pl&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;Polski - Polish&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;pt&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;Portugu&amp;amp;ecirc;s - Portuguese&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;ro&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;Rom&amp;amp;acirc;n&amp;amp;#259; - Romanian&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;ru&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;&amp;amp;#1056;&amp;amp;#1091;&amp;amp;#1089;&amp;amp;#1089;&amp;amp;#1082;&amp;amp;#1080;&amp;amp;#1081; - Russian&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;sr@latin&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;Srpski - Serbian (latin)&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;si&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;&amp;amp;#3523;&amp;amp;#3538;&amp;amp;#3458;&amp;amp;#3524;&amp;amp;#3517; - Sinhala&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;sq&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;Shqip - Slbanian&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;sk&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;Sloven&amp;amp;#269;ina - Slovak&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;sl&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;Sloven&amp;amp;scaron;&amp;amp;#269;ina - Slovenian&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;es&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;Espa&amp;amp;ntilde;ol - Spanish&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;sv&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;Svenska - Swedish&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;tr&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;T&amp;amp;uuml;rk&amp;amp;ccedil;e - Turkish&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;uk&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;&amp;amp;#1059;&amp;amp;#1082;&amp;amp;#1088;&amp;amp;#1072;&amp;amp;#1111;&amp;amp;#1085;&amp;amp;#1089;&amp;amp;#1100;&amp;amp;#1082;&amp;amp;#1072; - Ukrainian&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;option &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;vi&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;Tiếng Việt - Vietnamese&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/option&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/select&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/fieldset&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/form&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/div&amp;gt;&lt;/span&gt;\r\n			&lt;/td&gt;\r\n		&lt;/tr&gt;\r\n		&lt;tr&gt;\r\n			&lt;td class=&quot;line-number&quot;&gt;\r\n			&lt;/td&gt;\r\n			&lt;td class=&quot;line-content&quot;&gt;\r\n				&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;br /&amp;gt;&lt;/span&gt;\r\n			&lt;/td&gt;\r\n		&lt;/tr&gt;\r\n		&lt;tr&gt;\r\n			&lt;td class=&quot;line-number&quot;&gt;\r\n			&lt;/td&gt;\r\n			&lt;td class=&quot;line-content&quot;&gt;\r\n				&lt;span class=&quot;html-comment&quot;&gt;&amp;lt;!-- Login form --&amp;gt;&lt;/span&gt;\r\n			&lt;/td&gt;\r\n		&lt;/tr&gt;\r\n		&lt;tr&gt;\r\n			&lt;td class=&quot;line-number&quot;&gt;\r\n			&lt;/td&gt;\r\n			&lt;td class=&quot;line-content&quot;&gt;\r\n				&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;form &lt;span class=&quot;html-attribute-name&quot;&gt;method&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;post&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;action&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;index.php&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;name&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;login_form&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;class&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;disableAjax login hide js-show&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;\r\n			&lt;/td&gt;\r\n		&lt;/tr&gt;\r\n		&lt;tr&gt;\r\n			&lt;td class=&quot;line-number&quot;&gt;\r\n			&lt;/td&gt;\r\n			&lt;td class=&quot;line-content&quot;&gt;\r\n				&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;fieldset&amp;gt;&lt;/span&gt;\r\n			&lt;/td&gt;\r\n		&lt;/tr&gt;\r\n		&lt;tr&gt;\r\n			&lt;td class=&quot;line-number&quot;&gt;\r\n			&lt;/td&gt;\r\n			&lt;td class=&quot;line-content&quot;&gt;\r\n				&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;legend&amp;gt;&lt;/span&gt;登录&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;a &lt;span class=&quot;html-attribute-name&quot;&gt;href&lt;/span&gt;=&quot;&lt;a class=&quot;html-attribute-value html-external-link&quot; target=&quot;_blank&quot; href=&quot;http://localhost/phpmyadmin/doc/html/index.html&quot;&gt;./doc/html/index.html&lt;/a&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;target&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;documentation&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;img &lt;span class=&quot;html-attribute-name&quot;&gt;src&lt;/span&gt;=&quot;&lt;a class=&quot;html-attribute-value html-resource-link&quot; target=&quot;_blank&quot; href=&quot;http://localhost/phpmyadmin/themes/dot.gif&quot;&gt;themes/dot.gif&lt;/a&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;title&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;文档&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;alt&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;文档&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;class&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;icon ic_b_help&lt;/span&gt;&quot; /&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/a&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/legend&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;div &lt;span class=&quot;html-attribute-name&quot;&gt;class&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;item&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;\r\n			&lt;/td&gt;\r\n		&lt;/tr&gt;\r\n		&lt;tr&gt;\r\n			&lt;td class=&quot;line-number&quot;&gt;\r\n			&lt;/td&gt;\r\n			&lt;td class=&quot;line-content&quot;&gt;\r\n				&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;label &lt;span class=&quot;html-attribute-name&quot;&gt;for&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;input_username&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;用户名：&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/label&amp;gt;&lt;/span&gt;\r\n			&lt;/td&gt;\r\n		&lt;/tr&gt;\r\n		&lt;tr&gt;\r\n			&lt;td class=&quot;line-number&quot;&gt;\r\n			&lt;/td&gt;\r\n			&lt;td class=&quot;line-content&quot;&gt;\r\n				&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;input &lt;span class=&quot;html-attribute-name&quot;&gt;type&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;text&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;name&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;pma_username&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;id&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;input_username&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;root&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;size&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;24&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;class&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;textfield&lt;/span&gt;&quot;/&amp;gt;&lt;/span&gt;\r\n			&lt;/td&gt;\r\n		&lt;/tr&gt;\r\n		&lt;tr&gt;\r\n			&lt;td class=&quot;line-number&quot;&gt;\r\n			&lt;/td&gt;\r\n			&lt;td class=&quot;line-content&quot;&gt;\r\n				&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/div&amp;gt;&lt;/span&gt;\r\n			&lt;/td&gt;\r\n		&lt;/tr&gt;\r\n		&lt;tr&gt;\r\n			&lt;td class=&quot;line-number&quot;&gt;\r\n			&lt;/td&gt;\r\n			&lt;td class=&quot;line-content&quot;&gt;\r\n				&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;div &lt;span class=&quot;html-attribute-name&quot;&gt;class&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;item&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;\r\n			&lt;/td&gt;\r\n		&lt;/tr&gt;\r\n		&lt;tr&gt;\r\n			&lt;td class=&quot;line-number&quot;&gt;\r\n			&lt;/td&gt;\r\n			&lt;td class=&quot;line-content&quot;&gt;\r\n				&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;label &lt;span class=&quot;html-attribute-name&quot;&gt;for&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;input_password&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;密码：&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/label&amp;gt;&lt;/span&gt;\r\n			&lt;/td&gt;\r\n		&lt;/tr&gt;\r\n		&lt;tr&gt;\r\n			&lt;td class=&quot;line-number&quot;&gt;\r\n			&lt;/td&gt;\r\n			&lt;td class=&quot;line-content&quot;&gt;\r\n				&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;input &lt;span class=&quot;html-attribute-name&quot;&gt;type&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;password&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;name&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;pma_password&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;id&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;input_password&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;size&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;24&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;class&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;textfield&lt;/span&gt;&quot; /&amp;gt;&lt;/span&gt;\r\n			&lt;/td&gt;\r\n		&lt;/tr&gt;\r\n		&lt;tr&gt;\r\n			&lt;td class=&quot;line-number&quot;&gt;\r\n			&lt;/td&gt;\r\n			&lt;td class=&quot;line-content&quot;&gt;\r\n				&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/div&amp;gt;&lt;/span&gt; &lt;span class=&quot;html-tag&quot;&gt;&amp;lt;input &lt;span class=&quot;html-attribute-name&quot;&gt;type&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;hidden&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;name&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;server&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;1&lt;/span&gt;&quot; /&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/fieldset&amp;gt;&lt;/span&gt;\r\n			&lt;/td&gt;\r\n		&lt;/tr&gt;\r\n		&lt;tr&gt;\r\n			&lt;td class=&quot;line-number&quot;&gt;\r\n			&lt;/td&gt;\r\n			&lt;td class=&quot;line-content&quot;&gt;\r\n				&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;fieldset &lt;span class=&quot;html-attribute-name&quot;&gt;class&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;tblFooters&lt;/span&gt;&quot;&amp;gt;&lt;/span&gt;\r\n			&lt;/td&gt;\r\n		&lt;/tr&gt;\r\n		&lt;tr&gt;\r\n			&lt;td class=&quot;line-number&quot;&gt;\r\n			&lt;/td&gt;\r\n			&lt;td class=&quot;line-content&quot;&gt;\r\n				&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;input &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;执行&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;type&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;submit&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;id&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;input_go&lt;/span&gt;&quot; /&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;input &lt;span class=&quot;html-attribute-name&quot;&gt;type&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;hidden&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;name&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;target&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;sql.php&lt;/span&gt;&quot; /&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;input &lt;span class=&quot;html-attribute-name&quot;&gt;type&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;hidden&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;name&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;db&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;j8830&lt;/span&gt;&quot; /&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;input &lt;span class=&quot;html-attribute-name&quot;&gt;type&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;hidden&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;name&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;table&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;xt_history&lt;/span&gt;&quot; /&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;input &lt;span class=&quot;html-attribute-name&quot;&gt;type&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;hidden&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;name&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;token&lt;/span&gt;&quot; &lt;span class=&quot;html-attribute-name&quot;&gt;value&lt;/span&gt;=&quot;&lt;span class=&quot;html-attribute-value&quot;&gt;23c7bcd9770df110efa1c8a54933f42a&lt;/span&gt;&quot; /&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/fieldset&amp;gt;&lt;/span&gt;\r\n			&lt;/td&gt;\r\n		&lt;/tr&gt;\r\n		&lt;tr&gt;\r\n			&lt;td class=&quot;line-number&quot;&gt;\r\n			&lt;/td&gt;\r\n			&lt;td class=&quot;line-content&quot;&gt;\r\n				&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/form&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/div&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/div&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/body&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-tag&quot;&gt;&amp;lt;/html&amp;gt;&lt;/span&gt;&lt;span class=&quot;html-end-of-file&quot;&gt;&lt;/span&gt;\r\n			&lt;/td&gt;\r\n		&lt;/tr&gt;\r\n	&lt;/tbody&gt;\r\n&lt;/table&gt;', '0', '0', '', '1536373286', '1536373286', '1');

-- -----------------------------
-- Table structure for `xt_article_category`
-- -----------------------------
DROP TABLE IF EXISTS `xt_article_category`;
CREATE TABLE `xt_article_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `describe` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态',
  `icon` char(20) NOT NULL DEFAULT '' COMMENT '分类图标',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='分类表';

-- -----------------------------
-- Records of `xt_article_category`
-- -----------------------------
INSERT INTO `xt_article_category` VALUES ('7', '报单产品', '报单产品', '1509620712', '1536146329', '-1', 'fa-street-view');
INSERT INTO `xt_article_category` VALUES ('8', '后台介绍', '后台功能介绍', '1509792822', '1509792822', '1', 'fa-user');

-- -----------------------------
-- Table structure for `xt_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `xt_auth_group`;
CREATE TABLE `xt_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `module` varchar(20) NOT NULL DEFAULT '' COMMENT '用户组所属模块',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '用户组名称',
  `describe` varchar(80) NOT NULL DEFAULT '' COMMENT '描述信息',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户组状态：为1正常，为0禁用,-1为删除',
  `rules` varchar(1000) NOT NULL DEFAULT '' COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='权限组表';

-- -----------------------------
-- Records of `xt_auth_group`
-- -----------------------------
INSERT INTO `xt_auth_group` VALUES ('3', '', '普通会员', '', '1', '1,225,226,229,227,228,246,234,235,236,237,242,232,238,231,239,230,243,233,198,210,221', '1', '1536923655', '1536060679');
INSERT INTO `xt_auth_group` VALUES ('4', '', '报单中心', '', '1', '1,225,226,229,227,228,240,246,234,235,236,237,242,232,238,231,239,230,243,233,198,210,221', '1', '1536923669', '1536062691');

-- -----------------------------
-- Table structure for `xt_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `xt_auth_group_access`;
CREATE TABLE `xt_auth_group_access` (
  `member_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `group_id` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '用户组id',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户组授权表';

-- -----------------------------
-- Records of `xt_auth_group_access`
-- -----------------------------
INSERT INTO `xt_auth_group_access` VALUES ('94', '3', '1536930208', '1536930208', '1');
INSERT INTO `xt_auth_group_access` VALUES ('95', '3', '1536930261', '1536930261', '1');
INSERT INTO `xt_auth_group_access` VALUES ('96', '3', '1536930299', '1536930299', '1');
INSERT INTO `xt_auth_group_access` VALUES ('97', '3', '1536930349', '1536930349', '1');
INSERT INTO `xt_auth_group_access` VALUES ('97', '4', '1536930349', '1536930349', '1');
INSERT INTO `xt_auth_group_access` VALUES ('98', '3', '1536930413', '1536930413', '1');

-- -----------------------------
-- Table structure for `xt_blogroll`
-- -----------------------------
DROP TABLE IF EXISTS `xt_blogroll`;
CREATE TABLE `xt_blogroll` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(50) NOT NULL DEFAULT '' COMMENT '链接名称',
  `img_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '链接图片封面',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `describe` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='友情链接表';


-- -----------------------------
-- Table structure for `xt_bonus`
-- -----------------------------
DROP TABLE IF EXISTS `xt_bonus`;
CREATE TABLE `xt_bonus` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `times_id` bigint(20) NOT NULL COMMENT '期号，对应times表的id',
  `member_id` int(10) unsigned NOT NULL COMMENT '会员id',
  `username` char(50) NOT NULL DEFAULT '' COMMENT '会员账号',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `data_status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态',
  `b0` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '奖0',
  `b1` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '奖1',
  `b2` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '奖2',
  `b3` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '奖3',
  `b4` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '奖4',
  `b5` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '奖5',
  `b6` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '奖6',
  `b7` decimal(12,2) NOT NULL DEFAULT '0.00',
  `b8` decimal(12,2) NOT NULL DEFAULT '0.00',
  `b9` decimal(12,2) NOT NULL DEFAULT '0.00',
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=491 DEFAULT CHARSET=utf8 COMMENT='奖金表';

-- -----------------------------
-- Records of `xt_bonus`
-- -----------------------------
INSERT INTO `xt_bonus` VALUES ('485', '384', '94', '1', '1536930214', '0', '1', '0.00', '250.00', '6.00', '0.00', '400.00', '590.00', '0.00', '-124.00', '0.00', '0.00', '0');
INSERT INTO `xt_bonus` VALUES ('486', '384', '1', '100000', '1536930214', '0', '1', '0.00', '100.00', '0.00', '0.00', '300.00', '610.00', '1830.00', '-284.00', '0.00', '0.00', '0');
INSERT INTO `xt_bonus` VALUES ('487', '384', '95', '2', '1536930268', '0', '1', '0.00', '2600.00', '15.00', '2000.00', '0.00', '540.00', '0.00', '-514.00', '0.00', '0.00', '0');
INSERT INTO `xt_bonus` VALUES ('488', '384', '96', '3', '1536930307', '0', '1', '0.00', '100.00', '6.00', '0.00', '0.00', '20.00', '0.00', '-12.00', '0.00', '0.00', '0');
INSERT INTO `xt_bonus` VALUES ('489', '384', '97', '4', '1536930421', '0', '1', '0.00', '0.00', '150.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0');
INSERT INTO `xt_bonus` VALUES ('490', '384', '98', '6', '1536930425', '0', '1', '0.00', '0.00', '6.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0');

-- -----------------------------
-- Table structure for `xt_config`
-- -----------------------------
DROP TABLE IF EXISTS `xt_config`;
CREATE TABLE `xt_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置标题',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '配置选项',
  `describe` varchar(255) NOT NULL DEFAULT '' COMMENT '配置说明',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `value` text NOT NULL COMMENT '配置值',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `type` (`type`),
  KEY `group` (`group`)
) ENGINE=MyISAM AUTO_INCREMENT=87 DEFAULT CHARSET=utf8 COMMENT='配置表';

-- -----------------------------
-- Records of `xt_config`
-- -----------------------------
INSERT INTO `xt_config` VALUES ('1', 'seo_title', '1', '网站标题', '3', '', '', '1378898976', '1536737230', '1', '高原圣果', '3');
INSERT INTO `xt_config` VALUES ('2', 'seo_description', '2', '网站描述', '3', '', '', '1378898976', '1536231283', '1', '高原圣果', '100');
INSERT INTO `xt_config` VALUES ('3', 'seo_keywords', '2', '网站关键字', '3', '', '菩善春天', '1378898976', '1536230896', '1', '高原圣果', '99');
INSERT INTO `xt_config` VALUES ('9', 'config_type_list', '3', '配置类型列表', '3', '', '主要用于数据解析和页面表单的生成', '1378898976', '1536737230', '1', '0:数字\r\n1:字符\r\n2:文本\r\n3:数组\r\n4:枚举\r\n5:图片\r\n6:文件\r\n7:富文本\r\n8:单选\r\n9:多选\r\n10:日期\r\n11:时间\r\n12:颜色', '100');
INSERT INTO `xt_config` VALUES ('20', 'config_group_list', '3', '配置分组', '3', '', '配置分组', '1379228036', '1536737230', '1', '1:参数设置', '100');
INSERT INTO `xt_config` VALUES ('25', 'list_rows', '0', '每页数据记录数', '2', '', '数据每页显示记录数', '1379503896', '1536544339', '1', '10', '10');
INSERT INTO `xt_config` VALUES ('29', 'data_backup_part_size', '0', '数据库备份卷大小', '2', '', '该值用于限制压缩后的分卷最大长度。单位：B', '1381482488', '1536544339', '1', '52428800', '7');
INSERT INTO `xt_config` VALUES ('30', 'data_backup_compress', '4', '数据库备份文件是否启用压缩', '2', '0:不压缩\r\n1:启用压缩', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '1381713345', '1536544339', '1', '1', '9');
INSERT INTO `xt_config` VALUES ('31', 'data_backup_compress_level', '4', '数据库备份文件压缩级别', '2', '1:普通\r\n4:一般\r\n9:最高', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '1381713408', '1536544339', '1', '9', '10');
INSERT INTO `xt_config` VALUES ('33', 'allow_url', '3', '不受权限验证的url', '3', '', '', '1386644047', '1536737230', '1', '0:file/pictureupload\r\n1:addon/execute', '100');
INSERT INTO `xt_config` VALUES ('43', 'empty_list_describe', '1', '数据列表为空时的描述信息', '2', '', '', '1492278127', '1536544339', '1', 'aOh! 暂时还没有数据~', '0');
INSERT INTO `xt_config` VALUES ('44', 'trash_config', '3', '回收站配置', '3', '', 'key为模型名称，值为显示列。', '1492312698', '1536737230', '1', 'Config:name\r\nAuthGroup:name\r\nMember:nickname\r\nMenu:name\r\nArticle:name\r\nArticleCategory:name\r\nAddon:name\r\nPicture:name\r\nFile:name\r\nActionLog:describe\r\nApi:name\r\nApiGroup:name\r\nBlogroll:name\r\nExeLog:exe_url\r\nSeo:name', '0');
INSERT INTO `xt_config` VALUES ('49', 'static_domain', '1', '静态资源域名', '0', '', '若静态资源为本地资源则此项为空，若为外部资源则为存放静态资源的域名', '1502430387', '1536124701', '1', '', '0');
INSERT INTO `xt_config` VALUES ('52', 'team_developer', '3', '研发团队人员', '4', '', '', '1504236453', '1510894595', '1', '0:Bigotry\r\n1:扫地僧', '0');
INSERT INTO `xt_config` VALUES ('53', 'api_status_option', '3', 'API接口状态', '4', '', '', '1504242433', '1510894595', '1', '0:待研发\r\n1:研发中\r\n2:测试中\r\n3:已完成', '0');
INSERT INTO `xt_config` VALUES ('54', 'api_data_type_option', '3', 'API数据类型', '4', '', '', '1504328208', '1510894595', '1', '0:字符\r\n1:文本\r\n2:数组\r\n3:文件', '0');
INSERT INTO `xt_config` VALUES ('55', 'frontend_theme', '1', '前端主题', '1', '', '', '1504762360', '1534571556', '-1', 'default', '0');
INSERT INTO `xt_config` VALUES ('56', 'api_domain', '1', 'API部署域名', '4', '', '', '1504779094', '1510894595', '1', 'https://demo.onebase.org', '0');
INSERT INTO `xt_config` VALUES ('57', 'api_key', '1', 'API加密KEY', '4', '', '泄露后API将存在安全隐患', '1505302112', '1510894595', '1', 'l2V|gfZp{8`;jzR~6Y1_', '0');
INSERT INTO `xt_config` VALUES ('58', 'loading_icon', '4', '页面Loading图标设置', '0', '1:图标1\r\n2:图标2\r\n3:图标3\r\n4:图标4\r\n5:图标5\r\n6:图标6\r\n7:图标7', '页面Loading图标支持7种图标切换', '1505377202', '1536124784', '1', '7', '80');
INSERT INTO `xt_config` VALUES ('59', 'sys_file_field', '3', '文件字段配置', '3', '', 'key为模型名，值为文件列名。', '1505799386', '1536737230', '1', '0_article:file_id', '0');
INSERT INTO `xt_config` VALUES ('60', 'sys_picture_field', '3', '图片字段配置', '3', '', 'key为模型名，值为图片列名。', '1506315422', '1536737230', '1', '0_article:cover_id\r\n1_article:img_ids', '0');
INSERT INTO `xt_config` VALUES ('61', 'jwt_key', '1', 'JWT加密KEY', '4', '', '', '1506748805', '1510894595', '1', 'l2V|DSFXXXgfZp{8`;FjzR~6Y1_', '0');
INSERT INTO `xt_config` VALUES ('64', 'is_write_exe_log', '4', '是否写入执行记录', '3', '0:否\r\n1:是', '', '1510544340', '1536737230', '1', '1', '101');
INSERT INTO `xt_config` VALUES ('65', 'admin_allow_ip', '3', '超级管理员登录IP', '3', '', '后台超级管理员登录IP限制，其他角色不受限。', '1510995580', '1536737230', '1', '0:27.22.112.250', '0');
INSERT INTO `xt_config` VALUES ('66', 'pjax_mode', '8', 'PJAX模式', '3', '0:否\r\n1:是', '若为PJAX模式则浏览器不会刷新，若为常规模式则为AJAX+刷新', '1512370397', '1536737230', '1', '0', '120');
INSERT INTO `xt_config` VALUES ('67', 'reco', '2', '推荐奖比例（百分比）', '1', '', '', '1533280243', '1536927983', '1', '5', '0');
INSERT INTO `xt_config` VALUES ('68', 'cpzj', '2', '注册金额', '1', '', '注册金额的多少', '1533294825', '1536927983', '1', '2000|5000|10000|30000|50000', '0');
INSERT INTO `xt_config` VALUES ('69', 'treeplace', '2', '左中右区设置', '0', '', '相对于上级 的哪个区域', '1533295624', '1536127967', '1', '0-左|1-中|2-右', '0');
INSERT INTO `xt_config` VALUES ('70', 'vip_level', '2', '会员级别', '0', '', '会员的级别', '1533355032', '1536738017', '1', '2000会员|5000会员|10000会员|30000会员|50000会员', '0');
INSERT INTO `xt_config` VALUES ('71', 'type_name', '2', '奖项名称显示', '0', '', '', '1533871065', '1536737822', '1', '50-充值奖金币|30-转账奖金币|21-激活会员|1-直推奖|2-积分发放|3-业绩奖|4-管理奖|5-滑落奖|6-报单奖|7-扣税|90-左区业绩增加|91-右区业绩增加|66-提现驳回', '0');
INSERT INTO `xt_config` VALUES ('73', 'is_agent', '2', '报单中心配置', '0', '', '', '1536109819', '1536301993', '1', '1-普通会员|2-报单中心', '65535');
INSERT INTO `xt_config` VALUES ('72', 'agent_income', '2', '代理商提成', '1', '', '按身份证所在归属地，得利润（省|市|县）', '1534571441', '1536110329', '-1', '3-10|2-7|1-5', '0');
INSERT INTO `xt_config` VALUES ('74', 's_ratio', '2', '沙棘链比例（注册金额-百分比）', '1', '', '', '1536110316', '1536927983', '1', '2000-1.5|5000-1.5|10000-2|30000-2.5|50000-3', '0');
INSERT INTO `xt_config` VALUES ('75', 'everyday_time', '2', '每日时间', '0', '', '每日发奖后更新时间', '1536110905', '1536124662', '1', '1536854400', '0');
INSERT INTO `xt_config` VALUES ('76', 'achievement', '2', '业绩奖（百分比）', '1', '', '左右区和', '1536121084', '1536927983', '1', '7', '0');
INSERT INTO `xt_config` VALUES ('77', 'manage', '2', '管理奖（代数-百分比）', '1', '', '拿下几代会员的业绩奖', '1536124636', '1536927983', '1', '1-20|2-15|3-10', '0');
INSERT INTO `xt_config` VALUES ('78', 'see_you', '2', '滑落奖（注册金额-层数）', '1', '', '', '1536125806', '1536927983', '1', '2000-8|5000-9|10000-10|30000-12|50000-15\r\n', '0');
INSERT INTO `xt_config` VALUES ('79', 'see_you_ratio', '2', '滑落奖（百分比）', '1', '', '', '1536126087', '1536927983', '1', '1', '0');
INSERT INTO `xt_config` VALUES ('80', 'agent_center', '2', '报单奖比例（百分比）', '1', '', '', '1536130873', '1536927983', '1', '3', '0');
INSERT INTO `xt_config` VALUES ('81', 'tax', '2', '税比例（百分比）', '1', '', '', '1536132648', '1536927983', '1', '10', '0');
INSERT INTO `xt_config` VALUES ('82', 'money_type', '2', '钱包-奖', '0', '', '什么奖进入什么钱包', '1536280719', '1536737846', '1', '1-奖金币钱包|2-积分钱包|3-奖金币钱包|4-奖金币钱包|5-奖金币钱包|6-奖金币钱包|7-奖金币钱包|66-奖金币钱包', '0');
INSERT INTO `xt_config` VALUES ('83', 'bank', '2', '银行', '1', '', '', '1536631030', '1536927983', '1', '中国工商银行|中国银行|中国农业银行|中国建设银行|中国邮政储蓄银行|广发银行|浦发银行|平安银行|交通银行|招商银行|兴业银行\'|中信银行|民生银行|光大银行', '0');
INSERT INTO `xt_config` VALUES ('84', 'poundage', '2', '提现手续费比例（百分比）', '1', '', '', '1536657697', '1536927983', '1', '20', '0');
INSERT INTO `xt_config` VALUES ('85', '31231', '5', '12323', '1', '', '', '1536740530', '1536740597', '-1', '', '0');
INSERT INTO `xt_config` VALUES ('86', 'sj_ratio', '2', '沙棘链比例范围', '1', '', '', '1536927739', '1536927983', '1', '3', '30');

-- -----------------------------
-- Table structure for `xt_draw`
-- -----------------------------
DROP TABLE IF EXISTS `xt_draw`;
CREATE TABLE `xt_draw` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `uid` mediumint(8) NOT NULL DEFAULT '0' COMMENT '用户id',
  `ctime` int(11) DEFAULT '0',
  `num` int(11) DEFAULT '0',
  `name` varchar(20) CHARACTER SET utf8 NOT NULL COMMENT '支付宝验证名',
  `card` varchar(30) CHARACTER SET utf8 NOT NULL COMMENT '支付宝账号',
  `bank_name` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `kaihu` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `content` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0' COMMENT '状态0代表未审核 1代表已完成 2代表驳回',
  `order_id` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `issq` tinyint(1) DEFAULT '0',
  `error` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `type` tinyint(1) DEFAULT '0',
  `text` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;


-- -----------------------------
-- Table structure for `xt_driver`
-- -----------------------------
DROP TABLE IF EXISTS `xt_driver`;
CREATE TABLE `xt_driver` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `service_name` varchar(40) NOT NULL DEFAULT '' COMMENT '服务标识',
  `driver_name` varchar(20) NOT NULL DEFAULT '' COMMENT '驱动标识',
  `config` text NOT NULL COMMENT '配置',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='插件表';


-- -----------------------------
-- Table structure for `xt_exe_log`
-- -----------------------------
DROP TABLE IF EXISTS `xt_exe_log`;
CREATE TABLE `xt_exe_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `ip` char(50) NOT NULL DEFAULT '' COMMENT 'IP地址',
  `exe_url` varchar(2000) NOT NULL DEFAULT '' COMMENT '执行URL',
  `exe_time` float(10,6) unsigned NOT NULL DEFAULT '0.000000' COMMENT '执行时间 单位 秒',
  `exe_memory` char(20) NOT NULL DEFAULT '' COMMENT '内存占用KB',
  `exe_os` char(30) NOT NULL DEFAULT '' COMMENT '操作系统',
  `source_url` varchar(2000) NOT NULL DEFAULT '' COMMENT '来源URL',
  `session_id` char(32) NOT NULL DEFAULT '' COMMENT 'session_id',
  `browser` char(30) NOT NULL DEFAULT '' COMMENT '浏览器',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  `login_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '执行者ID',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '类型  0 ： 应用范围 ， 1：API 范围 ',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17227 DEFAULT CHARSET=utf8 COMMENT='执行记录表';

-- -----------------------------
-- Records of `xt_exe_log`
-- -----------------------------
INSERT INTO `xt_exe_log` VALUES ('17222', '192.168.0.197', '/s8726/public/admin/statistic/exespeed.html?_pjax=.content', '0.17301', '2.31 MB', 'Windows', 'http://192.168.0.197/s8726/public/admin/index/index.html', '17tq6r8q7bgb2vcqtu95du7tg0', 'Chrome', '1', '1534328025', '1534328025', '1', '0');
INSERT INTO `xt_exe_log` VALUES ('17223', '192.168.0.197', '/s8726/public/index/index/index.html?_pjax=.content', '0.093005', '2.22 MB', 'Windows', 'http://192.168.0.197/s8726/public/admin/statistic/exespeed.html', '17tq6r8q7bgb2vcqtu95du7tg0', 'Chrome', '1', '1534328033', '1534328033', '1', '0');
INSERT INTO `xt_exe_log` VALUES ('17224', '192.168.0.197', '/s8726/public/index/index/index.html', '0.102006', '2.26 MB', 'Windows', 'http://192.168.0.197/s8726/public/admin/statistic/exespeed.html', '17tq6r8q7bgb2vcqtu95du7tg0', 'Chrome', '1', '1534328033', '1534328033', '1', '0');
INSERT INTO `xt_exe_log` VALUES ('17225', '192.168.0.197', '/s8726/public/admin/index/index.html', '0.223013', '2.02 MB', 'Windows', 'http://192.168.0.197/s8726/public/index/index/index.html', '17tq6r8q7bgb2vcqtu95du7tg0', 'Chrome', '1', '1534328034', '1534328034', '1', '0');
INSERT INTO `xt_exe_log` VALUES ('17226', '192.168.0.197', '/s8726/public/admin/exelog/applist.html?_pjax=.content', '0.185011', '2.19 MB', 'Windows', 'http://192.168.0.197/s8726/public/admin/index/index.html', '17tq6r8q7bgb2vcqtu95du7tg0', 'Chrome', '1', '1534328050', '1534328050', '1', '0');

-- -----------------------------
-- Table structure for `xt_file`
-- -----------------------------
DROP TABLE IF EXISTS `xt_file`;
CREATE TABLE `xt_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '原始文件名',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '保存名称',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '远程地址',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '上传时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='文件表';

-- -----------------------------
-- Records of `xt_file`
-- -----------------------------
INSERT INTO `xt_file` VALUES ('1', '8cf1200e7587bd072a0dbc5ccc628bee.jpg', '20180823/8cf1200e7587bd072a0dbc5ccc628bee.jpg', '', '15b49f44d67d54111648596bf95e21e68a37b814', '1535006559', '0', '1');
INSERT INTO `xt_file` VALUES ('2', '8f322ac6d3678332bed4a5c82052ff57.jpg', '20180823/8f322ac6d3678332bed4a5c82052ff57.jpg', '', '2f2108c930c69861f55a4479de3b40bc18fcef43', '1535006567', '0', '1');
INSERT INTO `xt_file` VALUES ('3', '42abf306fe95e8a745d473af4ba0804c.jpg', '20180823/42abf306fe95e8a745d473af4ba0804c.jpg', '', 'f0c7066ecbd16879194bc49500eb4cd6db6ef667', '1535006614', '0', '1');

-- -----------------------------
-- Table structure for `xt_history`
-- -----------------------------
DROP TABLE IF EXISTS `xt_history`;
CREATE TABLE `xt_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `user_id` varchar(50) DEFAULT NULL,
  `did` int(11) NOT NULL,
  `user_did` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `action_type` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `pdt` int(11) NOT NULL,
  `epoints` decimal(12,2) NOT NULL DEFAULT '0.00',
  `allp` decimal(12,2) NOT NULL DEFAULT '0.00',
  `bz` text,
  `type` smallint(1) NOT NULL COMMENT '充值0明细1',
  `act_pdt` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL,
  `issq` int(11) NOT NULL,
  `text` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`action_type`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=1795 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `xt_history`
-- -----------------------------
INSERT INTO `xt_history` VALUES ('1720', '1', '100000', '94', '1', '21', '1536930214', '-2000.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1721', '94', '1', '94', '1', '2', '1536930214', '6.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1722', '1', '100000', '94', '1', '1', '1536930214', '100.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1723', '1', '100000', '1', '100000', '7', '1536930214', '-10.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1724', '1', '100000', '94', '1', '5', '1536930214', '20.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1725', '1', '100000', '1', '100000', '7', '1536930214', '-2.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1726', '1', '100000', '94', '1', '6', '1536930214', '60.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1727', '1', '100000', '1', '100000', '7', '1536930214', '-6.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1728', '1', '100000', '94', '1', '90', '1536930215', '2000.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1729', '1', '100000', '95', '2', '21', '1536930269', '-5000.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1730', '95', '2', '95', '2', '2', '1536930269', '15.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1731', '94', '1', '95', '2', '1', '1536930269', '250.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1732', '94', '1', '94', '1', '7', '1536930269', '-25.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1733', '94', '1', '95', '2', '5', '1536930269', '50.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1734', '94', '1', '94', '1', '7', '1536930269', '-5.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1735', '1', '100000', '95', '2', '5', '1536930269', '50.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1736', '1', '100000', '1', '100000', '7', '1536930269', '-5.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1737', '1', '100000', '95', '2', '6', '1536930269', '150.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1738', '1', '100000', '1', '100000', '7', '1536930269', '-15.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1739', '94', '1', '95', '2', '90', '1536930269', '5000.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1740', '1', '100000', '95', '2', '90', '1536930269', '5000.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1741', '1', '100000', '96', '3', '21', '1536930307', '-2000.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1742', '96', '3', '96', '3', '2', '1536930307', '6.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1743', '95', '2', '96', '3', '1', '1536930307', '100.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1744', '95', '2', '95', '2', '7', '1536930307', '-10.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1745', '95', '2', '96', '3', '5', '1536930307', '20.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1746', '95', '2', '95', '2', '7', '1536930307', '-2.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1747', '94', '1', '96', '3', '5', '1536930307', '20.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1748', '94', '1', '94', '1', '7', '1536930307', '-2.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1749', '1', '100000', '96', '3', '5', '1536930307', '20.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1750', '1', '100000', '1', '100000', '7', '1536930307', '-2.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1751', '1', '100000', '96', '3', '6', '1536930307', '60.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1752', '1', '100000', '1', '100000', '7', '1536930307', '-6.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1753', '95', '2', '96', '3', '90', '1536930308', '2000.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1754', '94', '1', '96', '3', '90', '1536930308', '2000.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1755', '1', '100000', '96', '3', '90', '1536930308', '2000.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1756', '1', '100000', '97', '4', '21', '1536930421', '-50000.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1757', '97', '4', '97', '4', '2', '1536930421', '150.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1758', '95', '2', '97', '4', '1', '1536930421', '2500.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1759', '95', '2', '95', '2', '7', '1536930421', '-250.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1760', '95', '2', '97', '4', '5', '1536930421', '500.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1761', '95', '2', '95', '2', '7', '1536930421', '-50.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1762', '94', '1', '97', '4', '5', '1536930421', '500.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1763', '94', '1', '94', '1', '7', '1536930421', '-50.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1764', '1', '100000', '97', '4', '5', '1536930422', '500.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1765', '1', '100000', '1', '100000', '7', '1536930422', '-50.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1766', '1', '100000', '97', '4', '6', '1536930422', '1500.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1767', '1', '100000', '1', '100000', '7', '1536930422', '-150.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1768', '95', '2', '97', '4', '91', '1536930422', '50000.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1769', '94', '1', '97', '4', '90', '1536930422', '50000.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1770', '1', '100000', '97', '4', '90', '1536930422', '50000.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1771', '1', '100000', '98', '6', '21', '1536930425', '-2000.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1772', '98', '6', '98', '6', '2', '1536930425', '6.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1773', '96', '3', '98', '6', '1', '1536930425', '100.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1774', '96', '3', '96', '3', '7', '1536930425', '-10.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1775', '96', '3', '98', '6', '5', '1536930425', '20.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1776', '96', '3', '96', '3', '7', '1536930425', '-2.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1777', '95', '2', '98', '6', '5', '1536930425', '20.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1778', '95', '2', '95', '2', '7', '1536930425', '-2.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1779', '94', '1', '98', '6', '5', '1536930425', '20.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1780', '94', '1', '94', '1', '7', '1536930425', '-2.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1781', '1', '100000', '98', '6', '5', '1536930425', '20.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1782', '1', '100000', '1', '100000', '7', '1536930425', '-2.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1783', '1', '100000', '98', '6', '6', '1536930425', '60.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1784', '1', '100000', '1', '100000', '7', '1536930425', '-6.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1785', '96', '3', '98', '6', '90', '1536930425', '2000.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1786', '95', '2', '98', '6', '90', '1536930425', '2000.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1787', '94', '1', '98', '6', '90', '1536930426', '2000.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1788', '1', '100000', '98', '6', '90', '1536930426', '2000.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1789', '95', '2', '95', '2', '3', '1536930439', '2000.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1790', '95', '2', '95', '2', '7', '1536930439', '-200.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1791', '94', '1', '95', '2', '4', '1536930439', '400.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1792', '94', '1', '94', '1', '7', '1536930439', '-40.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1793', '1', '100000', '95', '2', '4', '1536930439', '300.00', '0.00', '无备注', '1', '0', '0', '0', '');
INSERT INTO `xt_history` VALUES ('1794', '1', '100000', '1', '100000', '7', '1536930439', '-30.00', '0.00', '无备注', '1', '0', '0', '0', '');

-- -----------------------------
-- Table structure for `xt_hook`
-- -----------------------------
DROP TABLE IF EXISTS `xt_hook`;
CREATE TABLE `xt_hook` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `describe` varchar(255) NOT NULL COMMENT '描述',
  `addon_list` varchar(255) NOT NULL DEFAULT '' COMMENT '钩子挂载的插件 ''，''分割',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 COMMENT='钩子表';

-- -----------------------------
-- Records of `xt_hook`
-- -----------------------------
INSERT INTO `xt_hook` VALUES ('36', 'File', '文件上传钩子', 'File', '1', '0', '0');
INSERT INTO `xt_hook` VALUES ('37', 'Icon', '图标选择钩子', 'Icon', '1', '0', '0');
INSERT INTO `xt_hook` VALUES ('38', 'ArticleEditor', '富文本编辑器', 'Editor', '1', '0', '0');

-- -----------------------------
-- Table structure for `xt_member`
-- -----------------------------
DROP TABLE IF EXISTS `xt_member`;
CREATE TABLE `xt_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `nickname` char(50) NOT NULL DEFAULT '' COMMENT '昵称',
  `username` char(16) NOT NULL DEFAULT '' COMMENT '用户名',
  `name` varchar(255) NOT NULL,
  `k_name` varchar(255) NOT NULL,
  `bank_name` varchar(255) NOT NULL,
  `bank_card` int(11) NOT NULL,
  `bank_d` varchar(255) NOT NULL,
  `password` char(32) NOT NULL DEFAULT '' COMMENT '密码',
  `password2` varchar(255) NOT NULL,
  `email` char(32) NOT NULL DEFAULT '' COMMENT '用户邮箱',
  `mobile` char(15) NOT NULL DEFAULT '' COMMENT '用户手机',
  `card` varchar(255) NOT NULL,
  `card_d` varchar(255) NOT NULL,
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `red_packet_time` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户状态',
  `leader_id` int(10) unsigned NOT NULL DEFAULT '1' COMMENT '上级会员ID',
  `address` text NOT NULL,
  `is_share_member` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否共享会员',
  `is_inside` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否为后台使用者',
  `user_id` varchar(255) NOT NULL,
  `cpzj` varchar(255) NOT NULL,
  `u_level` varchar(255) NOT NULL,
  `re_id` varchar(255) NOT NULL,
  `re_uid` varchar(255) NOT NULL,
  `re_path` varchar(255) NOT NULL,
  `re_level` varchar(255) NOT NULL,
  `re_nums` int(11) NOT NULL,
  `father_id` varchar(255) NOT NULL,
  `father_uid` varchar(255) NOT NULL,
  `p_path` varchar(255) NOT NULL DEFAULT ',',
  `p_level` varchar(255) NOT NULL DEFAULT '0',
  `is_pay` varchar(255) NOT NULL,
  `is_lock` varchar(255) NOT NULL,
  `day_feng` varchar(255) NOT NULL,
  `zone_a` int(11) NOT NULL,
  `zone_b` int(11) NOT NULL,
  `zone_c` int(11) NOT NULL,
  `l` int(11) NOT NULL,
  `xl` int(11) NOT NULL,
  `xxl` int(11) NOT NULL,
  `lr` int(11) NOT NULL,
  `treeplace` int(11) NOT NULL,
  `r` int(11) NOT NULL,
  `xr` int(11) NOT NULL,
  `xxr` int(11) NOT NULL,
  `qq` varchar(255) NOT NULL,
  `red_packet` int(11) NOT NULL,
  `b0` int(11) NOT NULL,
  `b1` int(11) NOT NULL,
  `b2` int(11) NOT NULL,
  `b3` int(11) NOT NULL,
  `b4` int(11) NOT NULL,
  `b5` int(11) NOT NULL,
  `b6` int(11) NOT NULL,
  `b7` int(11) NOT NULL,
  `b8` int(11) NOT NULL,
  `b9` int(11) NOT NULL,
  `b10` int(11) NOT NULL,
  `b11` int(11) NOT NULL,
  `b12` int(11) NOT NULL,
  `b13` int(11) NOT NULL,
  `b14` int(11) NOT NULL,
  `b15` int(11) NOT NULL,
  `b16` int(11) NOT NULL,
  `b17` int(11) NOT NULL,
  `b18` int(11) NOT NULL,
  `b19` int(11) NOT NULL,
  `b20` int(11) NOT NULL,
  `b21` int(11) NOT NULL,
  `b22` int(11) NOT NULL,
  `c0` int(11) NOT NULL,
  `c1` int(11) NOT NULL,
  `c2` int(11) NOT NULL,
  `c3` int(11) NOT NULL,
  `c4` int(11) NOT NULL,
  `c5` int(11) NOT NULL,
  `bank` varchar(255) NOT NULL,
  `agent` int(11) NOT NULL,
  `agent_level` int(11) NOT NULL,
  `weixin` varchar(255) NOT NULL,
  `re_money` int(11) NOT NULL,
  `team_money` int(11) NOT NULL,
  `is_agent` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `agent_uid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8 COMMENT='会员表';

-- -----------------------------
-- Records of `xt_member`
-- -----------------------------
INSERT INTO `xt_member` VALUES ('1', '100000', '100000', '王', 'ereyr ', '12', '45545', '2', '1', '1', '525630631@qq.com', '1855555071', '360822198305022623', '吉水县(区/县)', '1536934230', '1533267710', '1535299200', '1', '0', '', '0', '1', '100000', '10000', '1', '', '100000', '', '', '666', '', '', ',1,', '1', '1', '', '', '61000', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '41840', '0', '0', '0', '0', '0', '0', '-284', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '2', '4', '1', '1', '3888', '3888', '2', '0', '');
INSERT INTO `xt_member` VALUES ('94', '1', '1', '', '', '', '0', '', '111111', '222222', '', '13122222222', '', '', '1536930207', '1536930207', '0', '1', '1', '123', '0', '1', '1', '2000', '', '1', '100000', ',1', '1', '0', '1', '100000', ',1,,1', '2', '1', '', '', '59000', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '1240', '6', '0', '0', '0', '0', '0', '-124', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '', '0', '0', '1', '0', '100000');
INSERT INTO `xt_member` VALUES ('95', '2', '2', '', '', '', '0', '', '111111', '222222', '', '13888888888', '', '', '1536930261', '1536930261', '0', '1', '1', '13', '0', '1', '2', '5000', '', '94', '1', ',1,94', '2', '0', '94', '1', ',1,,1,94', '3', '1', '', '', '4000', '0', '50000', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '5140', '15', '0', '0', '0', '0', '0', '-514', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '', '0', '0', '1', '0', '100000');
INSERT INTO `xt_member` VALUES ('96', '3', '3', '', '', '', '0', '', '111111', '222222', '', '13888888888', '', '', '1536930299', '1536930299', '0', '1', '1', '131', '0', '1', '3', '2000', '', '95', '2', ',1,94,95', '3', '0', '95', '2', ',1,,1,94,95', '4', '1', '', '', '2000', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '120', '6', '0', '0', '0', '0', '0', '-12', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '', '0', '0', '1', '0', '100000');
INSERT INTO `xt_member` VALUES ('97', '4', '4', '', '', '', '0', '', '111111', '222222', '', '13888888888', '', '', '1536930349', '1536930349', '0', '1', '1', '123', '0', '1', '4', '50000', '', '95', '2', ',1,94,95', '3', '0', '95', '2', ',1,,1,94,95', '4', '1', '', '', '0', '0', '0', '0', '0', '0', '0', '2', '0', '0', '0', '', '0', '0', '150', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '', '0', '0', '2', '0', '100000');
INSERT INTO `xt_member` VALUES ('98', '6', '6', '', '', '', '0', '', '111111', '222222', '', '13888888888', '', '', '1536930413', '1536930413', '0', '1', '1', '123', '0', '1', '6', '2000', '', '96', '3', ',1,94,95,96', '4', '0', '96', '3', ',1,,1,94,95,96', '5', '1', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '6', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '', '0', '0', '1', '0', '100000');

-- -----------------------------
-- Table structure for `xt_menu`
-- -----------------------------
DROP TABLE IF EXISTS `xt_menu`;
CREATE TABLE `xt_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '菜单名称',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `module` char(20) NOT NULL DEFAULT '' COMMENT '模块',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `is_hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `icon` char(30) NOT NULL DEFAULT '' COMMENT '图标',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=247 DEFAULT CHARSET=utf8 COMMENT='菜单表';

-- -----------------------------
-- Records of `xt_menu`
-- -----------------------------
INSERT INTO `xt_menu` VALUES ('1', '我的信息', '0', '0', 'admin', 'index/index', '0', 'fa-home', '1', '1536195068', '0');
INSERT INTO `xt_menu` VALUES ('16', '会员管理', '68', '3', 'admin', 'member/index', '0', 'fa-users', '1', '1535966341', '0');
INSERT INTO `xt_menu` VALUES ('17', '会员列表', '16', '1', 'admin', 'member/memberlist', '0', 'fa-list', '1', '1495272875', '0');
INSERT INTO `xt_menu` VALUES ('18', '会员添加', '16', '2', 'admin', 'index/member_add', '0', 'fa-user-plus', '1', '1536051303', '0');
INSERT INTO `xt_menu` VALUES ('27', '权限管理', '16', '3', 'admin', 'auth/grouplist', '1', 'fa-key', '1', '1536736683', '0');
INSERT INTO `xt_menu` VALUES ('32', '权限组编辑', '27', '0', 'admin', 'auth/groupedit', '1', '', '1', '1536714365', '0');
INSERT INTO `xt_menu` VALUES ('34', '授权', '27', '0', 'admin', 'auth_manager/group', '1', '', '1', '1536714371', '0');
INSERT INTO `xt_menu` VALUES ('35', '菜单授权', '27', '0', 'admin', 'auth/menuauth', '1', '', '1', '1536714378', '0');
INSERT INTO `xt_menu` VALUES ('36', '会员授权', '27', '0', 'admin', 'auth_manager/memberaccess', '1', '', '1', '1536714391', '0');
INSERT INTO `xt_menu` VALUES ('68', '后台管理', '0', '7', 'admin', 'config/group', '0', 'fa-wrench', '1', '1535966266', '0');
INSERT INTO `xt_menu` VALUES ('69', '系统设置', '68', '18', 'admin', 'config/setting', '0', 'fa-cogs', '1', '1536728887', '0');
INSERT INTO `xt_menu` VALUES ('70', '配置管理', '68', '2', 'admin', 'config/index', '0', 'fa-cog', '-1', '1534495080', '0');
INSERT INTO `xt_menu` VALUES ('71', '配置编辑', '70', '0', 'admin', 'config/configedit', '1', '', '1', '1491674180', '0');
INSERT INTO `xt_menu` VALUES ('72', '配置删除', '70', '0', 'admin', 'config/configDel', '1', '', '1', '1491674201', '0');
INSERT INTO `xt_menu` VALUES ('73', '配置添加', '70', '0', 'admin', 'config/configadd', '0', 'fa-plus', '1', '1491666947', '0');
INSERT INTO `xt_menu` VALUES ('75', '菜单管理', '68', '5', 'admin', 'menu/index', '1', 'fa-th-large', '1', '1536921048', '0');
INSERT INTO `xt_menu` VALUES ('98', '菜单编辑', '75', '0', 'admin', 'menu/menuedit', '1', '', '1', '1512459021', '0');
INSERT INTO `xt_menu` VALUES ('108', '修改密码', '17', '0', 'admin', 'user/update_password', '1', '', '1', '0', '0');
INSERT INTO `xt_menu` VALUES ('109', '修改昵称', '17', '0', 'admin', 'user/update_nickname', '1', '', '1', '1491578211', '0');
INSERT INTO `xt_menu` VALUES ('124', '菜单列表', '75', '0', 'admin', 'menu/menulist', '0', 'fa-list', '1', '1534495527', '0');
INSERT INTO `xt_menu` VALUES ('125', '菜单添加', '75', '0', 'admin', 'menu/menuadd', '0', 'fa-plus', '1', '1491318307', '0');
INSERT INTO `xt_menu` VALUES ('126', '配置列表', '70', '0', 'admin', 'config/configlist', '0', 'fa-list', '1', '1491666890', '1491666890');
INSERT INTO `xt_menu` VALUES ('127', '菜单状态', '75', '0', 'admin', 'menu/setstatus', '1', '', '1', '1534495462', '1491674128');
INSERT INTO `xt_menu` VALUES ('128', '权限组添加', '27', '0', 'admin', 'auth/groupadd', '1', '', '1', '1536714384', '1492002635');
INSERT INTO `xt_menu` VALUES ('134', '授权', '17', '0', 'admin', 'member/memberauth', '1', '', '1', '1492238568', '1492101426');
INSERT INTO `xt_menu` VALUES ('135', '回收站', '68', '4', 'admin', 'trash/trashlist', '0', ' fa-recycle', '-1', '1534495127', '1492311462');
INSERT INTO `xt_menu` VALUES ('136', '回收站数据', '135', '0', 'admin', 'trash/trashdatalist', '1', 'fa-database', '1', '1492319477', '1492319392');
INSERT INTO `xt_menu` VALUES ('140', '服务管理', '68', '5', 'admin', 'service/servicelist', '1', 'fa-server', '1', '1535971054', '1492352972');
INSERT INTO `xt_menu` VALUES ('141', '插件管理', '68', '6', 'admin', 'addon/index', '1', 'fa-puzzle-piece', '1', '1535971039', '1492427605');
INSERT INTO `xt_menu` VALUES ('142', '钩子列表', '141', '0', 'admin', 'addon/hooklist', '0', 'fa-anchor', '1', '1492427665', '1492427665');
INSERT INTO `xt_menu` VALUES ('143', '插件列表', '141', '0', 'admin', 'addon/addonlist', '0', 'fa-list', '1', '1492428116', '1492427838');
INSERT INTO `xt_menu` VALUES ('144', '公告管理', '68', '4', 'admin', 'article/index', '0', 'fa-edit', '1', '1535971086', '1492480187');
INSERT INTO `xt_menu` VALUES ('145', '文章列表', '144', '0', 'admin', 'article/articlelist', '0', 'fa-list', '1', '1492480245', '1492480245');
INSERT INTO `xt_menu` VALUES ('146', '文章分类', '144', '0', 'admin', 'article/articlecategorylist', '0', 'fa-list', '1', '1492480359', '1492480342');
INSERT INTO `xt_menu` VALUES ('147', '文章分类编辑', '146', '0', 'admin', 'article/articlecategoryedit', '1', '', '1', '1492485294', '1492485294');
INSERT INTO `xt_menu` VALUES ('148', '分类添加', '144', '0', 'admin', 'article/articlecategoryadd', '0', 'fa-plus', '1', '1492486590', '1492486576');
INSERT INTO `xt_menu` VALUES ('149', '文章添加', '144', '0', 'admin', 'article/articleadd', '0', 'fa-plus', '1', '1492518453', '1492518453');
INSERT INTO `xt_menu` VALUES ('150', '文章编辑', '145', '0', 'admin', 'article/articleedit', '1', '', '1', '1492879589', '1492879589');
INSERT INTO `xt_menu` VALUES ('151', '插件安装', '143', '0', 'admin', 'addon/addoninstall', '1', '', '1', '1492879763', '1492879763');
INSERT INTO `xt_menu` VALUES ('152', '插件卸载', '143', '0', 'admin', 'addon/addonuninstall', '1', '', '1', '1492879789', '1492879789');
INSERT INTO `xt_menu` VALUES ('153', '文章删除', '145', '0', 'admin', 'article/articledel', '1', '', '1', '1492879960', '1492879960');
INSERT INTO `xt_menu` VALUES ('154', '文章分类删除', '146', '0', 'admin', 'article/articlecategorydel', '1', '', '1', '1492879995', '1492879995');
INSERT INTO `xt_menu` VALUES ('156', '驱动安装', '140', '0', 'admin', 'service/driverinstall', '0', '', '1', '1534495282', '1502267009');
INSERT INTO `xt_menu` VALUES ('157', '接口管理', '68', '5', 'admin', 'api/index', '1', 'fa fa-book', '1', '1535971048', '1504000434');
INSERT INTO `xt_menu` VALUES ('158', '分组管理', '157', '0', 'admin', 'api/apigrouplist', '0', 'fa fa-fw fa-th-list', '1', '1504000977', '1504000723');
INSERT INTO `xt_menu` VALUES ('159', '分组添加', '157', '0', 'admin', 'api/apigroupadd', '0', 'fa fa-fw fa-plus', '1', '1504004646', '1504004646');
INSERT INTO `xt_menu` VALUES ('160', '分组编辑', '157', '0', 'admin', 'api/apigroupedit', '1', '', '1', '1504004710', '1504004710');
INSERT INTO `xt_menu` VALUES ('161', '分组删除', '157', '0', 'admin', 'api/apigroupdel', '1', '', '1', '1504004732', '1504004732');
INSERT INTO `xt_menu` VALUES ('162', '接口列表', '157', '0', 'admin', 'api/apilist', '0', 'fa fa-fw fa-th-list', '1', '1504172326', '1504172326');
INSERT INTO `xt_menu` VALUES ('163', '接口添加', '157', '0', 'admin', 'api/apiadd', '0', 'fa fa-fw fa-plus', '1', '1504172352', '1504172352');
INSERT INTO `xt_menu` VALUES ('164', '接口编辑', '157', '0', 'admin', 'api/apiedit', '1', '', '1', '1504172414', '1504172414');
INSERT INTO `xt_menu` VALUES ('165', '接口删除', '157', '0', 'admin', 'api/apidel', '1', '', '1', '1504172435', '1504172435');
INSERT INTO `xt_menu` VALUES ('166', '优化维护', '68', '6', 'admin', 'maintain/index', '1', 'fa-legal', '1', '1535971031', '1505387256');
INSERT INTO `xt_menu` VALUES ('167', 'SEO管理', '166', '0', 'admin', 'seo/seolist', '0', 'fa-list', '1', '1506309608', '1505387303');
INSERT INTO `xt_menu` VALUES ('168', '数据库', '68', '21', 'admin', 'maintain/database', '0', 'fa-database', '1', '1536728867', '1505539394');
INSERT INTO `xt_menu` VALUES ('169', '数据备份', '168', '0', 'admin', 'database/databackup', '0', 'fa-download', '1', '1506309900', '1505539428');
INSERT INTO `xt_menu` VALUES ('170', '数据还原', '168', '11', 'admin', 'database/datarestore', '0', 'fa-exchange', '1', '1536544463', '1505539492');
INSERT INTO `xt_menu` VALUES ('171', '文件清理', '166', '0', 'admin', 'fileclean/cleanlist', '0', 'fa-file', '1', '1506310152', '1505788517');
INSERT INTO `xt_menu` VALUES ('174', '行为日志', '166', '0', 'admin', 'log/loglist', '0', 'fa-street-view', '1', '1507201516', '1507200836');
INSERT INTO `xt_menu` VALUES ('176', '执行记录', '166', '0', 'admin', 'exelog/index', '0', 'fa-list-alt', '1', '1509433351', '1509433351');
INSERT INTO `xt_menu` VALUES ('177', '全局范围', '176', '0', 'admin', 'exelog/applist', '0', 'fa-tags', '1', '1509433570', '1509433570');
INSERT INTO `xt_menu` VALUES ('178', '接口范围', '176', '0', 'admin', 'exelog/apilist', '0', 'fa-tag', '1', '1509433591', '1509433591');
INSERT INTO `xt_menu` VALUES ('198', '关系图', '0', '5', 'admin', 'statistic/index', '0', 'fa-connectdevelop', '1', '1536195119', '1512638014');
INSERT INTO `xt_menu` VALUES ('199', '权限等级', '198', '0', 'admin', 'statistic/membertree', '1', 'fa-users', '1', '1535966149', '1512638868');
INSERT INTO `xt_menu` VALUES ('200', '浏览器统计', '203', '0', 'admin', 'statistic/performerfacility', '0', 'fa-edge', '1', '1533865293', '1512727672');
INSERT INTO `xt_menu` VALUES ('201', '执行速度', '203', '0', 'admin', 'statistic/exespeed', '0', 'fa-fighter-jet', '1', '1533865324', '1512787226');
INSERT INTO `xt_menu` VALUES ('202', '会员增长', '203', '0', 'admin', 'statistic/membergrowth', '0', 'fa-line-chart', '1', '1533865366', '1512801997');
INSERT INTO `xt_menu` VALUES ('203', '友情链接', '75', '7', 'admin', 'blogroll/index', '0', 'fa-link', '1', '1534495422', '1520505717');
INSERT INTO `xt_menu` VALUES ('204', '链接列表', '203', '0', 'admin', 'blogroll/blogrolllist', '0', 'fa-th', '1', '1520505777', '1520505777');
INSERT INTO `xt_menu` VALUES ('205', '链接添加', '203', '0', 'admin', 'blogroll/blogrolladd', '0', 'fa-plus', '1', '1520505826', '1520505826');
INSERT INTO `xt_menu` VALUES ('206', '链接编辑', '203', '0', 'admin', 'blogroll/blogrolledit', '1', 'fa-edit', '1', '1520505863', '1520505863');
INSERT INTO `xt_menu` VALUES ('207', '链接删除', '203', '0', 'admin', 'blogroll/blogrolldel', '1', 'fa-minus', '1', '1520505889', '1520505889');
INSERT INTO `xt_menu` VALUES ('208', '菜单排序', '75', '0', 'admin', 'menu/setsort', '1', '', '1', '1520506696', '1520506696');
INSERT INTO `xt_menu` VALUES ('209', '货币流向', '68', '11', 'admin', 'statistic/historyList', '0', 'fa-reorder', '1', '1536728944', '1533349314');
INSERT INTO `xt_menu` VALUES ('210', '接点图', '198', '0', 'admin', 'statistic/Tree3', '0', 'fa-users', '1', '1533885325', '1533353131');
INSERT INTO `xt_menu` VALUES ('211', '订单管理', '68', '6', 'admin', 'index/index/index', '0', 'fa-archive', '1', '1536921674', '1533644958');
INSERT INTO `xt_menu` VALUES ('212', '产品管理', '211', '1', 'admin', 'shopadmin/index', '0', 'fa-cogs', '1', '1533701811', '1533700168');
INSERT INTO `xt_menu` VALUES ('213', '产品浏览', '211', '0', 'admin', 'shop/index', '1', 'fa-cart-plus', '1', '1536888290', '1533700412');
INSERT INTO `xt_menu` VALUES ('214', '产品列表', '212', '0', 'admin', 'shopadmin/shoplist', '0', 'fa-align-justify', '1', '1533708430', '1533701028');
INSERT INTO `xt_menu` VALUES ('215', '产品分类', '212', '1', 'admin', 'shopadmin/shopcategorylist', '0', 'fa-list', '1', '1533708447', '1533701057');
INSERT INTO `xt_menu` VALUES ('216', '分类添加', '212', '3', 'admin', 'shopadmin/shopcategoryadd', '0', 'fa-plus', '1', '1533708455', '1533701084');
INSERT INTO `xt_menu` VALUES ('217', '产品添加', '212', '5', 'admin', 'shopadmin/shopadd', '0', 'fa-plus', '1', '1533708462', '1533701124');
INSERT INTO `xt_menu` VALUES ('218', '订单管理', '211', '0', 'admin', 'shop/order_list2', '0', 'fa-home', '1', '1536814462', '1533862708');
INSERT INTO `xt_menu` VALUES ('219', '购物车', '218', '0', 'admin', 'shop/car_list', '0', 'fa-shopping-cart', '-1', '1534585375', '1533862794');
INSERT INTO `xt_menu` VALUES ('220', '我的订单', '218', '0', 'admin', 'shop/order_list', '0', 'fa-align-left', '-1', '1534585371', '1533862853');
INSERT INTO `xt_menu` VALUES ('221', '推荐图', '198', '0', 'admin', 'vip/tree1', '0', 'fa-pagelines', '1', '1536667295', '1533884570');
INSERT INTO `xt_menu` VALUES ('222', '清空数据库', '170', '0', 'admin', 'member/clean', '0', 'fa-leaf', '-1', '1534478660', '1534476785');
INSERT INTO `xt_menu` VALUES ('223', '会员充值', '16', '0', 'admin', 'shopadmin/charge', '0', 'fa-jpy', '1', '1536029508', '1534823178');
INSERT INTO `xt_menu` VALUES ('224', '会员提现', '16', '0', 'admin', 'shopadmin/drawal', '0', '', '1', '1534989255', '1534989255');
INSERT INTO `xt_menu` VALUES ('225', '个人设置', '0', '1', 'admin', 'index/user/inde', '0', 'fa-user', '1', '1535967101', '1535966736');
INSERT INTO `xt_menu` VALUES ('226', '资料修改', '225', '0', 'admin', 'user/my_data', '0', '', '1', '1535969069', '1535966788');
INSERT INTO `xt_menu` VALUES ('227', '注册账户', '229', '0', 'admin', 'index/member_add', '0', '', '1', '1536194702', '1535966876');
INSERT INTO `xt_menu` VALUES ('228', '二维码分享', '229', '0', 'admin', 'vip/qcode', '0', '', '1', '1536195197', '1535966957');
INSERT INTO `xt_menu` VALUES ('229', '会员中心', '0', '2', 'admin', 'vip', '0', '', '1', '1536195078', '1535969770');
INSERT INTO `xt_menu` VALUES ('230', '提现', '242', '2', 'admin', 'vip/withdrawadd', '0', '', '1', '1536194963', '1535969850');
INSERT INTO `xt_menu` VALUES ('231', '转账', '242', '1', 'admin', 'vip/transfer', '0', '', '1', '1536194934', '1535969902');
INSERT INTO `xt_menu` VALUES ('232', '流水明细', '242', '0', 'admin', 'vip/bonusList4', '0', '', '1', '1536656442', '1535970098');
INSERT INTO `xt_menu` VALUES ('233', '新闻公告', '243', '0', 'admin', 'user/article_list', '0', '', '1', '1536194999', '1535971273');
INSERT INTO `xt_menu` VALUES ('234', '邮箱', '229', '3', 'admin', 'mail', '0', '', '1', '1536031025', '1535971624');
INSERT INTO `xt_menu` VALUES ('235', '收件箱', '234', '0', 'admin', 'vip/inmsg', '0', '', '1', '1536197898', '1535971652');
INSERT INTO `xt_menu` VALUES ('236', '发件箱', '234', '0', 'admin', 'vip/outmsg', '0', '', '1', '1536197852', '1535971664');
INSERT INTO `xt_menu` VALUES ('237', '写邮件', '234', '0', 'admin', 'vip/writemsg', '0', '', '1', '1536197752', '1535971675');
INSERT INTO `xt_menu` VALUES ('238', '奖金明细', '242', '0', 'admin', 'vip/bonusList', '0', '', '1', '1536194918', '1535972688');
INSERT INTO `xt_menu` VALUES ('239', '充值', '242', '1', 'admin', 'vip/charge_member', '0', '', '1', '1536194951', '1536025887');
INSERT INTO `xt_menu` VALUES ('240', '会员激活', '229', '0', 'admin', 'vip/memberList', '0', '', '1', '1536043847', '1536030963');
INSERT INTO `xt_menu` VALUES ('241', '配置列表', '75', '0', 'admin', 'config/configlist', '0', '', '1', '1536052149', '1536052149');
INSERT INTO `xt_menu` VALUES ('242', '会员财务', '0', '3', 'admin', '', '0', '', '1', '1536195085', '1536194839');
INSERT INTO `xt_menu` VALUES ('243', '会员资讯', '0', '4', 'admin', '', '0', '', '1', '1536195090', '1536194878');
INSERT INTO `xt_menu` VALUES ('244', '手动业绩奖', '68', '9', 'admin', 'config/achieve', '0', '', '1', '1536728936', '1536656745');
INSERT INTO `xt_menu` VALUES ('245', '奖金明细', '68', '10', 'admin', 'vip/bonuslist5', '0', '', '1', '1536728904', '1536712662');
INSERT INTO `xt_menu` VALUES ('246', '我的订单', '229', '0', 'admin', 'user/order_list', '0', '', '1', '1536826097', '1536826076');

-- -----------------------------
-- Table structure for `xt_msg`
-- -----------------------------
DROP TABLE IF EXISTS `xt_msg`;
CREATE TABLE `xt_msg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `f_uid` int(11) NOT NULL DEFAULT '0',
  `f_user_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `s_uid` int(11) NOT NULL DEFAULT '0',
  `s_user_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `f_time` int(11) NOT NULL DEFAULT '0',
  `f_del` smallint(3) NOT NULL DEFAULT '0',
  `s_del` smallint(3) NOT NULL DEFAULT '0',
  `f_read` smallint(3) NOT NULL DEFAULT '0',
  `s_read` smallint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- -----------------------------
-- Records of `xt_msg`
-- -----------------------------
INSERT INTO `xt_msg` VALUES ('27', '1', '100000', '1', '100000', 'werwerwer', 'werwerwerwe', '1536197094', '1', '1', '1', '1');
INSERT INTO `xt_msg` VALUES ('28', '1', '100000', '1', '100000', '', '', '1536199255', '1', '1', '0', '0');
INSERT INTO `xt_msg` VALUES ('29', '1', '100000', '1', '100000', '认同的人', '儿童额', '1536199286', '1', '1', '0', '1');
INSERT INTO `xt_msg` VALUES ('30', '1', '100000', '1', '100000', '回复：werwerwer', '随碟附送的', '1536201689', '1', '1', '0', '1');
INSERT INTO `xt_msg` VALUES ('31', '1', '100000', '1', '100000', '回复：认同的人', '人味儿', '1536202053', '1', '1', '0', '0');
INSERT INTO `xt_msg` VALUES ('32', '1', '100000', '1', '100000', '回复：回复：werwerwer', '动态 ', '1536202068', '1', '1', '0', '0');
INSERT INTO `xt_msg` VALUES ('34', '1', '100000', '1', '100000', '123', '123', '1536546085', '0', '0', '0', '1');

-- -----------------------------
-- Table structure for `xt_picture`
-- -----------------------------
DROP TABLE IF EXISTS `xt_picture`;
CREATE TABLE `xt_picture` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id自增',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '图片名称',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '图片链接',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='图片表';

-- -----------------------------
-- Records of `xt_picture`
-- -----------------------------
INSERT INTO `xt_picture` VALUES ('1', '84fafa1987401d06e61af234ab09d3a0.jpg', '20180818/84fafa1987401d06e61af234ab09d3a0.jpg', '', '07cc2894a31281cbdca53bbe8cd69309bc980cb6', '1534574193', '0', '1');
INSERT INTO `xt_picture` VALUES ('2', '1bcf4dd4ab63c7a987e3d26fa3fcf2e0.jpg', '20180818/1bcf4dd4ab63c7a987e3d26fa3fcf2e0.jpg', '', 'cf759987c0799f07a2f49a348f2bda4387a568f9', '1534574198', '0', '1');
INSERT INTO `xt_picture` VALUES ('3', 'e7714d04b0443d8c0a7c790f13c3eb0e.jpg', '20180818/e7714d04b0443d8c0a7c790f13c3eb0e.jpg', '', '968416d9c92f57361d62a8909379a0a6343c3c57', '1534574202', '0', '1');
INSERT INTO `xt_picture` VALUES ('4', 'a5fbc873d2ffc4e27f3c0049e8327d2a.jpg', '20180818/a5fbc873d2ffc4e27f3c0049e8327d2a.jpg', '', 'a9a41bc0439e29c4f182ad5a9118e644409171ae', '1534574206', '0', '1');
INSERT INTO `xt_picture` VALUES ('5', '93d4702dae83f5d3a07d3fd86e850f36.jpg', '20180818/93d4702dae83f5d3a07d3fd86e850f36.jpg', '', 'c9cb30cb7f6555e3e973733b17326d03112390d7', '1534574219', '0', '1');
INSERT INTO `xt_picture` VALUES ('6', '32a1fa981684a42e96fdd0f6c4a55888.jpg', '20180818/32a1fa981684a42e96fdd0f6c4a55888.jpg', '', 'ce19aa0e6cf6b9bf3a6c4439e7f5f12c30f22b9b', '1534574232', '0', '1');
INSERT INTO `xt_picture` VALUES ('7', 'cf4e80c446d94d6d40b5c966479e9d39.jpg', '20180823/cf4e80c446d94d6d40b5c966479e9d39.jpg', '', 'f0c7066ecbd16879194bc49500eb4cd6db6ef667', '1535006562', '0', '1');
INSERT INTO `xt_picture` VALUES ('8', '29c0a3f2f7e707b88674b2a1171dc85f.png', '20180823/29c0a3f2f7e707b88674b2a1171dc85f.png', '', '5f1b235656efffe7457a96f79179a295b74a7375', '1535008720', '0', '1');
INSERT INTO `xt_picture` VALUES ('9', '83dd83d265591bb5a77f617c2f72b2b1.png', '20180914/83dd83d265591bb5a77f617c2f72b2b1.png', '', '32e2ab52f1b436e14f336195b13ddce274bdd7b1', '1536921584', '0', '1');

-- -----------------------------
-- Table structure for `xt_seo`
-- -----------------------------
DROP TABLE IF EXISTS `xt_seo`;
CREATE TABLE `xt_seo` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `url` varchar(40) NOT NULL DEFAULT '' COMMENT '模块',
  `seo_title` text NOT NULL COMMENT '标题',
  `seo_keywords` text NOT NULL COMMENT '关键字',
  `seo_description` text NOT NULL COMMENT '描述',
  `usable_val` varchar(255) NOT NULL DEFAULT '' COMMENT '可用变量',
  `sort` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8 COMMENT='seo表';

-- -----------------------------
-- Records of `xt_seo`
-- -----------------------------
INSERT INTO `xt_seo` VALUES ('40', '首页SEO信息', 'index/index/index', 'OneBase 开发架构{$category_name}{$article_title}', 'OneBase,PHP,{$category_name},{$article_title}', '一款基于ThinkPHP5研发的开源免费基础架构，基于OneBase可以快速的研发各类Web应用。{$article_describe}', '{$category_name}，{$article_title}，{$article_describe}', '0', '1', '1505445912', '1505470293');
INSERT INTO `xt_seo` VALUES ('41', 'OneBase-系统登录', 'index/index/login', 'OneBase', 'OneBase', 'OneBase', '', '0', '1', '1505538002', '1505538026');

-- -----------------------------
-- Table structure for `xt_shop`
-- -----------------------------
DROP TABLE IF EXISTS `xt_shop`;
CREATE TABLE `xt_shop` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文章ID',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '会员id',
  `name` char(40) NOT NULL DEFAULT '' COMMENT '文章名称',
  `category_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文章分类',
  `describe` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `content` text NOT NULL COMMENT '文章内容',
  `cover_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '封面图片id',
  `file_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件id',
  `img_ids` varchar(200) NOT NULL DEFAULT '',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态',
  `thumb_a` varchar(255) NOT NULL,
  `num` int(11) NOT NULL DEFAULT '0',
  `price` varchar(255) NOT NULL DEFAULT '0',
  `cost` varchar(255) NOT NULL,
  `des` text NOT NULL,
  `selling` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `coupons` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='购物表';

-- -----------------------------
-- Records of `xt_shop`
-- -----------------------------
INSERT INTO `xt_shop` VALUES ('60', '1', '2000产品', '13', '', '2000', '0', '0', '', '1536825080', '1536825080', '1', '', '0', '2000', '2000', '', '0', '0', '', '0');
INSERT INTO `xt_shop` VALUES ('61', '1', '5000产品', '13', '', '5000', '0', '0', '', '1536825115', '1536825115', '1', '', '123', '5000', '5000', '', '0', '0', '', '0');
INSERT INTO `xt_shop` VALUES ('62', '1', '10000产品', '13', '', '10000', '0', '0', '', '1536825156', '1536825156', '1', '', '0', '10000', '10000', '', '0', '0', '', '0');
INSERT INTO `xt_shop` VALUES ('63', '1', '30000产品', '13', '', '30000', '0', '0', '', '1536825192', '1536825192', '1', '', '1', '30000', '30000', '', '0', '0', '', '1');
INSERT INTO `xt_shop` VALUES ('64', '1', '胶囊', '13', '', '50000', '9', '0', '', '1536825217', '1536921587', '1', '', '0', '50000', '50000', '', '0', '0', '', '0');

-- -----------------------------
-- Table structure for `xt_shop_car`
-- -----------------------------
DROP TABLE IF EXISTS `xt_shop_car`;
CREATE TABLE `xt_shop_car` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `num` int(5) NOT NULL,
  `time` int(11) NOT NULL,
  `goods_id` bigint(20) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=619 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `xt_shop_category`
-- -----------------------------
DROP TABLE IF EXISTS `xt_shop_category`;
CREATE TABLE `xt_shop_category` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `describe` varchar(255) NOT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `icon` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `xt_shop_category`
-- -----------------------------
INSERT INTO `xt_shop_category` VALUES ('7', '广告包', '基础内容', '1509620712', '1535946233', '-1', 'fa-street-view');
INSERT INTO `xt_shop_category` VALUES ('13', '会员产品', '会员产品', '1535946321', '1536830460', '0', 'fa-close');
INSERT INTO `xt_shop_category` VALUES ('12', '商城消费', 'dfdgdf', '1533981489', '1535946092', '-1', 'fa-font');

-- -----------------------------
-- Table structure for `xt_shop_order`
-- -----------------------------
DROP TABLE IF EXISTS `xt_shop_order`;
CREATE TABLE `xt_shop_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `num` int(5) NOT NULL,
  `create_time` int(11) NOT NULL,
  `send_time` int(11) NOT NULL DEFAULT '0',
  `get_time` int(11) NOT NULL DEFAULT '0',
  `express_type` varchar(255) NOT NULL,
  `express_no` varchar(20) NOT NULL DEFAULT '',
  `pay_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0全现金；1全积分；2半现金半积分',
  `money_type` int(8) NOT NULL DEFAULT '0',
  `goods_id` bigint(20) NOT NULL,
  `goods_name` varchar(200) NOT NULL,
  `goods_thumb` varchar(200) NOT NULL,
  `goods_price` decimal(12,2) NOT NULL,
  `address` varchar(200) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `status` tinyint(1) NOT NULL COMMENT '0待发货；1待收货；2已完成',
  `code` varchar(255) NOT NULL,
  `express_code` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `address_fee` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=663233 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `xt_shop_order`
-- -----------------------------
INSERT INTO `xt_shop_order` VALUES ('663228', '94', '1', '1', '1536930208', '0', '0', '', '', '0', '0', '60', '2000产品', '', '2000.00', '北京市北京市东城区123', '13122222222', '123', '1', 'S20180914210328347979', '', '1', '', '');
INSERT INTO `xt_shop_order` VALUES ('663229', '95', '2', '1', '1536930261', '0', '0', '', '', '0', '0', '61', '5000产品', '', '5000.00', '北京市北京市东城区13', '13888888888', '131', '1', 'S20180914210421556914', '', '2', '', '');
INSERT INTO `xt_shop_order` VALUES ('663230', '96', '3', '1', '1536930299', '0', '0', '', '', '0', '0', '60', '2000产品', '', '2000.00', '北京市北京市东城区131', '13888888888', '131', '1', 'S20180914210459990809', '', '3', '', '');
INSERT INTO `xt_shop_order` VALUES ('663231', '97', '4', '1', '1536930349', '0', '0', '', '', '0', '0', '64', '胶囊', '', '50000.00', '北京市北京市东城区123', '13888888888', '123', '1', 'S20180914210549268026', '', '4', '', '');
INSERT INTO `xt_shop_order` VALUES ('663232', '98', '6', '1', '1536930413', '0', '0', '', '', '0', '0', '60', '2000产品', '', '2000.00', '北京市北京市东城区123', '13888888888', '123', '1', 'S20180914210653177156', '', '6', '', '');

-- -----------------------------
-- Table structure for `xt_times`
-- -----------------------------
DROP TABLE IF EXISTS `xt_times`;
CREATE TABLE `xt_times` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` char(10) NOT NULL DEFAULT '' COMMENT '日期',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `data_status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=385 DEFAULT CHARSET=utf8 COMMENT='期号表';

-- -----------------------------
-- Records of `xt_times`
-- -----------------------------
INSERT INTO `xt_times` VALUES ('384', '2018-09-14', '0', '1536930214', '1');
